DCDC-bidirectional è un library block.
La cosa più veloce per usarlo è aprire il blocco, e copiarlo nel modello simulink. 
In questo modo si creerà un link, e modificando il library block verranno modificati anche le istanze usate nei vari modelli simulink.
Nel modello in cui ho instanziato la libreria posso poi decidere di disattivare il link (dx->lybrary link-> disable link), e in quel modo modificando localmente il blocco non vengono propagate le modifiche agli altri.

NB: se simulink non trova il blocco, vuol dire che la libreria non è aggiunta al path di matlab!!!


---------------

per aggiungere la libreria nel library browser di simulink:

prima di salvare la libreria nella command window digitare
set_param(gcs,'EnableLBRepository','on');   % gcs prende il path del modello corrente, quindi fai click sul subsisteem della libreria
poi dopo nel library browser di simulink devo fare il refresh

