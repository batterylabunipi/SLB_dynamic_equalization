function var = my_load_var(filename, var_name)
% carica nel workspace la variabile dal relativo file, se non c'è la crea.
% NB: va usata come 
%   pippo =  load_var("my_file","my_var");
% questa funzione è pensata per caricare una struct ed aggiungere poi altri
% elementi alla struct. 
% quindi inizialmente load_var crea pippo = [], poi sarò io che aggiungerò
% elementi in fondo 
%        j = length(pippo)+1
%        pippo(j)=...

try
        % Carica il file MAT
        load(filename);

        % Controlla se la variabile esiste
        if ~exist(var_name, 'var')
            error(['La variabile "', var_name, '" non è presente nel file "', filename, '".']);
        end

        % Recupera la variabile
        var = eval(var_name);

    catch ME
        % Il file non esiste o la variabile non è presente
        if strcmp(ME.identifier, 'MATLAB:load:couldNotReadFile') || strcmp(ME.identifier, 'MATLAB:ErrorRecovery:ItemNoLongerOnPath')
            fprintf('File MAT "%s" non trovato. Creo il file...\n', filename);
            save(filename);
        else

            %fprintf('Variabile "%s" non presente nel file "%s". Crea a mano la variabile vuota, e poi rilanciare lo script!\n es. pippo=[]', var_name, filename);
            fprintf('Variabile "%s" non presente nel file "%s". Creo la variabile vuota\n', var_name, filename);
        end

        var = [];

        % non funziona, servirebbe un modo per creare una variabile
        % partendo da un nome fornito dinamicamente con una stringa...
        % Crea la variabile vuota   
        %var = [];
        % Salva la variabile nel file
        %save(filename, var_name);
    end

end


