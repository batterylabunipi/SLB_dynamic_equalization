%% init battery cells parameters
clear; clc;

load("data/NMC_60Ah_param.mat");

Ncell=10;    % battery composition is parametric
cell.nominal_voltage = 3.65; %V 
cell.capacity = 60;   %Ah
cell.ocv = mdl_par.ocv;
cell.soc = mdl_par.soc/100;
cell.r0 = mean(mdl_par.r0(4:19));
cell.r1 = mean(mdl_par.r1(4:19));
cell.c1 = mean(mdl_par.c1(4:19));

c_var=0.15;
c_nom=2; %Ah  il fattore 3600 lo considero quando integro la corrente per calcolare il SoC, ed è un coeff che divide
c_min=c_nom*(1-c_var);
c_max=c_nom*(1+c_var);

batt.ncell = Ncell;
batt.c_nom = c_nom;
batt.c_var = 0.15;
batt.c_cell =  [c_min:(c_max-c_min)/(Ncell-1):c_max]';
batt.r0 = (cell.r0*cell.capacity) ./ batt.c_cell;       %scalo i risultati per la capacità che considero
batt.soc0 = 1 + zeros(Ncell,1);

c_aux.soc0 = 1;
c_aux.c_cell = c_nom;  %sum(max(batt.c_cell)-batt.c_cell);
c_aux.r0 = (cell.r0*cell.capacity)  ./ c_aux.c_cell;

clearvars -except batt cell c_aux Ncell
%% set simulation parameters

% balance algo options
MODE_BAL_1 = 1;     % la c_aux viene caricata quando la batteria si carica, e scaricata quando la batteria si scarica
MODE_BAL_2 = 2;     % la c_aux viene usata anche per cariche parziali (capacità di appoggio)
MODE_NO_BAL = 3;    % disattiva il bilanciamento, ma ho il pacco costituito da 10 celle, e quella ausiliaria non la considero

c_nom = batt.c_nom;                 % used as reference for Ah_to_Crate.m
sim_par.i_batt = c_nom/10; %load current, positive=discharge, negative=charge
sim_par.bal_period = 10;            % (s) balancing algo activation period
sim_par.soc_bal_thresh = 1/100;     % cell minimum delta SoC for balancer activation 
sim_par.soc_end = 0;
sim_par.discharge_cycle = (sim_par.i_batt > 0); % 1= discharge, 0 = charge

% sweep parameter
balance_current = c_nom ./ [5,10];     % external loop 
efficiency = [0.5:0.1:1];           % internal loop

mode = MODE_BAL_1;                  % balancing algorithm selected 
%% run simulation
f_name = "data/tmp.mat";
fprintf("Simulation output in: %s \n", f_name);
C2AUX = my_load_var(f_name, "C2AUX");

sim_par.mode = mode;

load_system('simulink/dyn_bal_C2AUX');
for k=1:length(balance_current)
    j=length(C2AUX)+1;  % evaluate struct saving index
    i_bal = balance_current(k);
    C2AUX(j).i_bal = i_bal;
    C2AUX(j).i_bal_str = Ah_to_Crate(i_bal,c_nom);    
    C2AUX(j).sim_par = sim_par; % saving metadata
    C2AUX(j).batt = batt;
    C2AUX(j).cell = cell;
    C2AUX(j).c_aux = c_aux;
    for i=1:length(efficiency)
        eff = efficiency(i);
        C2AUX(j).e(i) = eff;
        
        tic;
        fprintf('ONGOING: %d of %d, eff:%.1f, I_bal: %.4f, at %s', ((k-1)*length(efficiency))+i, length(efficiency)*size(balance_current,2), eff, balance_current(k), datestr(now,'HH:MM:SS.FFF'));
        out = sim('simulink/dyn_bal_C2AUX.slx');
        fprintf(' -> elapsed:%.2f\n', toc)

        % uncomment to save simulation output data 
        C2AUX(j).CB_obtained(i) = out.capacity_extracted;
        C2AUX(j).energy_obtained(i) = out.energy_extracted;
        C2AUX(j).last_SoC(i,:) = out.SoC.Data(end,:);
        C2AUX(j).last_SoC_auxCell(i) = out.SoC_aux_cell.Data(end);
        C2AUX(j).out(i).SoC = out.SoC;
        C2AUX(j).out(i).SoC_aux_cell = out.SoC_aux_cell;
        %C2AUX(j).out(i).Icell = out.Icell;
        C2AUX(j).out(i).Icell_bal = out.Icell_bal;
        C2AUX(j).out(i).I_aux_cell = out.I_aux_cell;
        C2AUX(j).out(i).bal_ctrl = out.bal_ctrl;
        %C2AUX(j).out(i) = out;  se salvo tutto sono un sacco di Gb
    end
    save(f_name, 'C2AUX',"-append");
end
%close_system('dyn_bal_C2AUX');