%% capacity gain theoretical data
ideal_Cb = [20.5700000000000	20.9200000000000	21.2300000000000	21.5100000000000	21.7700000000000	22]/10;   % @ C_aux=2Ah
%ideal_Cb = [21.2600000000000	21.6700000000000	22.0400000000000	22.3800000000000	22.6900000000000	23]/10;   % @ C_aux=3Ah
ideal_e = [0.5:0.1:1];

%% RAW DATA
f_name = "data/tmp.mat";
%load(f_name,"C2AUX");

sim_idx = [1];
eff_idx = [1];

for k=1:length(sim_idx)
    j = sim_idx(k);
    for l=1:length(eff_idx)
        i = eff_idx(l);
        figure;
        metadata = sprintf('METADATA - only discharge: %s, eff=%.1f, capacity gain=%.1f%%', ...
            Ah_to_Crate(C2AUX(j).i_bal, C2AUX(j).batt.c_nom), ...
            C2AUX(j).e(i), ...
            ((C2AUX(j).CB_obtained(i) - 1.7)/1.7)*100);
        txt_pos = [0.001 0.9 0.1 0.1];
        txt = annotation('textbox',txt_pos, 'String',metadata);
        tiledlayout(2,2);
        nexttile;
        plot(C2AUX(j).out(i).SoC)   % SoC celle
        title("Cells SoC");
        nexttile;
        plot(C2AUX(j).out(i).Icell_bal)
        title("cells bal current");
        nexttile;
        plot(C2AUX(j).out(i).SoC_aux_cell)
        title("aux cell SoC");
        nexttile; hold on
        plot(C2AUX(j).out(i).bal_ctrl)
        plot(C2AUX(j).out(i).I_aux_cell)
        title("Balancing data");
        legend("Bal ctrl", "aux cell current")
    end
end

%% analysis con extracted energy
f_name = "data/tmp.mat";
%load(f_name,"C2AUX");

%E_batt_NOBAL = 70.6386; % @C_aux=3A
E_batt_NOBAL = 70.4663; % @C_aux=2A

sim_idx = [3,4];   %NB: mettere E_batt_NOBAL coerente con la C_aux usata nelle simulazioni
figure;
tiledlayout(2,3);

metadata = sprintf('METADATA: aux cell=%.1f Ah', C2AUX(sim_idx(1)).c_aux.c_cell);
txt_pos = [0.001 0.9 0.1 0.1];
txt = annotation('textbox',txt_pos, 'String',metadata);

nexttile(1); hold on;
for k=1:length(sim_idx)
    j=sim_idx(k);
    plot(C2AUX(j).e, C2AUX(j).CB_obtained,'-o')
end
title("extracted capacity")
xlabel("efficiency")
ylabel("Ah")

nexttile(4); hold on;
plot(ideal_e, ((ideal_Cb- 1.7)/1.7)*100,'-*', "Color","black");
for k=1:length(sim_idx)
    j=sim_idx(k);
    plot(C2AUX(j).e, ((C2AUX(j).CB_obtained - 1.7)/1.7)*100)
end
title("capacity gain")
xlabel("efficiency")
ylabel("%")

nexttile(3); hold on;
legend_str = " ";
for k=1:length(sim_idx)
    j=sim_idx(k);
    plot(C2AUX(j).e, max(C2AUX(j).last_SoC,[],2))
    legend_str(k) =  Ah_to_Crate(C2AUX(j).i_bal,2);
end
legend(legend_str)
plot(C2AUX(j).e, 0.01+zeros(length(C2AUX(j).e),1), "LineStyle","--", "LineWidth",2, "Color","red")

title("residual SoC")

nexttile(6); hold on;
legend_str = " ";
for k=1:length(sim_idx)
    j=sim_idx(k);
    plot(C2AUX(j).e, C2AUX(j).last_SoC_auxCell)
end
title("aux cell residual SoC")

nexttile(2); hold on;
for k=1:length(sim_idx)
    j=sim_idx(k);
    plot(C2AUX(j).e, C2AUX(j).energy_obtained)
end

title("energy extracted")
ylabel("Wh")
xlabel("efficiency")

nexttile(5); hold on;
legend_str = " ";
for k=1:length(sim_idx)
    j=sim_idx(k);
    plot(C2AUX(j).e, ((C2AUX(j).energy_obtained - E_batt_NOBAL)/E_batt_NOBAL)*100);
    legend_str(k) =  Ah_to_Crate(C2AUX(j).i_bal,2);
end
legend(legend_str)
title("energy gain")
ylabel("%")
xlabel("efficiency")
