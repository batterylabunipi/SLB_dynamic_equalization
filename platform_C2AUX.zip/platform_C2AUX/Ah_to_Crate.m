function Crate_str = Ah_to_Crate(current, C)
% output a string with fraction related to the C-rate expression of "current",
% respect to "C" capacity
% ex. C=2Ah  I=0.01A -> "C/200"

[N,D] = rat(current/C);

if N ~= 1
    Crate_str = sprintf("C*%.0f/%.0f", N, D);
    disp(Crate_str);
    disp("-->");
    disp(current);
    disp("numeratore non unitario!");
else
    Crate_str = sprintf("I_{bal}=C/%.0f", D);
end