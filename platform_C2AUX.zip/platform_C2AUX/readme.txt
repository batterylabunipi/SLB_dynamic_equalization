Simulation platform for Second Life battery dynamic balancing based on auxiliary cell balancing.

platform_manager.m define the variables to run the simulink model, and then starts simulation.
parameters are:
    battery parameter
        Ncell, c_var, c_nom, r0, SoC0
    cell parameter
        ocv, soc, r1, c1
    aux cell parameter
        ocv, soc, r1, c1, capacity
    simulation options
        i_batt, i_bal, bal_period, bal_mode, bal_thresh, soc_end
    

