%% init battery cells parameters
clear; clc;

load("data/NMC_60Ah_param.mat");

Ncell=10;    % battery composition is parametric
cell.nominal_voltage = 3.65; %V 
cell.capacity = 60;   %Ah
cell.ocv = mdl_par.ocv;
cell.soc = mdl_par.soc/100;
cell.r0 = mean(mdl_par.r0(4:19));
cell.r1 = mean(mdl_par.r1(4:19));
cell.c1 = mean(mdl_par.c1(4:19));

c_var=0.15;
c_nom=2; %Ah  il fattore 3600 lo considero quando integro la corrente per calcolare il SoC, ed è un coeff che divide
c_min=c_nom*(1-c_var);
c_max=c_nom*(1+c_var);

batt.ncell = Ncell;
batt.c_nom = c_nom;
batt.c_var = 0.15;
batt.c_cell =  [c_min:(c_max-c_min)/(Ncell-1):c_max]';
batt.r0 = (cell.r0*cell.capacity) ./ batt.c_cell;       %scalo i risultati per la capacità che considero
batt.soc0 = 1 + zeros(Ncell,1);


clearvars -except batt cell Ncell

%% set simulation parameters

c_nom = batt.c_nom;                 % used as reference for Ah_to_Crate.m
sim_par.i_batt = c_nom/10; %load current, positive=discharge, negative=charge
sim_par.bal_period = 10;            % (s) balancing algo activation period
sim_par.soc_bal_thresh = 0.5/100;     % cell minimum delta SoC for balancer activation 
sim_par.soc_end = 0;
sim_par.discharge_cycle = (sim_par.i_batt > 0); % 1= discharge, 0 = charge

% sweep parameter
balance_current = c_nom ./ [20,25,30];     % external loop 
efficiency = [0.1:0.1:1];           % internal loop

%% AC2C
% se tolgo il delay nella retroazione della corrente di bilanciamento, il
% tempo di simulazione si allunga moltissimo
f_name = "data/data_small.mat";
fprintf("Simulation output in: %s \n", f_name);
AC2C = my_load_var(f_name, "AC2C");

balance_current = c_nom ./ [20,25,30];

load_system('simulink/dyn_bal_AC2C');
for k=1:length(balance_current)
    j=length(AC2C)+1;  % evaluate struct saving index
    i_bal = balance_current(k);
    AC2C(j).i_bal = i_bal;
    AC2C(j).i_bal_str = Ah_to_Crate(i_bal,c_nom);    
    AC2C(j).sim_par = sim_par; % saving metadata
    AC2C(j).batt = batt;
    AC2C(j).cell = cell;
    for i=1:length(efficiency)
        eff = efficiency(i);
        AC2C(j).e(i) = eff;
        
        tic;
        fprintf('ONGOING: %d of %d, eff:%.1f, I_bal: %.4f, at %s', ((k-1)*length(efficiency))+i, length(efficiency)*size(balance_current,2), eff, balance_current(k), datestr(now,'HH:MM:SS.FFF'));
        out = sim('simulink/dyn_bal_AC2C.slx');
        fprintf(' -> elapsed:%.2f\n', toc)

        % uncomment to save simulation output data 
        AC2C(j).CB_obtained(i) = out.capacity_extracted;
        AC2C(j).energy_obtained(i) = out.energy_extracted;
        AC2C(j).last_SoC(i,:) = out.SoC.Data(end,:);
        %AC2C(j).out(i).SoC = out.SoC;
        %AC2C(j).out(i).Icell = out.Icell;
        %AC2C(j).out(i).Icell_bal = out.Icell_bal;
        %AC2C(j).out(i).bal_ctrl = out.bal_ctrl;
        %AC2C(j).out(i) = out;  se salvo tutto sono un sacco di Gb
    end
    save(f_name, 'AC2C',"-append");
end
close_system('simulink/dyn_bal_AC2C');