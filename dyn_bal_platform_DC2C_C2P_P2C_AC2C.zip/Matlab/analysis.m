%% DC2C plot
f_name = "data/tmp.mat";
%load(f_name, "DC2C");

CB_targ = [6120,6583,6742,6852,6930,6994,7048,7094,7133,7168,7200]/3600;
e_targ = [0:0.1:1];

sim_idx = [1,2,3];  % avendo fatto tante simulazioni, con gli indici di questa tabella scelgo quale delle simulazioni plottare

f=figure; 
tiledlayout(2,1);
nexttile;
hold on; grid on; 

xlim([0.1 1]);
plot(e_targ,((CB_targ-1.7) / 1.7)*100,"-*", 'Color', 'k');
legend_str = " ";
legend_str(1) = "ideal";
for j=1:length(sim_idx)
    i = sim_idx(j);     
    plot(DC2C(i).e,((DC2C(i).CB_obtained - 1.7) / 1.7)*100, 'Marker',".");
    legend_str(end+1) = Ah_to_Crate(DC2C(i).i_bal, DC2C(i).batt.c_nom);
end
title("DC2C");
ylabel('Capacity gain (%)' );
legend(legend_str);

nexttile;
hold on; grid on; 

xlim([0.1 1]);
ideal_last_SoC = 0.01 + zeros(1,6);
p = plot([0:0.2:1], ideal_last_SoC*100,"LineStyle","--", "LineWidth",2, "Color","red");
ylim([0.005, inf])
for j=1:length(sim_idx)
    i = sim_idx(j); 
    plot(DC2C(i).e, max(DC2C(i).last_SoC,[],2)*100, 'Marker',".");
end
legend(p, "SoC threshold", 'Location','northwest');
ylabel('Residual SoC (%)');
xlabel('DC/DC efficiency');


%% P2C plot
f_name = "data/tmp.mat";
%load(f_name, "P2C");
CB_targ = [6120,6240,6360,6480,6600,6720,6840,6960,7080,7200]/3600;
e_targ = [0.1:0.1:1];

sim_idx = [1,2,3];  % avendo fatto tante simulazioni, con gli indici di questa tabella scelgo quale delle simulazioni plottare

f=figure; 
tiledlayout(2,1);
nexttile;
hold on; grid on; 

xlim([0.1 1]);
plot(e_targ,((CB_targ-1.7) / 1.7)*100,"-*", 'Color', 'k');
legend_str = " ";
legend_str(1) = "ideal";
for j=1:length(sim_idx)
    i = sim_idx(j); 
    plot(P2C(i).e,((P2C(i).CB_obtained - 1.7) / 1.7)*100, 'Marker',".");
    legend_str(end+1) = Ah_to_Crate(P2C(i).i_bal, P2C(i).batt.c_nom);
end
title("P2C");
ylabel('Capacity gain (%)' );
legend(legend_str);

nexttile;
hold on; grid on; 

xlim([0.1 1]);
ideal_last_SoC = 0.01 + zeros(1,6);
p = plot([0:0.2:1], ideal_last_SoC*100,"LineStyle","--", "LineWidth",2, "Color","red");
ylim([0.005, inf])
for j=1:length(sim_idx)
    i = sim_idx(j); 
    plot(P2C(i).e, max(P2C(i).last_SoC,[],2)*100, 'Marker',".");
end
legend(p, "SoC threshold", 'Location','northwest');
ylabel('Residual SoC (%)');
xlabel('DC/DC efficiency');

%% C2P plot
f_name = "data/tmp.mat";
%load(f_name, "C2P");
CB_targ  = [6120,6228,6336,6444,6552,6660,6768,6876,6984,7092,7200]/3600;
e_targ = [0:0.1:1];

sim_idx = [1,2,3];  % avendo fatto tante simulazioni, con gli indici di questa tabella scelgo quale delle simulazioni plottare

f=figure; 
tiledlayout(2,1);
nexttile;
hold on; grid on; 

xlim([0.1 1]);
plot(e_targ,((CB_targ-1.7) / 1.7)*100,"-*", 'Color', 'k');
legend_str = " ";
legend_str(1) = "ideal";
for j=1:length(sim_idx)
    i = sim_idx(j); 
    plot(C2P(i).e,((C2P(i).CB_obtained - 1.7) / 1.7)*100, 'Marker',".");
    legend_str(end+1) = Ah_to_Crate(C2P(i).i_bal, C2P(i).batt.c_nom);
end
title("C2P");
ylabel('Capacity gain (%)' );
legend(legend_str);

nexttile;
hold on; grid on; 

xlim([0.1 1]);
ideal_last_SoC = 0.01 + zeros(1,6);
p = plot([0:0.2:1], ideal_last_SoC*100,"LineStyle","--", "LineWidth",2, "Color","red");
ylim([0.005, inf])
for j=1:length(sim_idx)
    i = sim_idx(j); 
    plot(C2P(i).e, max(C2P(i).last_SoC,[],2)*100, 'Marker',".");
end
legend(p, "SoC threshold", 'Location','northwest');
ylabel('Residual SoC (%)');
xlabel('DC/DC efficiency');

%% AC2C plot
f_name = "data/data_small.mat";
%load(f_name, "AC2C");

CB_targ = [6120,6146,6179,6222,6279,6357,6465,6610,6791,6995,7200]/3600;   %Ah
e_targ = [0:0.1:1];

sim_idx = [1,2,3];  % avendo fatto tante simulazioni, con gli indici di questa tabella scelgo quale delle simulazioni plottare

f=figure; 
tiledlayout(2,1);
nexttile;
hold on; grid on; 

xlim([0.1 1]);
plot(e_targ,((CB_targ-1.7) / 1.7)*100,"-*", 'Color', 'k');
legend_str = " ";
legend_str(1) = "ideal";
for j=1:length(sim_idx)
    i = sim_idx(j);     
    plot(AC2C(i).e,((AC2C(i).CB_obtained - 1.7) / 1.7)*100, 'Marker',".");
    legend_str(end+1) = Ah_to_Crate(AC2C(i).i_bal, AC2C(i).batt.c_nom);
end
title("AC2C");
ylabel('Capacity gain (%)' );
legend(legend_str);

nexttile;
hold on; grid on; 

xlim([0.1 1]);
ideal_last_SoC = 0.01 + zeros(1,6);
p = plot([0:0.2:1], ideal_last_SoC*100,"LineStyle","--", "LineWidth",2, "Color","red");
ylim([0.005, inf])
for j=1:length(sim_idx)
    i = sim_idx(j); 
    plot(AC2C(i).e, max(AC2C(i).last_SoC,[],2)*100, 'Marker',".");
end
legend(p, "SoC threshold", 'Location','northwest');
ylabel('Residual SoC (%)');
xlabel('DC/DC efficiency');