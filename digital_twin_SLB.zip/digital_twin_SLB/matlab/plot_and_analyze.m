%% load file
clear;
tic;

selected_month = 3; 
file_name_list = ["data/output/gennaio.mat",
    "data/output/febbraio.mat",
    "data/output/marzo.mat",
    "data/output/aprile.mat",
    "data/output/maggio.mat",
    "data/output/giugno.mat",
    "data/output/luglio.mat",
    "data/output/agosto.mat",
    "data/output/settembre.mat",
    "data/output/ottobre.mat",
    "data/output/novembre.mat",
    "data/output/dicembre.mat"];

% file_name = "data/output/tmp2.mat";
file_name = file_name_list(selected_month);

fprintf("loading: %s \t ", file_name)
load(file_name);
fprintf(" -> DONE, elapsed:%.1f sec\n", toc);

c = struct();
c.no_bal        = [205, 0,26]/255;    % rosso
c.always_bal    = [25,97,174]/255; %blu
c.opt_bal(1,:)    = [242,205,0]/255; %arancio
c.opt_bal(2,:)    = [239,106,0]/255; %giallo
c.opt_bal(3,:)    = [121,195,0]/255; %verde
c.ideal         = [97,0,125] /255;       %viola

%% PLOT SoC and bal_activation
%close all
ref_index = 1; % indice della simulazione che contiene NO_BAL e IDEAL
index = 4;  % indice della simulazione da analizzare in my_out
sim_ref = my_out(ref_index);
sim = my_out(index);
horizon_index = [1 2];    % orizzonte della simulazione da mostrare
plot_check = [1 1 1]; % seleziona il tipo di grafico da plottare (mettere a 1 il bit corrispettivo)
% #1 = grafico con NO_BAL e ALWAYS_BAL
% #2 = grafico con SoC e Bal affiancati e un subplot per ogni horizon
% #3 = grafico di un singolo horizon con SoC e bal
% sovrapposti, una figure per ogni horizon
%
if plot_check(1)
    figure();
    add_label_metadata(sim,file_name, 'I_bal');
    tiledlayout(2, 2);
    ax1=nexttile; hold on;
    plot(sim_ref.no_bal.SoC_profile);
    % plot(sim_ref.no_bal.SoC_profile(:,1) * sim.batt.c_cell(1));
    % plot(sim_ref.no_bal.SoC_profile(:,10)* sim.batt.c_cell(10));
    title('NO BALANCING - SoC profile');
    xlabel("step(15min)");
    ax2=nexttile;
    plot(sim_ref.no_bal.bal_activation_profile);
    title('balancer activation');

    ax3=nexttile;
    plot(sim.always_bal.SoC_profile);
    title('ALWAYS BALANCING - SoC profile');
    xlabel("step(15min)");
    ax4=nexttile;
    plot(sim.always_bal.bal_activation_profile);
    title('balancer activation');
    linkaxes([ax1 ax3 ax2 ax4],'x')
end

if plot_check(2)
    %%%%%%% grafici SoC e bal affiancati
    %faccio un subplot per ogni horizon
    figure();
    add_label_metadata(sim,file_name, 'I_bal');
    n_lines = length(horizon_index);
    tiledlayout(length(horizon_index), 2);
    for i=1:length(horizon_index)
        ax1(i) = nexttile;
        plot(sim.opt_bal(i).SoC_profile);
        title(['OPTIMAL BALANCING - horizon length [h]: ', num2str(sim.opt_bal(horizon_index(i)).horizon), 'h - SoC profile']);
        xlabel("step(15min)");
        ax2(i) = nexttile;
        plot(sim.opt_bal(i).bal_activation_profile);
        title('balancer activation');
    end
    linkaxes([ax1 ax2], "x");

end
if plot_check(3)
    figure();
    add_label_metadata(sim,file_name, 'I_bal');
    n_lines = length(horizon_index);
    tiledlayout(2, length(horizon_index));
    for i=1:length(horizon_index)
        ax1(i) = nexttile(i);
        plot(sim.opt_bal(i).SoC_profile);
        title(['OPTIMAL BALANCING - horizon length [h]: ', num2str(sim.opt_bal(horizon_index(i)).horizon), 'h - SoC profile']);
        xlabel("step(15min)");
        ax2(i) = nexttile(i+length(horizon_index));
        plot(sim.opt_bal(i).bal_activation_profile);
        title('balancer activation');
    end
    linkaxes([ax1 ax2], "x");
end


%% ALWAYS - NO_BAL - HORIZON performance comparison
% elemento della struct my_out:
% id: 1   reference  c_nom = 400, C_var = 0.15, 
% id: 2:4 eff=0.7, i_bal= c/10,c/25,c/50
% id: 5:7 eff=0.9,  "       "   "   "
% id: 8     reference  c_nom = 400, C_var = 0.25, 
% id: 9:11  eff=0.7, i_bal= c/10,c/25,c/50
% id: 12:14 eff=0.9,  "       "   "   "

% ATTENTO A METTERE REF_INDEX CORRETTO !! se no non tornano i gain, che il
% caso no_bal non è quello giusto.
ref_sim_index = 8; %indice della simulazione fatta senza mismatch --> caso ideale
index_array = [12:14];  % indici della simulazioni da analizzare in my_out

sim_ref = my_out(ref_sim_index);
figure; tiledlayout(2,3);
legend_str = [""];
x_text_label = [""];
%queste celle contengono in posizione
% 1 -> NO_BAL
% 2..n -> optimal bal
% n+1 -> ALWAYS
% end (non c'è in tutti casi) --> IDEAL
wasted_energy = {};
wasted_energy_perc = {};
E_saved = {};
E_managed = {};
E_managed_gain = {};
E_provided = {};
E_provided_gain = {};
ss = {};
sc = {};
add_label_metadata(my_out(index_array(1)),file_name);
for j=1:length(index_array)
    index = index_array(j);
    sim = my_out(index);
    %%%%%%%%%%%%%%%%%%%%%%  Energia persa dal DCDC %%%%%%%%%%%%%%%%%%
    % non definito per IDEAL
    wasted_energy{j}(1) = sim_ref.no_bal.energy.E_lost; % NaN;
    wasted_energy_perc{j}(1) = sim_ref.no_bal.energy.E_lost / sim.always_bal.energy.E_lost; % NaN;
    x_text_label(1) = 'NO';
    for i=1:length(sim.opt_bal)
        wasted_energy{j}(end+1) = sim.opt_bal(i).energy.E_lost;
        wasted_energy_perc{j}(end+1) =  100 * sim.opt_bal(i).energy.E_lost / sim.always_bal.energy.E_lost;
        x_text_label(end+1) = num2str(sim.opt_bal(i).horizon);
    end
    wasted_energy{j}(end+1) = sim.always_bal.energy.E_lost;
    wasted_energy_perc{j}(end+1) = 100;
    x_text_label(end+1) = 'ALWAYS';
    x_text_label(end+1) = 'NEW BATTERY';

    nexttile(1); hold on;
    plot(wasted_energy{j}, '-*');
    title("DC/DC wasted energy [kWh]");
    xticks([1:length(wasted_energy{1})]); xticklabels(x_text_label);
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        MM       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% 
%     %%%%%%%%%%%%%%%%%%%%%%  Energia gestita totale %%%%%%%%%%%%%%%%%%
%     % Energia gestita "utile", ovvero integrale della potenza che
%     % entra/esce dalla batteria, al quale sottraggo la potenza persa dal
%     % DCDC
%     E_managed{j}(1) = sim_ref.no_bal.energy.E_batt;
%     for i=1:length(sim.opt_bal)
%         E_managed{j}(end+1) = sim.opt_bal(i).energy.E_batt - sim.opt_bal(i).energy.E_lost;
%     end
%     E_managed{j}(end+1) = sim.always_bal.energy.E_batt - sim.always_bal.energy.E_lost;
%     E_managed{j}(end+1) = sim_ref.ideal.energy.E_batt;   %sim_ref.ideal.energy.E_bd + abs(sim_ref.ideal.energy.E_bc);
% 
%     nexttile(2); hold on;
%     plot(E_managed{j}, '-*');
%     title("Total energy managed [KWh]");
%     xticks([1:length(E_managed{1})]); xticklabels(x_text_label);
% 
%     %%%%%%%%%%%%%%%%%%%%%%  guadagno in energia gestita %%%%%%%%%%%%%%%%%%
%     % calcolato rispetto al caso NO_BAL, è l'incremento percentuale in
%     % energia che riesco a gestire. Anche qui considero l'energia "utile",
%     % e sottraggo l'energia persa nel DCDC.
%     % OSS: non definito per IDEAL
%     E_managed_ref = sim_ref.no_bal.energy.E_batt;
% 
%     E_managed_gain{j}(1) = 0;   %no_bal
%     for i=1:length(sim.opt_bal)
%         E_managed_gain{j}(end+1) = 100*(sim.opt_bal(i).energy.E_batt - sim.opt_bal(i).energy.E_lost - E_managed_ref) / E_managed_ref;
%     end
%     E_managed_gain{j}(end+1) = 100*(sim.always_bal.energy.E_batt - sim.always_bal.energy.E_lost - E_managed_ref) /E_managed_ref;
%     nexttile(5); hold on;
%     plot(E_managed_gain{j}, '-*');
%     title("Energy managed gain [%] ");
%     xticks([1:length(E_managed_gain{1})]); xticklabels(x_text_label);

% %%%%%%%%%%%%%%%%%%%%%% guadagno netto dell'uso di una previsione su un orizzonte %%%%%%%%%%%%%%%%%%%%%%
%     %guadagno che c'è (se c'è...) tra usare opt_bal al posto di always
%     % non definito per NO_BAL e IDEAL
%     E_saved{j}(1) = NaN;
%     for i=1:length(sim.opt_bal)
%         % E_loss(i) = sim.always_bal.energy.E_lost - sim.opt_bal(i).energy.E_lost;      % alias premio
%         % E_not_managed(i) = sim.always_bal.energy.E_batt - sim.opt_bal(i).energy.E_batt;  % alias penalità
%         % E_saved{j}(end+1) = E_loss(i) - E_not_managed(i);
%         e_always_aux = (sim.always_bal.energy.E_batt - sim.always_bal.energy.E_lost);
%         e_opt_aux = (sim.opt_bal(i).energy.E_batt - sim.opt_bal(i).energy.E_lost);
%         E_saved{j}(end+1) = 100*(e_opt_aux - e_always_aux) / e_always_aux;
%     end
%     E_saved{j}(end+1) = NaN;
% 
%     nexttile(4); hold on;
%     plot(E_saved{j}, '-*');
%     title("optimal balancing VS always balancing gain [%]");
%     xticks([1:length(E_saved{1})]); xticklabels(x_text_label);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        end MM       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        RdR       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
    % %%%%%%%%%%%%%%%%%%%%%%  Energia fornita totale %%%%%%%%%%%%%%%%%%
    % versione RdR, energia fornita dalla batteria, che è il mio fattore di merito. In pratica è E_bd
    
    E_provided{j}(1) = sim_ref.no_bal.energy.E_bd;
    for i=1:length(sim.opt_bal)
        E_provided{j}(end+1) = sim.opt_bal(i).energy.E_bd;
    end
    E_provided{j}(end+1) = sim.always_bal.energy.E_bd;
    E_provided{j}(end+1) = sim_ref.ideal.energy.E_bd;   %sim_ref.ideal.energy.E_bd + abs(sim_ref.ideal.energy.E_bc);

    nexttile(2); hold on;
    plot(E_provided{j}, '-*');
    title("Total energy provided (E_{bd}) [KWh]");
    xticks([1:length(E_provided{1})]); xticklabels(x_text_label);

    % %%%%%%%%%%%%%%%%%%%%%%  guadagno in energia fornita totale %%%%%%%%%%%%%%%%%%
    % versione RdR, energia fornita dalla batteria, che è il mio fattore di merito. In pratica è E_bd
    % % OSS: non definito per IDEAL
    E_provided_ref = sim_ref.no_bal.energy.E_bd;
    E_provided_gain{j}(1) = 0;   %no_bal
    for i=1:length(sim.opt_bal)
        E_provided_gain{j}(end+1) = 100*(sim.opt_bal(i).energy.E_bd - E_provided_ref) / E_provided_ref;
    end
    E_provided_gain{j}(end+1) = 100*(sim.always_bal.energy.E_bd - E_provided_ref) /E_provided_ref;
    nexttile(5); hold on;
    plot(E_provided_gain{j}, '-*');
    title("Energy provided gain (E_{bd}) [%] ");
    xticks([1:length(E_provided_gain{1})]); xticklabels(x_text_label);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    


%%%%%%%%%%%%%%%%%%%%%% guadagno netto dell'uso di una previsione su un orizzonte %%%%%%%%%%%%%%%%%%%%%%
    %guadagno che c'è (se c'è...) tra usare opt_bal al posto di always
    % non definito per NO_BAL e IDEAL
    E_saved{j}(1) = NaN;
    for i=1:length(sim.opt_bal)
        E_saved{j}(end+1) = 100* (sim.opt_bal(i).energy.E_bd - sim.always_bal.energy.E_bd) / sim.always_bal.energy.E_bd;
    end
    E_saved{j}(end+1) = NaN;

    nexttile(4); hold on;
    plot(E_saved{j}, '-*');
    title("optimal balancing VS always balancing gain [%]");
    xticks([1:length(E_saved{1})]); xticklabels(x_text_label);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        end RdR       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

    %%%%%%%%%%%%%%%%%%%%%%  self consumption %%%%%%%%%%%%%%%%%%
    sc{j}(1) = sim_ref.no_bal.sc;
    for i=1:length(sim.opt_bal)
        sc{j}(end+1) = sim.opt_bal(i).sc;
    end
    sc{j}(end+1) = sim.always_bal.sc;
    sc{j}(end+1) = sim_ref.ideal.sc;

    nexttile(3); hold on;
    plot(sc{j}, '-*');
    title("self consumption [%]");
    xticks([1:length(sc{1})]); xticklabels(x_text_label);

    %%%%%%%%%%%%%%%%%%%%%%  self sufficiency %%%%%%%%%%%%%%%%%%
    ss{j}(1) = sim_ref.no_bal.ss;
    for i=1:length(sim.opt_bal)
        ss{j}(end+1) = sim.opt_bal(i).ss;
    end
    ss{j}(end+1) = sim.always_bal.ss;
    ss{j}(end+1) = sim_ref.ideal.ss;

    nexttile(6); hold on;
    plot(ss{j}, '-*');
    title("self sufficiency [%]");
    xticks([1:length(ss{1})]); xticklabels(x_text_label);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    legend_str(j) = sim.I_bal_str;
end
legend(legend_str);

%% local functions

function add_label_metadata(sim,file_name, varargin)
% if length(varargin) == 0  % c'è I_bal
%
%       metadata = sprintf('METADATA: start=%d, lenght=%d, Cnom=%.1f, Cvar=%d%%, eff=%.1f - %s', sim.system.sim_start_day, sim.system.sim_days, sim.batt.c_nom, sim.batt.c_var*100, sim.eff, file_name);
% elseif length(varargin) >= 1
%     I_bal = varargin{1};
%     metadata = sprintf('METADATA: start=%d, lenght=%d, Cnom=%.1f, Cvar=%d%%, Ibal=%s, eff=%.1f - %s', sim.system.sim_start_day, sim.system.sim_days, sim.batt.c_nom, sim.batt.c_var*100, sim.I_bal_str, sim.eff, file_name);
% else
%     metadata = sprintf('error in metadata function');
% end
%

%%%%%%%%%
metadata = sprintf("METADATA: start=%d, lenght=%d, Cnom=%.1f, Cvar=%d%%, eff=%.1f, ", sim.system.sim_start_day, sim.system.sim_days, sim.batt.c_nom, sim.batt.c_var*100, sim.eff);
for i=1:length(varargin)
    switch varargin{i}
        case 'I_bal'
            aux_str = sprintf("Ibal=%s, ",sim.I_bal_str);
            metadata = strcat(metadata,aux_str);
        otherwise
            metadata = 'parametro per funzione add_metadata errato';
    end
end
metadata = strcat(metadata,file_name); %
txt_pos = [0.001 0.9 0.1 0.1];
txt = annotation('textbox',txt_pos, 'String',metadata);
end

function out = extract_month_data(in, month)
% partendo da "in" che sono i dati di un semestre, estraggo i dati di un
% singolo mese 1=gennaio, 2=febbraio... "out" è una la struct come in, solo
% che i timeseries sono "ritagliati" per il mese interessato

timeseries_sampling_time = 10; % [s]
out = in;

t_start = (month-1)*30*24*3600/timeseries_sampling_time + 1; % la potenza di uscita è campionata ogni 10 secondi
t_end = (month)*30*24*3600/10;
out.IDEAL.P_in = getsamples(in.IDEAL.P_in, t_start:t_end); % gli elementi di un timeseries sono relativi al tempo
out.IDEAL.P_out = getsamples(in.IDEAL.P_out, t_start:t_end);
out.IDEAL.P_bc = getsamples(in.IDEAL.P_bc, t_start:t_end);
out.IDEAL.P_bd = getsamples(in.IDEAL.P_bd, t_start:t_end);
out.IDEAL.SoC =  getsamples(in.IDEAL.SoC, t_start:t_end);

t_start2 = (month-1)*30*24*3600/900 +1;      % i profili di ingresso sono campionati ogni 900 secondi
t_end2 = (month)*30*24*3600/900;
out.profile.power_timeseries = getsamples(in.profile.power_timeseries,t_start2:t_end2);
out.profile.load_power_timeseries = getsamples(in.profile.load_power_timeseries,t_start2:t_end2);
out.profile.PV_power_timeseries = getsamples(in.profile.PV_power_timeseries,t_start2:t_end2);

out.sim_dur = 30;
out.d = (month-1)*30+1;
months_list = ["January", "February", "March", "April", "May", "June", ...
    "July", "August", "September", "October", "November", "December"];
out.month = months_list(month);
end