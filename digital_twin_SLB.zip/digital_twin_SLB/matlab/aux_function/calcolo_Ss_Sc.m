%% CONTENUTO FILE .MAT
% --> "data/output/calcolo_SS_SC.mat"
%       - simulazioni divise per mese da gennaio a luglio, e poi simulazione semestrale
%       unica. con Cnom=[200,400,500,600], e P-pk=[7.15,5].
%       - ci sono solo le energie finali per ciascun mese, ma non i profili di potenza
%       - sono 60 simulazioni(4*cnom,6*mesi,2*P_pk). gli indici 29:32 sono
%       per le semestrali.

% --> "data\output\calcolo_SS_SC_semestre.mat"
%       - simulazioni semestre per Cnom=[100,200,300,400,500,600] e P_pk =
%       [5,7].
%       - sono 12 simulazioni (6*c_nom, 2*P_pk)
%       - ci sono i timeseries per SoC,P_in,P_out,P_bc,P_bd,P_load,P_pv per
%       tutto il semestre, e con la funzione extract_month_data mi estraggo
%       una struct con i dati solo di quel mese. I valori di energia sel
%       singolo mese me li devo poi calcolare integrando.

%% LOAD
%file_name = "data/output/calcolo_SS_SC.mat";
file_name = "data/output/calcolo_SS_SC_semestre.mat";
fprintf("loading...\n");
tic;
load(file_name);
fprintf("LOADED: %s \t elapsed:%.1f sec\n", file_name, toc)
%% simulazione per Self-sufficiency e self-consumption partendo da modello batteria ideale no_bal
DC2C = 1;
C2P = 2;
P2C = 3;
Ncell=10;
Vnom = 3.65;

% configurazioni base
base_config.start_day = 90;    %aprile
base_config.sim_dur_day = 30;   %tutto il mese
base_config.mode = DC2C;
base_config.eff= 0.90;
base_config.C_nom = battery_capacity_KWh*1e3/(Ncell*Vnom);
base_config.P_pk = 7.15; % ex GIS magic number
base_config.C_var = 0.20;
base_config.I_bal = base_config.C_nom/5;
base_config.SoC_H = 0.90;  % soglia di attivazione del supervisor
base_config.SoC_L = 0.10;
base_config.horizon = NaN;  %(h)

base_config.file_name = "data/output/calcolo_SS_SC_semestre.mat";

base_config.sim_dur_day = 180;
base_config.start_day = 1;

base_config.P_pk = 7;
c_batt = [100,200,300,400,500,600];

for j=1:length(c_batt)
    base_config.C_nom = c_batt(j);
    run_model_ideal_nostep(base_config, PV_profile, load_profile_r);   %ideale
end

base_config.P_pk = 5;

for j=1:length(c_batt)
    base_config.C_nom = c_batt(j);
    run_model_ideal_nostep(base_config, PV_profile, load_profile_r);   %ideale
end

% c_batt = [200,400,500,600];
% start_days = [1,32,60,91,121,152,182]; %gennaio, febbraio,..., luglio.
% base_config.sim_dur_day = 30;
% for i=1:length(start_days)
%     base_config.start_day = start_days(i);
%     for j=1:length(c_batt)
%         base_config.C_nom = c_batt(j);
%         run_model_ideal_nostep(base_config, PV_profile, load_profile_r);   %ideale
%     end
% end

% base_config.start_day = 1;
% base_config.sim_dur_day = 180;  % simulazione semestre
% for j=1:length(c_batt)
%         base_config.C_nom = c_batt(j);
%         run_model_ideal_nostep(base_config, PV_profile, load_profile_r);   %ideale
% end
%
% % CAMBIO IL MAGIC NUMBER E RIPETO LE SIMULAZIONI
% GIS_magic_coeff = 5; %7.15; %[m^2], tiene conto di perdite
% PV_profile.P = GIS_magic_coeff*PV_profile.I/1e3; %[KW]
%
% base_config.sim_dur_day = 30;
% for i=1:length(start_days)
%     base_config.start_day = start_days(i);
%     for j=1:length(c_batt)
%         base_config.C_nom = c_batt(j);
%         run_model_ideal_nostep(base_config, PV_profile, load_profile_r);   %ideale
%     end
% end

%% calcolo Self-sufficiency e self-consumption - solo per "data/output/calcolo_SS_SC.mat"

%calcolo Ss e Sc per ogni elemento del file
for i=1:length(my_out)

    out_sel = my_out(i);

    E_in = out_sel.IDEAL.E_in;
    E_out= abs(out_sel.IDEAL.E_out);
    E_du = out_sel.IDEAL.E_du;
    E_bc = abs(out_sel.IDEAL.E_bc);
    E_bd = out_sel.IDEAL.E_bd;

    E_pv = out_sel.IDEAL.E_pv;
    E_load = out_sel.IDEAL.E_load;

    E_pv2 = E_du + E_bc + E_out;
    E_load2 = E_du + E_bd + E_in;

    Sc(i) = 100 * (E_du + E_bc) / E_pv;
    Ss(i) = 100 * (E_du + E_bd) / E_load ;

    %fprintf("file_name: %s, simID=%i, start day:%i sim dur:%i days, C_nom=%.1fAh Sc = %.2f%%, Ss = %.2f%% \n", file_name, index, out_sel.d, out_sel.sim_dur, out_sel.batt.c_nom, Sc(i), Ss(i));
end

%% plot Sc Ss per i vari mesi "data/output/calcolo_SS_SC.mat";

% scelgo le structs [1:60] che mi interessa analizzare
% 1:28 a gruppi di 4(le varie Cnom), sono i mesi da gennaio a luglio. Con
% p_pk=7.15
% 33:60 a gruppi di 4(le varie Cnom), sono i mesi da gennaio a luglio. Con
% p_pk= 5

i_start = 1;%33; %1;
i_end = 28;%60; %28;
C200_i = i_start   : 4 : i_end;
C400_i = i_start+1 : 4 : i_end;
C500_i = i_start+2 : 4 : i_end;
C600_i = i_start+3 : 4 : i_end;

Sc_200 = Sc(C200_i);
Sc_400 = Sc(C400_i);
Sc_500 = Sc(C500_i);
Sc_600 = Sc(C600_i);

Ss_200 = Ss(C200_i);
Ss_400 = Ss(C400_i);
Ss_500 = Ss(C500_i);
Ss_600 = Ss(C600_i);

figure;
if isfield(out_sel.system, 'P_pk')
    P_pk = out_sel.system.P_pk;
else
    P_pk = NaN;
end
metadata = sprintf("Ppk= %.2f KW",P_pk);
txt_pos = [0.001 0.9 0.1 0.1];
txt = annotation('textbox',txt_pos, 'String',metadata);
tiledlayout(2,1);
nexttile;

hold on
plot(Sc_200);
% plot(Sc_400);
% plot(Sc_500);
% plot(Sc_600);
legend("200Ah", "400Ah","500Ah","600Ah");
title("Self consumption");
xticks([1,2,3,4,5,6,7,8])
ylim([0 100]);
yticks([0, 25, 50, 75, 100])
xticklabels(["gennaio", "febbraio", "marzo","aprile","maggio","giugno","luglio", "semestre"]);

nexttile;
hold on
plot(Ss_200);
% plot(Ss_400);
% plot(Ss_500);
% plot(Ss_600);
title("Self sufficiency")
legend("200Ah", "400Ah","500Ah","600Ah");
xticks([1,2,3,4,5,6,7,8])
ylim([0 100]);
yticks([0, 25, 50, 75, 100])
xticklabels(["gennaio", "febbraio", "marzo","aprile","maggio","giugno","luglio", "semestre"]);



%% calcolo Ss Sc (solo per file_name = "data/output/calcolo_SS_SC_semestre.mat")
sim_index = 1:6; %indice simulazione

figure;
tiledlayout(2,1);
for i=1:length(sim_index)
    selected_sim = my_out(sim_index(i));

    for choosen_month=1:6
        out_sel = extract_month_data(selected_sim,choosen_month);

        P_bc = out_sel.IDEAL.P_bc;
        P_bd = out_sel.IDEAL.P_bd;
        P_pv = out_sel.profile.PV_power_timeseries;
        P_load = out_sel.profile.load_power_timeseries;

        P_load_tmp = P_load.Data';
        P_pv_tmp = P_pv.Data';

        % implemento la funzione(che è praticamente la ricerca e selezione del minimo):
        %   IF P_load<P_pv
        %       p_du = P_load
        %   ELSE
        %       P_du = P_pv

        P_du_tmp = min([P_load_tmp; P_pv_tmp])';
        P_du = timeseries(P_du_tmp, out_sel.profile.load_power_timeseries.Time);

        E_du = trapz(P_du.Time,P_du.Data)/3600; %[Wh]
        E_pv = trapz(P_pv.Time,P_pv.Data)/3600;
        E_load = trapz(P_load.Time,P_load.Data)/3600;
        E_bc = trapz(P_bc.Time,P_bc.Data)/3600;
        E_bd = trapz(P_bd.Time,P_bd.Data)/3600;

        Sc(choosen_month) = 100 * (E_du + abs(E_bc)) / E_pv;
        Ss(choosen_month) = 100 * (E_du + E_bd) / E_load ;
    end
    nexttile(1); hold on;
    plot(Sc);
    legend("100Ah","200Ah","300Ah", "400Ah","500Ah","600Ah");
    title("Self consumption");
    xticks([1,2,3,4,5,6,7,8])
    ylim([0 100]);
    yticks([0, 25, 50, 75, 100])
    xticklabels(["gennaio", "febbraio", "marzo","aprile","maggio","giugno","luglio"]);
    ylabel("%");

    nexttile(2); hold on;
    plot(Ss);
    legend("100Ah","200Ah","300Ah", "400Ah","500Ah","600Ah");
    title("Self sufficiency");
    xticks([1,2,3,4,5,6,7,8])
    ylim([0 100]);
    yticks([0, 25, 50, 75, 100])
    xticklabels(["gennaio", "febbraio", "marzo","aprile","maggio","giugno","luglio"]);
    ylabel("%");

    metadata = sprintf(' day start=%d,  sim dur=%d, PV=%.2f kW', out_sel.d, out_sel.sim_dur, out_sel.system.P_pk);
    txt_pos = [0.001 0.9 0.1 0.1];
    txt = annotation('textbox',txt_pos, 'String',metadata);

    Sc_aux(i,:)=Sc;   
    Ss_aux(i,:)=Ss;
end

figure;
tiledlayout(2,1)

% Top bar graph
ax1 = nexttile;
bar(ax1,Sc_aux')

% Bottom bar graph
ax2 = nexttile;
bar(ax2,Ss_aux)

%% plot power profiles  (solo per file_name = "data/output/calcolo_SS_SC_semestre.mat")
index = 4; %indice simulazione
semester = true;
choosen_month = 2; %[1:6]

if semester == true
    out_sel = my_out(index);
else
    out_sel = extract_month_data(my_out(index),choosen_month);
end

if isfield(out_sel.system, 'P_pk')
    P_pk = out_sel.system.P_pk;
else
    P_pk = NaN;
end

if isfield(out_sel, 'month')
    month = out_sel.month;
else
    month = NaN;
end

metadata = sprintf(' day start=%d, month:%s sim dur=%d, Cnom=%.1f Ah, PV=%.2f kW', out_sel.d, month, out_sel.sim_dur, out_sel.C_nom,P_pk);
txt_pos = [0.001 0.9 0.1 0.1];

figure;
tiledlayout(3,2);
txt = annotation('textbox',txt_pos, 'String',metadata);

ax1 = nexttile(1); hold on;
plot(out_sel.profile.load_power_timeseries - out_sel.profile.PV_power_timeseries);
window_size = 96; % n. di campioni, essendo quelli di load_power_timeseries ogni 900s
filtered_profile = movmean(out_sel.profile.load_power_timeseries.Data - out_sel.profile.PV_power_timeseries.Data, window_size);
filtered_profile_ts = timeseries(filtered_profile,out_sel.profile.load_power_timeseries.Time);
plot(filtered_profile_ts);
title("Load - PV"); ylabel("[W]"); legend("LOAD-PV","filtered 24h");

ax2 = nexttile(3);
plot(out_sel.IDEAL.P_in);
title("P grid bought");ylabel("[W]");

ax3 = nexttile(5);
plot(out_sel.IDEAL.P_out);
title("P grid sold");ylabel("[W]");

ax4 = nexttile(2);
plot(out_sel.IDEAL.SoC);
title("SoC");ylabel("[W]");

ax5 = nexttile(4);
plot(out_sel.IDEAL.P_bc);
title("P battery charge");ylabel("[W]");

ax6 = nexttile(6);
plot(out_sel.IDEAL.P_bd);
title("P battery discharge");ylabel("[%]");

if semester == true
    xticks(ax4,[1 : 30*24*3600 : out_sel.IDEAL.P_bd.Time(end)])
    xticklabels(ax4,["gennaio", "febbraio", "marzo","aprile","maggio","giugno","luglio"]);
    xticks(ax1,[1 : 30*24*3600 : out_sel.IDEAL.P_bd.Time(end)])
    xticklabels(ax1,["gennaio", "febbraio", "marzo","aprile","maggio","giugno","luglio"]);
else
    out_sel = extract_month_data(my_out(index),choosen_month);
end


linkaxes([ax1 ax2 ax3 ax4 ax5 ax6], 'x')

%% plot SoC (solo per file_name = "data/output/calcolo_SS_SC_semestre.mat")
index = 4;
i = index;

figure;
metadata = sprintf(' day start=%d, sim dur=%d, Cnom=%.1f Ah', my_out(index).d, my_out(index).sim_dur, my_out(index).C_nom);
txt_pos = [0.001 0.9 0.1 0.1];
txt = annotation('textbox',txt_pos, 'String',metadata);
plot(my_out(i).IDEAL.SoC);
ylabel("SoC %")
xticks([1 : 30*24*3600 : my_out(i).IDEAL.SoC.Time(end)])
xticklabels(["gennaio", "febbraio", "marzo","aprile","maggio","giugno","luglio"]);


%% reshape e trasforma vettore in timeseries riducendone la dimensione

aa = my_out(i).IDEAL.SoC(13:end);
aa_reshaped = reshape(aa, 10, []); % fattore di rimpicciolimento
aa_reduced = mean(aa_reshaped,1);
aa_reduced(end+1) = aa_reduced(end);
my_out(i).IDEAL.SoC = timeseries(aa_reduced', bb);

%% local function extract_month_data

function out = extract_month_data(in, month)
% partendo da "in" che sono i dati di un semestre, estraggo i dati di un
% singolo mese 1=gennaio, 2=febbraio... "out" è una la struct come in, solo
% che i timeseries sono "ritagliati" per il mese interessato

out = in;

t_start = (month-1)*30*24*3600/10 +1; % la potenza di uscita è campionata ogni 10 secondi
t_end = (month)*30*24*3600/10;
out.IDEAL.P_in = getsamples(in.IDEAL.P_in, t_start:t_end); % gli elementi di un timeseries sono relativi al tempo
out.IDEAL.P_out = getsamples(in.IDEAL.P_out, t_start:t_end);
out.IDEAL.P_bc = getsamples(in.IDEAL.P_bc, t_start:t_end);
out.IDEAL.P_bd = getsamples(in.IDEAL.P_bd, t_start:t_end);
out.IDEAL.SoC =  getsamples(in.IDEAL.SoC, t_start:t_end);

t_start2 = (month-1)*30*24*3600/900 +1;      % i profili di ingresso sono campionati ogni 900 secondi
t_end2 = (month)*30*24*3600/900;
out.profile.power_timeseries = getsamples(in.profile.power_timeseries,t_start2:t_end2);
out.profile.load_power_timeseries = getsamples(in.profile.load_power_timeseries,t_start2:t_end2);
out.profile.PV_power_timeseries = getsamples(in.profile.PV_power_timeseries,t_start2:t_end2);

out.sim_dur = 30;
out.d = (month-1)*30+1;
months_list = ["January", "February", "March", "April", "May", "June", ...
    "July", "August", "September", "October", "November", "December"];
out.month = months_list(month);
end