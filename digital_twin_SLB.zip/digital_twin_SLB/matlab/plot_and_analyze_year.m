%% JOIN data from different months
%creo una matrice dove la prima dimensione(righe), sono i dati per i vari
%mesi, nella seconda dimensione (colonne), ci sono i risultati delle
%simulazioni per vari parametri (es. I_bal/C_var/eff), e poi ogni elemento
%è una struct con i campi NO_BAL/ALWAYS/OPT/IDEAL

% elemento della struct my_out:
% id: 1   reference  c_nom = 400, C_var = 0.15,
% id: 2:5 eff=0.7, i_bal= c/5, c/10,c/25,c/50
% id: 6:8 eff=0.9,  "       "   "   "
% id: 9     reference  c_nom = 400, C_var = 0.25,
% id: 10:13  eff=0.7, i_bal= c/5, c/10,c/25,c/50
% id: 14:16 eff=0.9,  "       "   "   "
% id: 17   reference  c_nom = 400, C_var = 0.25, ### alarm_soc_bal = 10/90% ### (per vedere se in questo modo si riducono le scariche parziali a giugno/luglio, e valorizzo opt_bal)
% id: 18:20  eff=0.7, i_bal= c/10,c/25,c/50
% id: 21   reference  c_nom = 400, C_var = 0.35,
% id: 22:25  eff=0.7, i_bal= c/5,c/10,c/25,c/50

clear;

%NB: tutti i file devono avere i dati ordinati allo stesso modo!!
file_name_list = ["data/output/gennaio.mat",
    "data/output/febbraio.mat",
    "data/output/marzo.mat",
    "data/output/aprile.mat",
    "data/output/maggio.mat",
    "data/output/giugno.mat",
    "data/output/luglio.mat",
    "data/output/agosto.mat",
    "data/output/settembre.mat",
    "data/output/ottobre.mat",
    "data/output/novembre.mat",
    "data/output/dicembre.mat"];
%file_name_list = ["data/output/gennaio.mat","data/output/febbraio.mat","data/output/marzo.mat"];
ref_sim_index = [1,9,17,21]; %indice della simulazione NO_BAL e IDEAL
index_array = [2:8,10:16,18:20,22:25];  % indici della simulazioni da inserire in sim_year

sim_year = [];

for month=1:length(file_name_list)
    tic;
    fprintf("loading: %s \t ", file_name_list(month))
    load(file_name_list(month))
    fprintf(" -> DONE, elapsed:%.1f sec\n", toc);
    for j=1:length(my_out)
        if any(ref_sim_index == j)
            fprintf("%i is in reference_sim_index\n", j);
            sim_year(month,j).no_bal.energy = my_out(j).no_bal.energy;
            sim_year(month,j).no_bal.ss     = my_out(j).no_bal.ss;
            sim_year(month,j).no_bal.sc     = my_out(j).no_bal.sc;

            sim_year(month,j).ideal.energy  = my_out(j).ideal.energy;
            sim_year(month,j).ideal.ss      = my_out(j).ideal.ss;
            sim_year(month,j).ideal.sc      = my_out(j).ideal.sc;

        else
            sim_year(month,j).always_bal.energy = my_out(j).always_bal.energy;
            sim_year(month,j).always_bal.ss     = my_out(j).always_bal.ss;
            sim_year(month,j).always_bal.sc     = my_out(j).always_bal.sc;

            for h=1: length(my_out(j).opt_bal)
                sim_year(month,j).opt_bal(h).energy = my_out(j).opt_bal(h).energy;
                sim_year(month,j).opt_bal(h).ss     = my_out(j).opt_bal(h).ss;
                sim_year(month,j).opt_bal(h).sc     = my_out(j).opt_bal(h).sc;
                sim_year(month,j).opt_bal(h).horizon= my_out(j).opt_bal(h).horizon;
            end

        end
        % add metadata
        sim_year(month,j).c_nom     = my_out(j).c_nom;
        sim_year(month,j).c_var     = my_out(j).c_var;
        sim_year(month,j).I_bal     = my_out(j).I_bal;
        sim_year(month,j).I_bal_str = my_out(j).I_bal_str;
        sim_year(month,j).eff       = my_out(j).eff;

    end
end
%save("data/output/year_400Ah.mat", "sim_year" )

% %% SPLIT year data struct into different struct (NO_BAL_YEAR, ALWAYS_YEAR...)
% file_name =  "data/output/year_400Ah.mat";
% %file_name =  "data/output/year_200Ah.mat";
% load(file_name)
%
% % nella dimensione 1(raw) di sim_year ci sono i vari mesi
% % nella dimensione 2(col) di sim_year ci sono i vari scenari, al variare di
% % i_bal, eff, c_var... tra questi ci sono anche i reference scenario
% % es.
% %          ref   scen_1   scen_2   scen_3
% %   gen |  --  |   --   |   --   |   --   |
% %   feb |  --  |   --   |   --   |   --   |
% %   marz|  --  |   --   |   --   |   --   |
%
% % colonna: 1   reference  c_nom = 400, C_var = 0.15,
% % colonna: 2:4 eff=0.7, i_bal= c/10,c/25,c/50
% % colonna: 5:7 eff=0.9,  "       "   "   "
% % colonna: 8     reference  c_nom = 400, C_var = 0.25,
% % colonna: 9:11  eff=0.7, i_bal= c/10,c/25,c/50
% % colonna: 12:14 eff=0.9,  "       "   "   "
%
%
% % NB: ref_scenario deve essere coerente con le impostazioni di id_scenario,
% %
% ref_scenario = 21;
% id_scenario = [22:25];
%
% %le variabili estratte dal semestre le creo usando una riga per ogni
% %scenario, e poi le variabili sono vettori con un elemento per mese.
% % Opt_bal in aggiunta ha una colonna per ogni horizon
%
% no_bal_year = []; % variabili estratte semestrali
% ideal_year = [];
% always_bal_year = [];
% opt_bal_year = [];
% aux_cmp = [];
%
% for i=1:length(id_scenario)
%     sel = id_scenario(i);
%     for month=1:size(sim_year,1)
%         no_bal_year(i).energy.E_load(month)       = sim_year(month,ref_scenario).no_bal.energy.E_load;
%         no_bal_year(i).energy.E_pv(month)         = sim_year(month,ref_scenario).no_bal.energy.E_pv;
%         no_bal_year(i).energy.E_batt(month)       = sim_year(month,ref_scenario).no_bal.energy.E_batt;
%         no_bal_year(i).energy.E_du(month)         = sim_year(month,ref_scenario).no_bal.energy.E_du;
%         no_bal_year(i).energy.E_bc(month)         = sim_year(month,ref_scenario).no_bal.energy.E_bc;
%         no_bal_year(i).energy.E_bd(month)         = sim_year(month,ref_scenario).no_bal.energy.E_bd;
%         no_bal_year(i).energy.E_grid_out(month)   = sim_year(month,ref_scenario).no_bal.energy.E_grid_out;
%         no_bal_year(i).energy.E_grid_in(month)    = sim_year(month,ref_scenario).no_bal.energy.E_grid_in;
%         no_bal_year(i).energy.E_balanced(month)   = sim_year(month,ref_scenario).no_bal.energy.E_balanced;
%         no_bal_year(i).energy.E_lost(month)       = sim_year(month,ref_scenario).no_bal.energy.E_lost;
%         no_bal_year(i).ss(month)                  = sim_year(month,ref_scenario).no_bal.ss;
%         no_bal_year(i).sc(month)                  = sim_year(month,ref_scenario).no_bal.sc;
%
%         % controllo che per i vari mesi ci siano gli stessi metadata, in
%         % modo da esser sicuro che le simulazioni sono coerenti per gli
%         % input
%         if month == 1
%             no_bal_year(i).metadata.c_nom      = sim_year(month,ref_scenario).c_nom;
%             no_bal_year(i).metadata.c_var      = sim_year(month,ref_scenario).c_var;
%             no_bal_year(i).metadata.I_bal      = sim_year(month,ref_scenario).I_bal;
%             no_bal_year(i).metadata.I_bal_str  = sim_year(month,ref_scenario).I_bal_str;
%             no_bal_year(i).metadata.eff        = sim_year(month,ref_scenario).eff;
%         else
%             aux_cmp(1) = no_bal_year(i).metadata.c_nom      - sim_year(month,ref_scenario).c_nom;
%             aux_cmp(2) = no_bal_year(i).metadata.c_var      - sim_year(month,ref_scenario).c_var;
%             if any(aux_cmp ~= 0)
%                 error "simulazioni con metadata diversi"
%             end
%         end
%
%         ideal_year(i).energy.E_load(month)       = sim_year(month,ref_scenario).ideal.energy.E_load;
%         ideal_year(i).energy.E_pv(month)         = sim_year(month,ref_scenario).ideal.energy.E_pv;
%         ideal_year(i).energy.E_batt(month)       = sim_year(month,ref_scenario).ideal.energy.E_batt;
%         ideal_year(i).energy.E_du(month)         = sim_year(month,ref_scenario).ideal.energy.E_du;
%         ideal_year(i).energy.E_bc(month)         = sim_year(month,ref_scenario).ideal.energy.E_bc;
%         ideal_year(i).energy.E_bd(month)         = sim_year(month,ref_scenario).ideal.energy.E_bd;
%         ideal_year(i).energy.E_grid_out(month)   = sim_year(month,ref_scenario).ideal.energy.E_grid_out;
%         ideal_year(i).energy.E_grid_in(month)    = sim_year(month,ref_scenario).ideal.energy.E_grid_in;
%         ideal_year(i).energy.E_balanced(month)   = sim_year(month,ref_scenario).ideal.energy.E_balanced;
%         ideal_year(i).energy.E_lost(month)       = sim_year(month,ref_scenario).ideal.energy.E_lost;
%         ideal_year(i).ss(month)                  = sim_year(month,ref_scenario).ideal.ss;
%         ideal_year(i).sc(month)                  = sim_year(month,ref_scenario).ideal.sc;
%         if month == 1
%             ideal_year(i).metadata.c_nom      = sim_year(month,ref_scenario).c_nom;
%             ideal_year(i).metadata.c_var      = sim_year(month,ref_scenario).c_var;
%             ideal_year(i).metadata.I_bal      = sim_year(month,ref_scenario).I_bal;
%             ideal_year(i).metadata.I_bal_str  = sim_year(month,ref_scenario).I_bal_str;
%             ideal_year(i).metadata.eff        = sim_year(month,ref_scenario).eff;
%         else
%             aux_cmp(1) = ideal_year(i).metadata.c_nom - sim_year(month,ref_scenario).c_nom;
%             aux_cmp(2) = ideal_year(i).metadata.c_var - sim_year(month,ref_scenario).c_var;
%             if any(aux_cmp ~= 0)
%                 error simulazioni con metadata diversi
%             end
%         end
%         always_bal_year(i).energy.E_load(month)       = sim_year(month,sel).always_bal.energy.E_load;
%         always_bal_year(i).energy.E_pv(month)         = sim_year(month,sel).always_bal.energy.E_pv;
%         always_bal_year(i).energy.E_batt(month)       = sim_year(month,sel).always_bal.energy.E_batt;
%         always_bal_year(i).energy.E_du(month)         = sim_year(month,sel).always_bal.energy.E_du;
%         always_bal_year(i).energy.E_bc(month)         = sim_year(month,sel).always_bal.energy.E_bc;
%         always_bal_year(i).energy.E_bd(month)         = sim_year(month,sel).always_bal.energy.E_bd;
%         always_bal_year(i).energy.E_grid_out(month)   = sim_year(month,sel).always_bal.energy.E_grid_out;
%         always_bal_year(i).energy.E_grid_in(month)    = sim_year(month,sel).always_bal.energy.E_grid_in;
%         always_bal_year(i).energy.E_balanced(month)   = sim_year(month,sel).always_bal.energy.E_balanced;
%         always_bal_year(i).energy.E_lost(month)       = sim_year(month,sel).always_bal.energy.E_lost;
%         always_bal_year(i).ss(month)                  = sim_year(month,sel).always_bal.ss;
%         always_bal_year(i).sc(month)                  = sim_year(month,sel).always_bal.sc;
%         if month == 1
%             always_bal_year(i).metadata.c_nom      = sim_year(month,sel).c_nom;
%             always_bal_year(i).metadata.c_var      = sim_year(month,sel).c_var;
%             always_bal_year(i).metadata.I_bal      = sim_year(month,sel).I_bal;
%             always_bal_year(i).metadata.I_bal_str  = sim_year(month,sel).I_bal_str;
%             always_bal_year(i).metadata.eff        = sim_year(month,sel).eff;
%         else
%             aux_cmp(1) = always_bal_year(i).metadata.c_nom - sim_year(month,sel).c_nom;
%             aux_cmp(2) = always_bal_year(i).metadata.c_var - sim_year(month,sel).c_var;
%             aux_cmp(3) = always_bal_year(i).metadata.I_bal - sim_year(month,sel).I_bal;
%             aux_cmp(4) = always_bal_year(i).metadata.eff   - sim_year(month,sel).eff;
%             if any(aux_cmp ~= 0)
%                 error simulazioni con metadata diversi
%             end
%         end
%         for h=1:length(sim_year(month,sel).opt_bal)
%             opt_bal_year(i,h).energy.E_load(month)       = sim_year(month,sel).opt_bal(h).energy.E_load;
%             opt_bal_year(i,h).energy.E_pv(month)         = sim_year(month,sel).opt_bal(h).energy.E_pv;
%             opt_bal_year(i,h).energy.E_batt(month)       = sim_year(month,sel).opt_bal(h).energy.E_batt;
%             opt_bal_year(i,h).energy.E_du(month)         = sim_year(month,sel).opt_bal(h).energy.E_du;
%             opt_bal_year(i,h).energy.E_bc(month)         = sim_year(month,sel).opt_bal(h).energy.E_bc;
%             opt_bal_year(i,h).energy.E_bd(month)         = sim_year(month,sel).opt_bal(h).energy.E_bd;
%             opt_bal_year(i,h).energy.E_grid_out(month)   = sim_year(month,sel).opt_bal(h).energy.E_grid_out;
%             opt_bal_year(i,h).energy.E_grid_in(month)    = sim_year(month,sel).opt_bal(h).energy.E_grid_in;
%             opt_bal_year(i,h).energy.E_balanced(month)   = sim_year(month,sel).opt_bal(h).energy.E_balanced;
%             opt_bal_year(i,h).energy.E_lost(month)       = sim_year(month,sel).opt_bal(h).energy.E_lost;
%             opt_bal_year(i,h).ss(month)                  = sim_year(month,sel).opt_bal(h).ss;
%             opt_bal_year(i,h).sc(month)                  = sim_year(month,sel).opt_bal(h).sc;
%             if month == 1
%                 opt_bal_year(i,h).metadata.c_nom      = sim_year(month,sel).c_nom;
%                 opt_bal_year(i,h).metadata.c_var      = sim_year(month,sel).c_var;
%                 opt_bal_year(i,h).metadata.I_bal      = sim_year(month,sel).I_bal;
%                 opt_bal_year(i,h).metadata.I_bal_str  = sim_year(month,sel).I_bal_str;
%                 opt_bal_year(i,h).metadata.eff        = sim_year(month,sel).eff;
%                 opt_bal_year(i,h).metadata.horizon    = sim_year(month,sel).opt_bal(h).horizon;
%             else
%                 aux_cmp(1) = opt_bal_year(i,h).metadata.c_nom - sim_year(month,sel).c_nom;
%                 aux_cmp(2) = opt_bal_year(i,h).metadata.c_var - sim_year(month,sel).c_var;
%                 aux_cmp(3) = opt_bal_year(i,h).metadata.I_bal - sim_year(month,sel).I_bal;
%                 aux_cmp(4) = opt_bal_year(i,h).metadata.eff   - sim_year(month,sel).eff;
%                 if any(aux_cmp ~= 0)
%                     error simulazioni con metadata diversi
%                 end
%             end
%         end
%     end
% end
% %save("data/output/semester_15perc_cvar.mat", "opt_bal_year", "always_bal_year", "no_bal_year","ideal_year");

%% PLOT year data
% id: 1   reference  c_nom = 400, C_var = 0.15,
% id: 2:5 eff=0.7, i_bal= c/5, c/10,c/25,c/50
% id: 6:8 eff=0.9,  "       "   "   "
% id: 9     reference  c_nom = 400, C_var = 0.25,
% id: 10:13  eff=0.7, i_bal= c/5, c/10,c/25,c/50
% id: 14:16 eff=0.9,  "       "   "   "
% id: 17   reference  c_nom = 400, C_var = 0.25, ### alarm_soc_bal = 10/90% ### (per vedere se in questo modo si riducono le scariche parziali a giugno/luglio, e valorizzo opt_bal)
% id: 18:20  eff=0.7, i_bal= c/10,c/25,c/50
% id: 21   reference  c_nom = 400, C_var = 0.35,
% id: 22:25  eff=0.7, i_bal= c/5,c/10,c/25,c/50
c = struct();
c.no_bal        = [205, 0,26]/255; %rosso
c.always_bal    = [25,97,174]/255; %blu
c.opt_bal(1,:)  = [242,205,0]/255; %arancio
c.opt_bal(2,:)  = [239,106,0]/255; %giallo
c.opt_bal(3,:)  = [121,195,0]/255; %verde
c.opt_bal(4,:)  = [156, 135, 20]/255; %ocra
c.opt_bal(5,:)  = [1,1,1]/255; %??
c.ideal         = [97,0,125] /255; %viola

file_name = 'data/output/year_400Ah.mat';
ref_scenario = 1;
id_scenario = [2:8];
[no_bal_year,always_bal_year,opt_bal_year,ideal_year ] = split_scenarios(file_name,ref_scenario,id_scenario);

scenario_index = 4; % è la riga che andrò ada analizzare di no_bal_year, always_bal_year, etc..
sel_horizon = [2,3,4]; %indice dell'orizzonte da plottare (es. [2,3] plotta solo gli orizzonti che corrispondono alla posizione 2,3 della struct opt_bal_year)


figure; hold on;
tiledlayout(2,3,'TileSpacing','Compact');
x_text_label = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul","Aug", "Sept", "Oct", "Nov", "Dec"];
add_label_metadata(always_bal_year(scenario_index),file_name,scenario_index);

%%%%%%%%%%%%%%%%%%%%%%  Energia persa dal DCDC %%%%%%%%%%%%%%%%%%
% non definito per IDEAL

% figure #10 paper
nexttile(4); hold on
legend_str = [""];
plot(always_bal_year(scenario_index).energy.E_lost, 'Color',c.always_bal)
legend_str(1) = "ALWAYS";
for h_id=1:length(sel_horizon)  % per i vari horizzonti
    h = sel_horizon(h_id);
    plot(opt_bal_year(scenario_index, h).energy.E_lost, 'Color',c.opt_bal(h,:));
    legend_str(end+1) = "TWIN (" + num2str(opt_bal_year(scenario_index, h).metadata.horizon ) + "h)";
end
legend(legend_str);
title("DC/DC wasted energy [kWh]");
xticks(1:length(x_text_label)); xticklabels(x_text_label);

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        MM       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%  Energia gestita totale %%%%%%%%%%%%%%%%%%
% nexttile(1); hold on
% legend_str = [""];
%
% e_managed_tot = [];
% e_managed_tot(1,:) = always_bal_year(scenario_index).energy.E_batt - always_bal_year(scenario_index).energy.E_lost;
% plot(e_managed_tot(1,:),'Color',c.always_bal);
% legend_str(1) = "ALWAYS";
% for h_id=1:length(sel_horizon)  % per i vari horizzonti
%      h = sel_horizon(h_id);
%     e_managed_tot(end+1,:) = opt_bal_year(scenario_index, h).energy.E_batt - opt_bal_year(scenario_index, h).energy.E_lost;
%     plot(e_managed_tot(end,:),'Color',c.opt_bal(h,:));
%     legend_str(end+1) = num2str(opt_bal_year(scenario_index, h).metadata.horizon );
% end
% e_managed_tot(end+1,:) = no_bal_year(scenario_index).energy.E_batt;
% plot(e_managed_tot(end,:),'Color',c.no_bal);
% legend_str(end+1) = "NO BAL";
% e_managed_tot(end+1,:) = ideal_year(scenario_index).energy.E_batt;
% plot(e_managed_tot(end,:), '--','Color',c.ideal);
% legend_str(end+1) = "IDEAL";
%
% legend(legend_str);
% title("Total energy managed [KWh]");
% xticks(1:length(x_text_label)); xticklabels(x_text_label);
%
% %%%%%%%%%%%%%%%%%%%%%%  guadagno in energia gestita %%%%%%%%%%%%%%%%%%
% % OSS: non definito per IDEAL
% nexttile(2); hold on
% legend_str = [""];
% E_managed_ref = no_bal_year(scenario_index).energy.E_batt;
% E_managed_gain = [];
% E_managed_gain(1,:) = 100*(always_bal_year(scenario_index).energy.E_batt - always_bal_year(scenario_index).energy.E_lost - E_managed_ref) ./ E_managed_ref;
% plot(E_managed_gain(1,:),'Color',c.always_bal);
% legend_str(1) = "ALWAYS";
% for h_id=1:length(sel_horizon)  % per i vari horizzonti
%      h = sel_horizon(h_id);
%     E_managed_gain(end+1,:) =  100*(opt_bal_year(scenario_index, h).energy.E_batt - opt_bal_year(scenario_index, h).energy.E_lost - E_managed_ref) ./ E_managed_ref;
%     plot(E_managed_gain(end,:),'Color',c.opt_bal(h,:));
%     legend_str(end+1) = num2str(opt_bal_year(scenario_index, h).metadata.horizon );
% end
% legend(legend_str);
% title("Energy managed gain [%] ");
% xticks(1:length(x_text_label)); xticklabels(x_text_label);
%
% %%%%%%%%%%%%%%%%%%%%%% guadagno netto dell'uso di una previsione su un orizzonte %%%%%%%%%%%%%%%%%%%%%%
% %guadagno che c'è (se c'è...) tra usare opt_bal al posto di always
% % non definito per NO_BAL e IDEAL
% nexttile(3); hold on;
% legend_str = [""];
% e_always_aux = always_bal_year(scenario_index).energy.E_batt - always_bal_year(scenario_index).energy.E_lost;
% E_saved = [];
% e_opt_aux = [];
% for h_id=1:length(sel_horizon)  % per i vari horizzonti
%      h = sel_horizon(h_id);
%     e_opt_aux(h,:) = (opt_bal_year(scenario_index,h).energy.E_batt - opt_bal_year(scenario_index,h).energy.E_lost);
%     E_saved(h,:) =  100*(e_opt_aux(h,:) - e_always_aux) ./ e_always_aux;
%     plot(E_saved(h,:),'Color',c.opt_bal(h,:));
%     legend_str(h) = num2str(opt_bal_year(scenario_index, h).metadata.horizon );
% end
% legend(legend_str);
% title("optimal balancing VS always balancing gain [%]");
% xticks(1:length(x_text_label)); xticklabels(x_text_label);
%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        end MM       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        RdR       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%  Energia fornita totale %%%%%%%%%%%%%%%%%%
% versione RdR, energia fornita dalla batteria, che è il mio fattore di merito. In pratica è E_bd
nexttile(1); hold on
legend_str = [""];
E_provided = [];
E_provided(1,:)  = no_bal_year(scenario_index).energy.E_bd;
plot(E_provided(1,:),'Color',c.no_bal);
legend_str(1) = "NEVER";
for h_id=1:length(sel_horizon)
    h = sel_horizon(h_id);
    E_provided(end+1,:) = opt_bal_year(scenario_index, h).energy.E_bd;
    plot(E_provided(end,:),'Color',c.opt_bal(h,:));
    legend_str(end+1) = "TWIN (" + num2str(opt_bal_year(scenario_index, h).metadata.horizon ) + "h)";
end
E_provided(end+1,:) = always_bal_year(scenario_index).energy.E_bd;
plot(E_provided(end,:),'Color',c.always_bal);
legend_str(end+1) = "ALWAYS";
E_provided(end+1,:) = ideal_year(scenario_index).energy.E_bd;   %sim_ref.ideal.energy.E_bd + abs(sim_ref.ideal.energy.E_bc);
plot(E_provided(end,:), '--','Color',c.ideal);
legend_str(end+1) = "IDEAL";
title("Total energy provided (E_{bd}) [KWh]");
legend(legend_str);
xticks([1:length(E_provided)]); xticklabels(x_text_label);

% %%%%%%%%%%%%%%%%%%%%%%  guadagno in energia fornita totale %%%%%%%%%%%%%%%%%%
% versione RdR, energia fornita dalla batteria, che è il mio fattore di merito. In pratica è E_bd
% % OSS: non definito per IDEAL
nexttile(2); hold on
legend_str = [""];
E_provided_ref = no_bal_year(scenario_index).energy.E_bd;
E_provided_gain = [];
E_provided_gain(1,:) = 100*(always_bal_year(scenario_index).energy.E_bd - E_provided_ref) ./ E_provided_ref;
plot(E_provided_gain(end,:),'Color',c.always_bal)
legend_str(1) = "ALWAYS";
for h_id=1:length(sel_horizon)
    h = sel_horizon(h_id);
    E_provided_gain(h,:) = 100*(opt_bal_year(scenario_index, h).energy.E_bd - E_provided_ref) ./ E_provided_ref;
    plot(E_provided_gain(h,:),'Color',c.opt_bal(h,:));
    legend_str(end+1) = "TWIN (" + num2str(opt_bal_year(scenario_index, h).metadata.horizon ) + "h)";
end
plot(zeros(1,size(E_provided_gain(h,:),2)), '--', 'Color','k');
legend_str(end+1) = "Zero thresh";
legend(legend_str);
title(" energy provided gain (E_{bd}) [%]");
xticks([1:length(E_provided_gain)]); xticklabels(x_text_label);

%%%%%%%%%%%%%%%%%%%%%% guadagno netto dell'uso di una previsione su un orizzonte %%%%%%%%%%%%%%%%%%%%%%
%guadagno che c'è (se c'è...) tra usare opt_bal al posto di always
% non definito per NO_BAL e IDEAL
nexttile(3); hold on;
legend_str = [""];
E_saved = [];
for h_id=1:length(sel_horizon)  % per i vari horizzonti
    h = sel_horizon(h_id);
    E_saved(h,:) =  100*(opt_bal_year(scenario_index,h).energy.E_bd - always_bal_year(scenario_index).energy.E_bd ) ./ always_bal_year(scenario_index).energy.E_bd;
    plot(E_saved(h,:),'Color',c.opt_bal(h,:));
    legend_str(h_id) = "TWIN (" + num2str(opt_bal_year(scenario_index, h).metadata.horizon ) + "h)";
end
plot(zeros(1,size(E_saved(h,:),2)), '--', 'Color','k');
legend_str(end+1) = "Zero thresh";
legend(legend_str);
title("optimal balancing VS always balancing gain [%]");
xticks(1:length(x_text_label)); xticklabels(x_text_label);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        end RdR       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%  self consumption %%%%%%%%%%%%%%%%%%
nexttile(5); hold on;
legend_str = [""];
plot(always_bal_year(scenario_index).sc,'Color',c.always_bal)
legend_str(1) = "ALWAYS";
for h_id=1:length(sel_horizon)  % per i vari horizzonti
    h = sel_horizon(h_id);
    plot(opt_bal_year(scenario_index, h).sc,'Color',c.opt_bal(h,:));
    legend_str(end+1) = num2str(opt_bal_year(scenario_index, h).metadata.horizon );
end
plot(no_bal_year(scenario_index).sc,'Color',c.no_bal)
legend_str(end+1) = "NO BAL";
plot(ideal_year(scenario_index).sc, '--','Color',c.ideal)
legend_str(end+1) = "IDEAL";
legend(legend_str);
title("self consumption [%]");
xticks(1:length(x_text_label)); xticklabels(x_text_label);

%%%%%%%%%%%%%%%%%%%%%%  self sufficiency %%%%%%%%%%%%%%%%%%

nexttile(6); hold on;
legend_str = [""];
plot(always_bal_year(scenario_index).ss,'Color',c.always_bal)
legend_str(1) = "ALWAYS";
for h_id=1:length(sel_horizon)  % per i vari horizzontiù
    h = sel_horizon(h_id);
    plot(opt_bal_year(scenario_index, h).ss,'Color',c.opt_bal(h,:));
    legend_str(end+1) = num2str(opt_bal_year(scenario_index, h).metadata.horizon );
end
plot(no_bal_year(scenario_index).ss,'Color',c.no_bal)
legend_str(end+1) = "NO BAL";
plot(ideal_year(scenario_index).ss, '--','Color',c.ideal)
legend_str(end+1) = "IDEAL";
legend(legend_str);
title("self sufficiency [%]");
xticks(1:length(x_text_label)); xticklabels(x_text_label);


%% PLOT year data summary

file_name = 'data/output/year_400Ah.mat';
ref_scenario = 21;
id_scenario = [22:25];
[no_bal_year,always_bal_year,opt_bal_year,ideal_year] = split_scenarios(file_name,ref_scenario,id_scenario);

scenario_index = 2; % indice della i_bal che mi interessa nelle strutture no_bal_year,always_bal_year,opt_bal_year,ideal_year
% 1=C/5, 2=C/10, 3=C/25, 4=C/50,
sel_horizon = [1,2,3];

% DECOMMENTA PER FARE LA FIGURA, E POI COMMENTA PER AGGIUNGERE CURVE(ovvero
% i plot, che così vengono aggiunti sulla stessa figure)
figure;
hold on;
tiledlayout(2,3);
add_label_metadata(always_bal_year(scenario_index),file_name,scenario_index);

j = 1;
x_text_label = "";
wasted_energy = {};
E_saved = {};
E_provided = {};
E_provided_gain = {};
E_provided_diff = {};


%%%%%%%%%%%%%%%%%%%%%%  Energia persa dal DCDC %%%%%%%%%%%%%%%%%%
% non definito per IDEAL
nexttile(4);hold on;
wasted_energy{j}(1) = NaN;
x_text_label(1) = 'NEVER';
for h_id=1:length(sel_horizon)
    h = sel_horizon(h_id);
    wasted_energy{j}(end+1) = sum(opt_bal_year(scenario_index, h).energy.E_lost);

    x_text_label(end+1) = "TWIN (" + num2str(opt_bal_year(scenario_index, h).metadata.horizon) +"h)";
end
wasted_energy{j}(end+1) = sum(always_bal_year(scenario_index).energy.E_lost);
x_text_label(end+1) = 'ALWAYS';
wasted_energy{j}(end+1) = NaN;
x_text_label(end+1) = 'IDEAL';
plot(wasted_energy{j}, '-*');
title("Year DC/DC wasted energy [kWh]");
xticks([1:length(wasted_energy{1})]); xticklabels(x_text_label);

% %%%%%%%%%%%%%%%%%%%%%%  Energia fornita totale %%%%%%%%%%%%%%%%%%
% figure #11 paper
nexttile(1); hold on;
E_provided{j}(1) = sum(no_bal_year(scenario_index).energy.E_bd);
for h_id=1:length(sel_horizon)
    h = sel_horizon(h_id);
    E_provided{j}(end+1) = sum(opt_bal_year(scenario_index, h).energy.E_bd);
end
E_provided{j}(end+1) = sum(always_bal_year(scenario_index).energy.E_bd);
E_provided{j}(end+1) = sum(ideal_year(scenario_index).energy.E_bd);

plot(E_provided{j}, '-*');
title("Year tot energy provided (E_{bd}) [KWh]");
xticks([1:length(E_provided{1})]); xticklabels(x_text_label);

% %%%%%%%%%%%%%%%%%%%%%%  guadagno in energia fornita totale %%%%%%%%%%%%%%%%%%
% % OSS: non definito per IDEAL
nexttile(2); hold on;
E_provided_ref = sum(no_bal_year(scenario_index).energy.E_bd);
E_provided_gain{j}(1) = 0;   %no_bal
for h_id=1:length(sel_horizon)
    h = sel_horizon(h_id);
    E_provided_gain{j}(end+1) = 100*(sum(opt_bal_year(scenario_index, h).energy.E_bd) - E_provided_ref) / E_provided_ref;
end
E_provided_gain{j}(end+1) = 100*(sum(always_bal_year(scenario_index).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_provided_gain{j}(end+1) = NaN; %IDEAL
plot(E_provided_gain{j}, '-*');
title("Year Energy provided gain (E_{g}) [%] ");
xticks([1:length(E_provided_gain{1})]); xticklabels(x_text_label);

% %%%%%%%%%%%%%%%%%%%%%%  differenza in energia fornita totale %%%%%%%%%%%%%%%%%%
% % OSS: non definito per IDEAL
nexttile(5); hold on;
E_provided_ref = sum(no_bal_year(scenario_index).energy.E_bd);
E_provided_diff{j}(1) = 0;   %no_bal
for h_id=1:length(sel_horizon)
    h = sel_horizon(h_id);
    E_provided_diff{j}(end+1) = (sum(opt_bal_year(scenario_index, h).energy.E_bd) - E_provided_ref);
end
E_provided_diff{j}(end+1) = (sum(always_bal_year(scenario_index).energy.E_bd) - E_provided_ref);
E_provided_diff{j}(end+1) = (sum(ideal_year(scenario_index).energy.E_bd) - E_provided_ref);
plot(E_provided_diff{j}, '-*');
title("Year Energy provided difference to NOBAL [KWh] ");
xticks([1:length(E_provided_diff{1})]); xticklabels(x_text_label);

%%%%%%%%%%%%%%%%%%%%%% guadagno netto dell'uso di una previsione su un orizzonte %%%%%%%%%%%%%%%%%%%%%%
%guadagno che c'è (se c'è...) tra usare opt_bal al posto di always
% non definito per NO_BAL e IDEAL
nexttile(3); hold on;
E_saved{j}(1) = NaN; %NOBAL
for h_id=1:length(sel_horizon)
    h = sel_horizon(h_id);
    E_saved{j}(end+1) = 100* (sum(opt_bal_year(scenario_index,h).energy.E_bd) - sum(always_bal_year(scenario_index).energy.E_bd)) / sum(always_bal_year(scenario_index).energy.E_bd);
end
E_saved{j}(end+1) = NaN; %ALWAYS
E_saved{j}(end+1) = NaN; %IDEAL

plot(E_saved{j}, '-*');
title("Year optimal balancing VS always balancing gain [%]");
xticks([1:length(E_saved{1})]); xticklabels(x_text_label);

%%%%%%%%%%%%%%%%%%%%%%  self sufficiency & self consumption %%%%%%%%%%%%%%%%%%

nexttile(6); hold on;
legend_str = [""];
ss_year = {};
sc_year = {};
ss_year{j}(1) = sum(no_bal_year(scenario_index).ss)/12;
sc_year{j}(1) = sum(no_bal_year(scenario_index).sc)/12;
for h_id=1:length(sel_horizon)  % per i vari horizzontiù
    h = sel_horizon(h_id);
    ss_year{j}(end+1) = sum(opt_bal_year(scenario_index,h).ss)/12;
    sc_year{j}(end+1) = sum(opt_bal_year(scenario_index,h).sc)/12;
end
ss_year{j}(end+1) = sum(always_bal_year(scenario_index).ss)/12;
sc_year{j}(end+1) = sum(always_bal_year(scenario_index).sc)/12;
ss_year{j}(end+1) = sum(ideal_year(scenario_index).ss)/12;
sc_year{j}(end+1) = sum(ideal_year(scenario_index).sc)/12;

title("SS & SC[%]");
plot(ss_year{j});
plot(sc_year{j});

legend("SS","SC");
xticks(1:length(x_text_label)); xticklabels(x_text_label);

%% PLOT E_gain= f(C_var) parametrizzato su I_bal, rispetto a 12 mesi (OPTIMAL BAL-1h)
% per il plot considero solo il caso ALWAYS_BAL, che tanto ho dimostrato
% che OPT_BAL è praticamente uguale
file_name = 'data/output/year_400Ah.mat';
E_gain_C5 = [];
E_gain_C10 =[];
E_gain_C25 =[];
E_gain_C50 =[];

h=3;
%%%%%%%%%%      C_var=15%     %%%%%%%%%%%%%%
ref_scenario = 1;
id_scenario = [2:8];
[no_bal_year,~,opt_bal_year,~] = split_scenarios(file_name,ref_scenario,id_scenario);
E_provided_ref = sum(no_bal_year(1).energy.E_bd);

E_gain_C5 (1) = 100*(sum(opt_bal_year(1,h).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_gain_C10(1) = 100*(sum(opt_bal_year(2,h).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_gain_C25(1) = 100*(sum(opt_bal_year(3,h).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_gain_C50(1) = 100*(sum(opt_bal_year(4,h).energy.E_bd) - E_provided_ref) / E_provided_ref;
x_text_label(1) = "15%";
%%%%%%%%%%      C_var=25%     %%%%%%%%%%%%%%
ref_scenario = 9;
id_scenario = [10:16];
[no_bal_year,~,opt_bal_year,~] = split_scenarios(file_name,ref_scenario,id_scenario);
E_provided_ref = sum(no_bal_year(1).energy.E_bd);
E_gain_C5 (2) = 100*(sum(opt_bal_year(1,h).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_gain_C10(2) = 100*(sum(opt_bal_year(2,h).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_gain_C25(2) = 100*(sum(opt_bal_year(3,h).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_gain_C50(2) = 100*(sum(opt_bal_year(4,h).energy.E_bd) - E_provided_ref) / E_provided_ref;
x_text_label(2) = "25%";
%%%%%%%%%%      C_var=35%     %%%%%%%%%%%%%%
ref_scenario = 21;
id_scenario = [22:25];
[no_bal_year,~,opt_bal_year,~] = split_scenarios(file_name,ref_scenario,id_scenario);
scenario_index=[1,2,3,4];  %campi della struct dove ci sono C/5, C/10,C/25,C/50
E_provided_ref = sum(no_bal_year(1).energy.E_bd);
E_gain_C5 (3) = 100*(sum(opt_bal_year(1,h).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_gain_C10(3) = 100*(sum(opt_bal_year(2,h).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_gain_C25(3) = 100*(sum(opt_bal_year(3,h).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_gain_C50(3) = 100*(sum(opt_bal_year(4,h).energy.E_bd) - E_provided_ref) / E_provided_ref;
x_text_label(3) = "35%";

figure; hold on; grid on;
%plot(E_gain_C5 );
plot(E_gain_C10);
plot(E_gain_C25);
plot(E_gain_C50);
legend("C/10","C/25", "C/50");
xticks(1:length(x_text_label)); xticklabels(x_text_label);
ylabel("E_g [%]");
xlabel("C_{var}");
title("Dynamic equalization benefits when C_{var} increases");

%% PLOT E_gain= f(C_var) parametrizzato su I_bal, rispetto a 12 mesi    (ALWAYS BAL)
% per il plot considero solo il caso ALWAYS_BAL, che tanto ho dimostrato
% che OPT_BAL è praticamente uguale
file_name = 'data/output/year_400Ah.mat';
E_gain_C5 = [];
E_gain_C10 =[];
E_gain_C25 =[];
E_gain_C50 =[];

%%%%%%%%%%      C_var=15%     %%%%%%%%%%%%%%
ref_scenario = 1;
id_scenario = [2:8];
[no_bal_year,always_bal_year,~,~] = split_scenarios(file_name,ref_scenario,id_scenario);
E_provided_ref = sum(no_bal_year(1).energy.E_bd);

E_gain_C5 (1) = 100*(sum(always_bal_year(1).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_gain_C10(1) = 100*(sum(always_bal_year(2).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_gain_C25(1) = 100*(sum(always_bal_year(3).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_gain_C50(1) = 100*(sum(always_bal_year(4).energy.E_bd) - E_provided_ref) / E_provided_ref;
x_text_label(1) = "15%";
%%%%%%%%%%      C_var=25%     %%%%%%%%%%%%%%
ref_scenario = 9;
id_scenario = [10:16];
[no_bal_year,always_bal_year,~,~] = split_scenarios(file_name,ref_scenario,id_scenario);
E_provided_ref = sum(no_bal_year(1).energy.E_bd);
E_gain_C5 (2) = 100*(sum(always_bal_year(1).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_gain_C10(2) = 100*(sum(always_bal_year(2).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_gain_C25(2) = 100*(sum(always_bal_year(3).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_gain_C50(2) = 100*(sum(always_bal_year(4).energy.E_bd) - E_provided_ref) / E_provided_ref;
x_text_label(2) = "25%";
%%%%%%%%%%      C_var=35%     %%%%%%%%%%%%%%
ref_scenario = 21;
id_scenario = [22:25];
[no_bal_year,always_bal_year,~,~] = split_scenarios(file_name,ref_scenario,id_scenario);
scenario_index=[1,2,3,4];  %campi della struct dove ci sono C/5, C/10,C/25,C/50
E_provided_ref = sum(no_bal_year(1).energy.E_bd);
E_gain_C5 (3) = 100*(sum(always_bal_year(1).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_gain_C10(3) = 100*(sum(always_bal_year(2).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_gain_C25(3) = 100*(sum(always_bal_year(3).energy.E_bd) - E_provided_ref) / E_provided_ref;
E_gain_C50(3) = 100*(sum(always_bal_year(4).energy.E_bd) - E_provided_ref) / E_provided_ref;
x_text_label(3) = "35%";

figure; hold on;
plot(E_gain_C5 );
plot(E_gain_C10);
plot(E_gain_C25);
plot(E_gain_C50);
legend("C/5", "C/10","C/25", "C/50");
xticks(1:length(x_text_label)); xticklabels(x_text_label);
ylabel("E battery provided gain [%]");
xlabel("C_{var}");
title("E_{bd} when SLB ages (ALWAYS BAL)");
%% sovrapposizione grafico Ss, Sc
% Se sovrapponessi il grafico annuale di ss e sc e trovassi quali sono le
% fasce/combinazioni in cui ho un E_gain maggiore? Che avere ss altro o sc
% alto vuol dire che la batteria o è sempre piena o è sempre vuota
% rispettivamente (a causa dello sbilanciamento tra load e PV), e quindi il
% sistema di bilanciamento serve il giusto…

scenario_index = 2;
sel_horizon = [2,3,4];
figure;
x_text_label = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul","Aug", "Sept", "Oct", "Nov", "Dic"];
add_label_metadata(always_bal_year(scenario_index),file_name,scenario_index);

tiledlayout(2,1);
nexttile;hold on;

legend_str = [""];
plot(always_bal_year(scenario_index).ss,'--','Color',c.always_bal)
legend_str(1) = "ALW-ss";
for h_id=1:length(sel_horizon)  % per i vari horizzonti
    h = sel_horizon(h_id);
    plot(opt_bal_year(scenario_index, h).ss,'--','Color',c.opt_bal(h,:));
    legend_str(end+1) = num2str(opt_bal_year(scenario_index, h).metadata.horizon );
end
plot(no_bal_year(scenario_index).ss,'--','Color',c.no_bal)
legend_str(end+1) = "NO-ss";
plot(ideal_year(scenario_index).ss, '--','Color',c.ideal)
legend_str(end+1) = "ID-ss";
legend(legend_str);


plot(always_bal_year(scenario_index).sc,'Color',c.always_bal)
legend_str(1) = "ALW-sc";
for h_id=1:length(sel_horizon)  % per i vari horizzonti
    h = sel_horizon(h_id);
    plot(opt_bal_year(scenario_index, h).sc,'Color',c.opt_bal(h,:));
    legend_str(end+1) = num2str(opt_bal_year(scenario_index, h).metadata.horizon);
end
plot(no_bal_year(scenario_index).sc,'Color',c.no_bal)
legend_str(end+1) = "NO-sc";
plot(ideal_year(scenario_index).sc,'Color',c.ideal)
legend_str(end+1) = "ID-sc";
legend(legend_str);
title("Ss and Sc [%]");
xticks(1:length(x_text_label)); xticklabels(x_text_label);

% %%%%%%%%%%%%%%%%%%%%%%  guadagno in energia fornita totale %%%%%%%%%%%%%%%%%%
% versione RdR, energia fornita dalla batteria, che è il mio fattore di merito. In pratica è E_bd
% % OSS: non definito per IDEAL
nexttile(2); hold on
legend_str = [""];
E_provided_ref = no_bal_year(scenario_index).energy.E_bd;
E_provided_gain = [];
E_provided_gain(1,:) = 100*(always_bal_year(scenario_index).energy.E_bd - E_provided_ref) ./ E_provided_ref;
plot(E_provided_gain(end,:),'Color',c.always_bal)
legend_str(1) = "ALWAYS";
for h_id=1:length(sel_horizon)
    h = sel_horizon(h_id);
    E_provided_gain(h,:) = 100*(opt_bal_year(scenario_index, h).energy.E_bd - E_provided_ref) ./ E_provided_ref;
    plot(E_provided_gain(h,:),'Color',c.opt_bal(h,:));
    legend_str(end+1) = num2str(opt_bal_year(scenario_index, h).metadata.horizon );
end
legend(legend_str);
title(" energy provided gain (E_{bd}) [%]");
xticks([1:length(E_provided_gain)]); xticklabels(x_text_label);

%% plot E_gain_bd per i vari mesi
color = [0 0.4470 0.7410;
    0.8500 0.3250 0.0980;
    0.9290 0.6940 0.1250;
    0.4940 0.1840 0.5560];
file_name = 'data/output/year_400Ah.mat';
ref_scenario = 1;
id_scenario = [2:8];
[no_bal_year,always_bal_year,opt_bal_year,ideal_year ] = split_scenarios(file_name,ref_scenario,id_scenario);

scenario_index = 2; % è la riga che andrò ada analizzare di no_bal_year, always_bal_year, etc..
sel_horizon = [2,3,4]; %indice dell'orizzonte da plottare (es. [2,3] plotta solo gli orizzonti che corrispondono alla posizione 2,3 della struct opt_bal_year)


figure; hold on;
tiledlayout(2,1);
x_text_label = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul","Aug", "Sept", "Oct", "Nov", "Dec"];
add_label_metadata(always_bal_year(scenario_index),file_name,scenario_index);

nexttile(1); hold on
legend_str = [""];
E_never_bd= no_bal_year(scenario_index).energy.E_bd;
E_always_bd= always_bal_year(scenario_index).energy.E_bd;
E_ideal_bd= ideal_year(scenario_index).energy.E_bd;
E_opt_bd= opt_bal_year(scenario_index,1).energy.E_bd;
plot(E_ideal_bd,"LineStyle", "-"  , "LineWidth", 1.5)
plot(E_opt_bd, "LineStyle","-."   , "LineWidth", 1.5)
plot(E_always_bd,"LineStyle", ":" , "LineWidth", 1.5)
plot(E_never_bd, "LineStyle", "--", "LineWidth", 1.5)
title("E_{bd}");
ylabel("[kWh]");
legend("IDEAL","TWIN", "ALWAYS","NEVER")
xticks([1:length(E_never_bd)]); xticklabels(x_text_label);
xlim([1 12])

nexttile(2); hold on
E_always_bd_gain = 100*((E_always_bd - E_never_bd)./E_never_bd);
E_opt_bd_gain  = 100*((E_opt_bd - E_never_bd)./E_never_bd);
E_ideal_bd_gain  = 100*((E_ideal_bd - E_never_bd)./E_never_bd);

area(E_ideal_bd_gain, "LineStyle","-")
area(E_opt_bd_gain,"LineStyle","-."  ) 
area(E_always_bd_gain,"LineStyle",":")
title("G");
ylabel("[%]");
legend("IDEAL","TWIN","ALWAYS");
xticks([1:length(E_always_bd_gain)]); xticklabels(x_text_label);
xlim([1 12])

%% plot E_grid_in integrale
file_name = 'data/output/year_400Ah.mat';
ref_scenario = 1;
id_scenario = [2:8];
[no_bal_year,always_bal_year,opt_bal_year,ideal_year ] = split_scenarios(file_name,ref_scenario,id_scenario);

scenario_index = 2; % è la riga che andrò ada analizzare di no_bal_year, always_bal_year, etc..
sel_horizon = [2,3,4]; %indice dell'orizzonte da plottare (es. [2,3] plotta solo gli orizzonti che corrispondono alla posizione 2,3 della struct opt_bal_year)


figure;
tiledlayout(2,1); 
nexttile;hold on;
x_text_label = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul","Aug", "Sept", "Oct", "Nov", "Dec"];
add_label_metadata(always_bal_year(scenario_index),file_name,scenario_index);

legend_str = [""];
E_grid_in_no_bal = cumsum(no_bal_year(scenario_index).energy.E_grid_in);
E_grid_in_always_bal = cumsum(always_bal_year(scenario_index).energy.E_grid_in);
plot(E_grid_in_no_bal,'--','Color',c.no_bal)
legend_str(1) = "NEVER";
plot(E_grid_in_always_bal,'Color',c.always_bal)
legend_str(2) = "ALWAYS";
for h_id=1:length(sel_horizon)
    h = sel_horizon(h_id);
    E_grid_in_opt_bal(h_id,:) = cumsum(opt_bal_year(scenario_index, h).energy.E_grid_in);
    plot(E_grid_in_opt_bal(h_id,:),'Color',c.opt_bal(h,:));
    legend_str(end+1) = "TWIN (" + num2str(opt_bal_year(scenario_index, h).metadata.horizon ) + "h)";
end
legend(legend_str);
title(" energy provided gain (E_{bd}) [%]");
xticks([1:length(E_provided_gain)]); xticklabels(x_text_label);

nexttile;hold on;
plot(E_grid_in_always_bal-E_grid_in_opt_bal(1,:))
plot(E_grid_in_always_bal-E_grid_in_opt_bal(2,:))
plot(E_grid_in_always_bal-E_grid_in_opt_bal(3,:))
title("energia comprata dalla rete: always-opt")
%% plot W_waste integrale
file_name = 'data/output/year_400Ah.mat';
load(file_name)
ref_scenario = 1;
id_scenario = [2:5];
[~,always_bal_year,opt_bal_year,~] = split_scenarios(file_name,ref_scenario,id_scenario);

scenario_index = 2; % indice della i_bal che mi interessa nelle strutture no_bal_year,always_bal_year,opt_bal_year,ideal_year
% 1=C/5, 2=C/10, 3=C/25, 4=C/50,

wasted_energy = [];
%in "wasted_energy" metto cumulativamente l'energia persa da gennaio al mese "m"
for m=1:12
    wasted_energy(1,m)= sum(opt_bal_year(scenario_index, 1).energy.E_lost(1:m)); % TWIN 3h
    wasted_energy(2,m)= sum(opt_bal_year(scenario_index, 2).energy.E_lost(1:m)); % TWIN 6h
    wasted_energy(3,m)= sum(opt_bal_year(scenario_index, 3).energy.E_lost(1:m)); % TWIN 12h
    wasted_energy(4,m)= sum(always_bal_year(scenario_index).energy.E_lost(1:m)); %always bal
end

figure;
add_label_metadata(always_bal_year(scenario_index),file_name,scenario_index);
hold on;
plot(wasted_energy(4,:), "lineWidth", 1.5);
plot(wasted_energy(3,:), "lineWidth", 1.5);
plot(wasted_energy(2,:), "lineWidth", 1.5);
plot(wasted_energy(1,:), "lineWidth", 1.5);
title("Energy loss by dynamic equalization system");
months_list = ["Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sept", "Oct", "Nov", "Dec"];
xticks([1:size(wasted_energy,2)]);
xticklabels(months_list);
xlim([1 12])
ylabel("[kWh]");
legend("ALWAYS","TWIN 12h","TWIN 6h","TWIN 3h", "Location","northwest");
%% plot capacity mismatch increasing effect
color = [0 0.4470 0.7410;
    0.8500 0.3250 0.0980;
    0.9290 0.6940 0.1250;
    0.4940 0.1840 0.5560];
file_name = 'data/output/year_400Ah.mat';

%%%%%%%%%%      C_var=15%     %%%%%%%%%%%%%%
ref_scenario = 1;
id_scenario = [2:8];
[no_bal_year,always_bal_year,opt_bal_year,~] = split_scenarios(file_name,ref_scenario,id_scenario);
E_bd_never(1)  = sum(no_bal_year(1).energy.E_bd);
E_bd_always(1) = sum(always_bal_year(2).energy.E_bd);
E_bd_twin(1) = sum(opt_bal_year(2,2).energy.E_bd);  % 3h
E_g_always(1) = 100*(E_bd_always(1) - E_bd_never(1)) / E_bd_never(1);
E_g_twin(1) = 100*(E_bd_twin(1) - E_bd_never(1)) / E_bd_never(1);
%%%%%%%%%%      C_var=25%     %%%%%%%%%%%%%%
ref_scenario = 9;
id_scenario = [10:16];
[no_bal_year,always_bal_year,opt_bal_year,~] = split_scenarios(file_name,ref_scenario,id_scenario);
E_bd_never(2) = sum(no_bal_year(1).energy.E_bd);
E_bd_always(2) = sum(always_bal_year(2).energy.E_bd);
E_bd_twin(2) = sum(opt_bal_year(2,2).energy.E_bd);
E_g_always(2) = 100*(E_bd_always(2) - E_bd_never(2)) / E_bd_never(2);
E_g_twin(2) = 100*(E_bd_twin(2) - E_bd_never(2)) / E_bd_never(2);
%%%%%%%%%%      C_var=35%     %%%%%%%%%%%%%%
ref_scenario = 21;
id_scenario = [22:25];
[no_bal_year,always_bal_year,opt_bal_year,~] = split_scenarios(file_name,ref_scenario,id_scenario);
scenario_index=[1,2,3,4];  %campi della struct dove ci sono C/5, C/10,C/25,C/50
E_bd_never(3) = sum(no_bal_year(1).energy.E_bd);
E_bd_always(3) = sum(always_bal_year(2).energy.E_bd);
E_bd_twin(3) = sum(opt_bal_year(2,2).energy.E_bd);
E_g_always(3) = 100*(E_bd_always(3)- E_bd_never(3)) / E_bd_never(3);
E_g_twin(3) = 100*(E_bd_twin(3)- E_bd_never(3)) / E_bd_never(3);

figure; 
yyaxis left
hold on;
x_label = ["15%","25%","35%"];
bar(x_label, E_bd_twin,'FaceColor',color(2,:),'EdgeColor',color(2,:));
bar(x_label, E_bd_always,'FaceColor',color(1,:),'EdgeColor',color(1,:));
bar(x_label, E_bd_never,'FaceColor' ,color(3,:),'EdgeColor',color(3,:));
ylabel("E_{bd} [kWh]")
xlabel("Cell capacity mismatch")


yyaxis right
plot(E_g_twin,"-*", "Color",color(2,:), "LineWidth",2);
plot(E_g_always,"-*", "Color",color(4,:), "LineWidth",2);
legend("ALWAYS","NEVER","E_g")
ylabel("E_g [%]")
ax = gca();
ax.YAxis(1).Color = [0 0 0];
ax.YAxis(2).Color = [0 0 0];
%% analisi economica

file_name = 'data/output/year_400Ah.mat';
ref_scenario = 1;
id_scenario = [2:5];
[no_bal_year,always_bal_year,opt_bal_year,ideal_year] = split_scenarios(file_name,ref_scenario,id_scenario);

idx = 2; % indice della i_bal che mi interessa nelle strutture no_bal_year,always_bal_year,opt_bal_year,ideal_year

% considero i 3 casi:
% a) PV+new battery --> IDEAL (NEW BATT)
% b) PV+slb         --> NO_BAL
% c) PV+slb+dyn_bal --> ALWAYS
% d) PV & no battery     --> pago e_load-E_du. vendo E_pv-E_du
% e) no PV & no battery  --> pago tutto E_load, non vendo niente

% costi e variabili definibili per l'investimento
PV_cost_kwp        = 1322;%1322   % [€/kWp], costo pv+inverter -- da transaction
c_new_batt         = 676; %676;   % [€/kWh], costo new batt -- da transaction
c_slb              = 250; %400;   % [€/kWh], costo slb      -- da siti che vendono slb (83-250€/kWh + manodopera&bms), (150€ da https://www.irena.org/-/media/Files/IRENA/Agency/Publication/2019/May/IRENA_Innovation_Outlook_EV_smart_charging_2019.pdf)
c_dyn_bal          = 0;  %80;      [€], costo sistema di bilanciamento, sarebbe una variabile libera
e_price_grid_in    = .40; %.30;   % [€/kWh], costo acquisto energia (ad ottobre 2023 è arrivata a costare 0.55€/kWh, oggi 0.12)
e_price_grid_out   = .115; %.12;   % [€/kWh], ricavo vendita energia
life_span = 15;                   % [years], durata prevista dell'impianto, assumendo comportamento invariante negli anni
interest_rate = 0.04;

% dati del caso studio
PV_p_peak = 7;          %[kWp]
battery_capacity = 14;  %[kWh]
slb_soh = 0.75;
c_PV = PV_p_peak * PV_cost_kwp;
c_init.a = c_PV + c_new_batt*battery_capacity;
c_init.b = c_PV + c_slb*battery_capacity/slb_soh;
c_init.c = c_init.b + c_dyn_bal;
c_init.d = c_PV;
c_init.e = 0;

% energia comprata
e_grid_in.a = sum(ideal_year(idx).energy.E_grid_in); %[kWh]
e_grid_in.b = sum(no_bal_year(idx).energy.E_grid_in);
e_grid_in.c = sum(always_bal_year(idx).energy.E_grid_in);
e_grid_in.d = sum(ideal_year(idx).energy.E_load ) - sum(ideal_year(idx).energy.E_du);
e_grid_in.e = sum(ideal_year(idx).energy.E_load);

%costo annuo legato all'acquisto di energia
c_grid_in.a = e_grid_in.a * e_price_grid_in;
c_grid_in.b = e_grid_in.b * e_price_grid_in;
c_grid_in.c = e_grid_in.c * e_price_grid_in;
c_grid_in.d = e_grid_in.d * e_price_grid_in;
c_grid_in.e = e_grid_in.e * e_price_grid_in;

% energia venduta (oss: *.energy.E_grid_out è negativa)
e_grid_out.a = -sum(ideal_year(idx).energy.E_grid_out);
e_grid_out.b = -sum(no_bal_year(idx).energy.E_grid_out);
e_grid_out.c = -sum(always_bal_year(idx).energy.E_grid_out);
e_grid_out.d = -(sum(ideal_year(idx).energy.E_pv) + sum(ideal_year(idx).energy.E_du)); %E_pv è negativa...
e_grid_out.e = 0;

% ricavi legati alla vendita di energia
c_grid_out.a = e_grid_out.a * e_price_grid_out;
c_grid_out.b = e_grid_out.b * e_price_grid_out;
c_grid_out.c = e_grid_out.c * e_price_grid_out;
c_grid_out.d = e_grid_out.d * e_price_grid_out;
c_grid_out.e = e_grid_out.e * e_price_grid_out;

% netto economico per ogni anno, senza considerare l'investimento iniziale
c_tot.a = -c_grid_in.a + c_grid_out.a;
c_tot.b = -c_grid_in.b + c_grid_out.b;
c_tot.c = -c_grid_in.c + c_grid_out.c;
c_tot.d = -c_grid_in.d + c_grid_out.d;
c_tot.e = -c_grid_in.e + c_grid_out.e;

%soldi risparmiati ogni anno rispetto al caso "e" (ovvero quello che non
%devo pagare in bolletta rispetto al caso in cui non avessi PV e batteria)
c_saved.a =  c_tot.a - c_tot.e;
c_saved.b =  c_tot.b - c_tot.e;
c_saved.c =  c_tot.c - c_tot.e;
c_saved.d =  c_tot.d - c_tot.e;

% calcolo il pbt, rispetto al caso "e", dove non ho PV e batteria.
pbt.a = c_init.a / (c_tot.a - c_tot.e);
pbt.b = c_init.b / (c_tot.b - c_tot.e);
pbt.c = c_init.c / (c_tot.c - c_tot.e);
pbt.d = c_init.d / (c_tot.d - c_tot.e);

% calcolo npv
years = 1:1:life_span;
npv.a = -c_init.a + sum(c_saved.a * (1/(1+interest_rate)).^years(:));
npv.b = -c_init.b + sum(c_saved.b * (1/(1+interest_rate)).^years(:));
npv.c = -c_init.c + sum(c_saved.c * (1/(1+interest_rate)).^years(:));
npv.d = -c_init.d + sum(c_saved.d * (1/(1+interest_rate)).^years(:));

figure(1);
%tiledlayout(2,1);
nexttile(1); hold on;
%add_label_metadata(always_bal_year(idx),file_name,idx);
%npv_values = structfun(@(x) x, npv);
npv_values(1) = npv.a;
npv_values(2) = npv.b;
npv_values(3) = npv.c;
labels = ["NEW BATTERY", "NO", "ALWAYS"];
plot(1:numel(npv_values), npv_values, '-o', 'LineWidth', 1);
xticks(1:numel(npv_values));
xticklabels(labels);
title("Net present value ");
ylabel("[€]");

nexttile(2);
hold on
%pbt_values = structfun(@(x) x, pbt);
pbt_values(1) = pbt.a;
pbt_values(2) = pbt.b;
pbt_values(3) = pbt.c;
plot(1:numel(pbt_values), pbt_values, '-o', 'LineWidth', 1);
xticks(1:numel(pbt_values));
xticklabels(labels);
title("Payback time");
ylabel("[years]")

%% analisi economica considerando vari mismatch di capacità
color = [0 0.4470 0.7410;
    0.8500 0.3250 0.0980;
    0.9290 0.6940 0.1250;
    0.4940 0.1840 0.5560];

c_mism_15 = 1;
c_mism_25 = 2;
c_mism_35 = 3;
file_name = 'data/output/year_400Ah.mat';
load(file_name);
% considero i 3 casi:
% a) PV+new battery --> IDEAL
% b) PV+slb         --> NO_BAL
% c) PV+slb+dyn_bal --> ALWAYS
% d) PV & no battery     --> pago e_load-E_du. vendo E_pv-E_du
% e) no PV & no battery  --> pago tutto E_load, non vendo niente

% costi e variabili definibili per l'investimento
PV_cost_kwp        = 1322;%1322   % [€/kWp], costo pv+inverter -- da transaction
c_new_batt         = 676; %676;   % [€/kWh], costo new batt -- da transaction
c_slb              = 250; %400;   % [€/kWh], costo slb      -- da siti che vendono slb (83-250€/kWh + manodopera&bms), (150€ da https://www.irena.org/-/media/Files/IRENA/Agency/Publication/2019/May/IRENA_Innovation_Outlook_EV_smart_charging_2019.pdf)
c_dyn_bal          = 0;  %80;      [€], costo sistema di bilanciamento, sarebbe una variabile libera
e_price_grid_in    = .40; %.30;   % [€/kWh], costo acquisto energia (ad ottobre 2023 è arrivata a costare 0.55€/kWh, oggi 0.12)
e_price_grid_out   = .115; %.12;   % [€/kWh], ricavo vendita energia
life_span = 15;                   % [years], durata prevista dell'impianto, assumendo comportamento invariante negli anni
interest_rate = 0.04;

% dati del caso studio
PV_p_peak = 7;          %[kWp]
battery_capacity = 14;  %[kWh]
slb_soh = 0.75;
c_PV = PV_p_peak * PV_cost_kwp;
c_init.a = c_PV + c_new_batt*battery_capacity;
c_init.b = c_PV + c_slb*battery_capacity/slb_soh;
c_init.c = c_init.b + c_dyn_bal;
c_init.d = c_PV;
c_init.e = 0;


for i=1:3
    if i==c_mism_15 %c_mismatch=15%
        ref_scenario = 1;
        id_scenario = [2:5];
        [no_bal_year,always_bal_year,opt_bal_year,ideal_year] = split_scenarios(file_name,ref_scenario,id_scenario);
    end
    if i==c_mism_25 %c_mismatch=25%
        ref_scenario = 9;
        id_scenario = [10:13];
        [no_bal_year,always_bal_year,opt_bal_year,ideal_year] = split_scenarios(file_name,ref_scenario,id_scenario);
    end
    if i==c_mism_35 %c_mismatch=35%
        ref_scenario = 21;
        id_scenario = [22:25];
        [no_bal_year,always_bal_year,opt_bal_year,ideal_year] = split_scenarios(file_name,ref_scenario,id_scenario);
    end

    idx = 2; % indice della i_bal che mi interessa nelle strutture no_bal_year,always_bal_year,opt_bal_year,ideal_year

    % energia comprata
    e_grid_in.a(i) = sum(ideal_year(idx).energy.E_grid_in); %[kWh]
    e_grid_in.b(i) = sum(no_bal_year(idx).energy.E_grid_in);
    e_grid_in.c(i) = sum(always_bal_year(idx).energy.E_grid_in);
    e_grid_in.d(i) = sum(ideal_year(idx).energy.E_load ) - sum(ideal_year(idx).energy.E_du);
    e_grid_in.e(i) = sum(ideal_year(idx).energy.E_load);

    % energia venduta
    e_grid_out.a(i) = -sum(ideal_year(idx).energy.E_grid_out);
    e_grid_out.b(i) = -sum(no_bal_year(idx).energy.E_grid_out);
    e_grid_out.c(i) = -sum(always_bal_year(idx).energy.E_grid_out);
    e_grid_out.d(i) = -(sum(ideal_year(idx).energy.E_pv) + sum(ideal_year(idx).energy.E_du)); %E_pv è negativa...
    e_grid_out.e(i) = 0;

    %costo annuo legato all'acquisto di energia
    c_grid_in.a(i) = e_grid_in.a(i) * e_price_grid_in;
    c_grid_in.b(i) = e_grid_in.b(i) * e_price_grid_in;
    c_grid_in.c(i) = e_grid_in.c(i) * e_price_grid_in;
    c_grid_in.d(i) = e_grid_in.d(i) * e_price_grid_in;
    c_grid_in.e(i) = e_grid_in.e(i) * e_price_grid_in;

    % ricavi legati alla vendita di energia
    c_grid_out.a(i) = e_grid_out.a(i) * e_price_grid_out;
    c_grid_out.b(i) = e_grid_out.b(i) * e_price_grid_out;
    c_grid_out.c(i) = e_grid_out.c(i) * e_price_grid_out;
    c_grid_out.d(i) = e_grid_out.d(i) * e_price_grid_out;
    c_grid_out.e(i) = e_grid_out.e(i) * e_price_grid_out;

    % netto economico per ogni anno, senza considerare l'investimento iniziale
    
    c_tot.a(i) = -c_grid_in.a(i) + c_grid_out.a(i);
    c_tot.b(i) = -c_grid_in.b(i) + c_grid_out.b(i);
    c_tot.c(i) = -c_grid_in.c(i) + c_grid_out.c(i);
    c_tot.d(i) = -c_grid_in.d(i) + c_grid_out.d(i);
    c_tot.e(i) = -c_grid_in.e(i) + c_grid_out.e(i);

    %soldi risparmiati ogni anno rispetto al caso "e" (ovvero quello che non
    %devo pagare in bolletta rispetto al caso in cui non avessi PV e batteria)
    c_saved.a(i) = c_tot.a(i) - c_tot.e(i);
    c_saved.b(i) = c_tot.b(i) - c_tot.e(i);
    c_saved.c(i) = c_tot.c(i) - c_tot.e(i);
    c_saved.d(i) = c_tot.d(i) - c_tot.e(i);

    % calcolo il pbt, rispetto al caso "e", dove non ho PV e batteria.
    pbt.a(i) = c_init.a / (c_tot.a(i) - c_tot.e(i));
    pbt.b(i) = c_init.b / (c_tot.b(i) - c_tot.e(i));
    pbt.c(i) = c_init.c / (c_tot.c(i) - c_tot.e(i));
    pbt.d(i) = c_init.d / (c_tot.d(i) - c_tot.e(i));

    % calcolo npv
    years = 1:1:life_span;
    npv.a(i) = -c_init.a + sum(c_saved.a(i) * (1/(1+interest_rate)).^years(:));
    npv.b(i) = -c_init.b + sum(c_saved.b(i) * (1/(1+interest_rate)).^years(:));
    npv.c(i) = -c_init.c + sum(c_saved.c(i) * (1/(1+interest_rate)).^years(:));
    npv.d(i) = -c_init.d + sum(c_saved.d(i) * (1/(1+interest_rate)).^years(:));
end


% %%%%%%%%%%%%%%
% % calcolo npv e pbt considerando una variazione lineare di aging
    % % c_saved linear variation
    % c_saved_lin.a = linspace(c_saved.a(c_mism_15),c_saved.a(c_mism_25),life_span); 
    % c_saved_lin.b = linspace(c_saved.b(c_mism_15),c_saved.b(c_mism_25),life_span);
    % c_saved_lin.c = linspace(c_saved.c(c_mism_15),c_saved.c(c_mism_25),life_span);
    % c_saved_lin.d = linspace(c_saved.d(c_mism_15),c_saved.d(c_mism_25),life_span);

    % energia comprata
    e_grid_in_lin.a = linspace(e_grid_in.a(c_mism_15),e_grid_in.a(c_mism_25),life_span); %in realtà non varia
    e_grid_in_lin.b = linspace(e_grid_in.b(c_mism_15),e_grid_in.b(c_mism_25),life_span);
    e_grid_in_lin.c = linspace(e_grid_in.c(c_mism_15),e_grid_in.c(c_mism_25),life_span);
    e_grid_in_lin.d = linspace(e_grid_in.d(c_mism_15),e_grid_in.d(c_mism_25),life_span); %in realtà non varia
    e_grid_in_lin.e = linspace(e_grid_in.e(c_mism_15),e_grid_in.e(c_mism_25),life_span); %in realtà non varia

    %costo annuo legato all'acquisto di energia
    c_grid_in_lin.a = e_grid_in_lin.a * e_price_grid_in;
    c_grid_in_lin.b = e_grid_in_lin.b * e_price_grid_in;
    c_grid_in_lin.c = e_grid_in_lin.c * e_price_grid_in;
    c_grid_in_lin.d = e_grid_in_lin.d * e_price_grid_in;
    c_grid_in_lin.e = e_grid_in_lin.e * e_price_grid_in;

    % energia venduta
    e_grid_out_lin.a = linspace(e_grid_out.a(c_mism_15),e_grid_out.a(c_mism_25),life_span);
    e_grid_out_lin.b = linspace(e_grid_out.b(c_mism_15),e_grid_out.b(c_mism_25),life_span);
    e_grid_out_lin.c = linspace(e_grid_out.c(c_mism_15),e_grid_out.c(c_mism_25),life_span);
    e_grid_out_lin.d = linspace(e_grid_out.d(c_mism_15),e_grid_out.d(c_mism_25),life_span);
    e_grid_out_lin.e = linspace(e_grid_out.e(c_mism_15),e_grid_out.e(c_mism_25),life_span);

    % ricavi legati alla vendita di energia
    c_grid_out_lin.a = e_grid_out_lin.a * e_price_grid_out;
    c_grid_out_lin.b = e_grid_out_lin.b * e_price_grid_out;
    c_grid_out_lin.c = e_grid_out_lin.c * e_price_grid_out;
    c_grid_out_lin.d = e_grid_out_lin.d * e_price_grid_out;
    c_grid_out_lin.e = e_grid_out_lin.e * e_price_grid_out;

    % netto economico per ogni anno, senza considerare l'investimento iniziale
    c_tot_lin.a = -c_grid_in_lin.a + c_grid_out_lin.a;
    c_tot_lin.b = -c_grid_in_lin.b + c_grid_out_lin.b;
    c_tot_lin.c = -c_grid_in_lin.c + c_grid_out_lin.c;
    c_tot_lin.d = -c_grid_in_lin.d + c_grid_out_lin.d;
    c_tot_lin.e = -c_grid_in_lin.e + c_grid_out_lin.e;

    %soldi risparmiati ogni anno rispetto al caso "e" (ovvero quello che non
    %devo pagare in bolletta rispetto al caso in cui non avessi PV e batteria)
    c_saved_lin.a = c_tot_lin.a - c_tot_lin.e;
    c_saved_lin.b = c_tot_lin.b - c_tot_lin.e;
    c_saved_lin.c = c_tot_lin.c - c_tot_lin.e;
    c_saved_lin.d = c_tot_lin.d - c_tot_lin.e;

    % calcolo il pbt, rispetto al caso "e", dove non ho PV e batteria.
    pbt_lin.a = c_init.a / mean(c_tot_lin.a - c_tot_lin.e);
    pbt_lin.b = c_init.b / mean(c_tot_lin.b - c_tot_lin.e);
    pbt_lin.c = c_init.c / mean(c_tot_lin.c - c_tot_lin.e);
    pbt_lin.d = c_init.d / mean(c_tot_lin.d - c_tot_lin.e);

    years = 1:1:life_span;
    npv_lin.a = -c_init.a + sum(c_saved_lin.a .* (1/(1+interest_rate)).^years(:)');
    npv_lin.b = -c_init.b + sum(c_saved_lin.b .* (1/(1+interest_rate)).^years(:)');
    npv_lin.c = -c_init.c + sum(c_saved_lin.c .* (1/(1+interest_rate)).^years(:)');
    npv_lin.d = -c_init.d + sum(c_saved_lin.d .* (1/(1+interest_rate)).^years(:)');
% %%%%%%%%%%%%%%%%%%%%%%

figure(1); tiledlayout(1,2);
nexttile(1); hold on;
npv_values(1,:) = npv.a;
npv_values(2,:) = npv.b;
npv_values(3,:) = npv.c;

labels = ["NEW BATTERY", "NO", "ALWAYS"];
plot(1:size(npv_values,1), npv_values(:,c_mism_15), '-o', 'LineWidth', 1);
plot(1:size(npv_values,1), npv_values(:,c_mism_25), '-o', 'LineWidth', 1,"LineStyle","--");
plot(1:size(npv_values,1), [npv_lin.a npv_lin.b npv_lin.c], '-o', 'LineWidth', 1,"LineStyle",":");
%plot(1:size(npv_values,1), npv_values(:,c_mism_35), '-o', 'LineWidth', 1);
xticks(1:numel(npv_values));
xticklabels(labels);
title("Net present value ");
ylabel("[€]");

nexttile(2);
hold on
%pbt_values = structfun(@(x) x, pbt);
pbt_values(1,:) = pbt.a;
pbt_values(2,:) = pbt.b;
pbt_values(3,:) = pbt.c;
plot(1:size(pbt_values,1), pbt_values(:,c_mism_15), '-o', 'LineWidth', 1);
plot(1:size(pbt_values,1), pbt_values(:,c_mism_25), '-o', 'LineWidth', 1, "LineStyle","--");
%plot(1:size(pbt_values,1), pbt_values(:,c_mism_35), '-o', 'LineWidth', 1);
plot(1:size(pbt_values,1), [pbt_lin.a pbt_lin.b pbt_lin.c], '-o', 'LineWidth', 1, "LineStyle",":"); % plot con variazione lineare
xticks(1:numel(pbt_values));
xticklabels(labels);
title("Payback time");
legend(["15%","25%","linear aging"])
ylabel("[years]")

figure;
yyaxis left
hold on;
npv_values(1,:) = npv.a;
npv_values(2,:) = npv.b;
npv_values(3,:) = npv.c;

labels = ["NEW BATTERY", "NO", "ALWAYS"];
plot(1:size(npv_values,1), npv_values(:,c_mism_15), '-o', 'LineWidth', 1, "Color",color(1,:));
plot(1:size(npv_values,1), npv_values(:,c_mism_25), '-o', 'LineWidth', 1,"Color",color(2,:));
plot(1:size(npv_values,1), [npv_lin.a npv_lin.b npv_lin.c], '-o', 'LineWidth', 1,"Color",color(3,:));
xticks(1:numel(npv_values));
xticklabels(labels);
ylabel("NPV [€]");

yyaxis right
hold on
pbt_values(1,:) = pbt.a;
pbt_values(2,:) = pbt.b;
pbt_values(3,:) = pbt.c;
plot(1:size(pbt_values,1), pbt_values(:,c_mism_15),"-*","Color",color(1,:), 'LineWidth', 1,"LineStyle","--");
plot(1:size(pbt_values,1), pbt_values(:,c_mism_25),"-*","Color",color(2,:),'LineWidth', 1, "LineStyle","--");
plot(1:size(pbt_values,1), [pbt_lin.a pbt_lin.b pbt_lin.c],"-*","Color",color(3,:), 'LineWidth',1, "LineStyle","--"); % plot con variazione lineare
xticks(1:numel(pbt_values));
xticklabels(labels);
legend(["NPV (@15%)","NPV (@25%)","NPV (@linear aging)", "PBT (@15%)", "PBT (@25%)", "PBT (@linear aging)"])
ylabel("PBT [years]")
xlabel("Scenario");
ax = gca();
ax.YAxis(1).Color = [0 0 0];
ax.YAxis(2).Color = [0 0 0];

figure;
yyaxis left
labels = ["NEW BATTERY", "NO", "ALWAYS"];
plot(1:size(npv_values,1), [npv_lin.a npv_lin.b npv_lin.c], '-o', 'LineWidth', 1);
xticks(1:numel(npv_values));
xticklabels(labels);
ylabel("NPV [€]");

yyaxis right
plot(1:size(pbt_values,1), [pbt_lin.a pbt_lin.b pbt_lin.c],"-*", 'LineWidth',1, "LineStyle","--"); % plot con variazione lineare
xticks(1:numel(pbt_values));
xticklabels(labels);
legend(["NPV", "PBT"])
ylabel("PBT [years]")
title("linear aging capacity mismatch 15-25% -  NO CAPACITY FADING")
xlabel("Scenario");

%% fig/economics - analisi economica con capacity fading 20%
set(groot, 'DefaultAxesFontName', 'Helvetica');
set(groot, 'DefaultTextFontName', 'Helvetica');
set(groot, 'DefaultAxesFontSize', 14);
set(groot, 'DefaultTextFontSize', 14);

% rifatte simulazioni del primo anno e quindicesimo anno, considerando
% capacity fading del 20% e capacity mismatch da 15% a 25%.
file_name = 'data/output/one_year_aging.mat';
load(file_name)

% considero i 3 casi:
% a) PV+new battery --> IDEAL
% b) PV+slb         --> NO_BAL
% c) PV+slb+dyn_bal --> ALWAYS
% d) PV & no battery     --> pago e_load-E_du. vendo E_pv-E_du
% e) no PV & no battery  --> pago tutto E_load, non vendo niente

% costi e variabili definibili per l'investimento
PV_cost_kwp        = 1322;%1322   % [€/kWp], costo pv+inverter -- da transaction
c_new_batt         = 676; %676;   % [€/kWh], costo new batt -- da transaction
c_slb              = 250; %400;   % [€/kWh], costo slb      -- da siti che vendono slb (83-250€/kWh + manodopera&bms), (150€ da https://www.irena.org/-/media/Files/IRENA/Agency/Publication/2019/May/IRENA_Innovation_Outlook_EV_smart_charging_2019.pdf)
c_dyn_bal          = 0;  %80;      [€], costo sistema di bilanciamento, sarebbe una variabile libera
e_price_grid_in    = .40; %.30;   % [€/kWh], costo acquisto energia (ad ottobre 2023 è arrivata a costare 0.55€/kWh, oggi 0.12)
e_price_grid_out   = .115; %.12;   % [€/kWh], ricavo vendita energia
life_span = 15;                   % [years], durata prevista dell'impianto, assumendo comportamento invariante negli anni
interest_rate = 0.04;

% dati del caso studio
PV_p_peak = 7;          %[kWp]
battery_capacity = 14;  %[kWh]
slb_soh = 0.75;
c_PV = PV_p_peak * PV_cost_kwp;
c_init.a = c_PV + c_new_batt*battery_capacity;
c_init.b = c_PV + c_slb*battery_capacity/slb_soh;
c_init.c = c_init.b + c_dyn_bal;
c_init.d = c_PV;
c_init.e = 0;

t_0 = 1;
t_end = 2;
% energia comprata
idx = 1;
e_grid_in.a(t_0) = my_out(idx).ideal.energy.E_grid_in; %[kWh]
e_grid_in.b(t_0) = my_out(idx).no_bal.energy.E_grid_in;
e_grid_in.c(t_0) = my_out(idx+1).always_bal.energy.E_grid_in;
e_grid_in.d(t_0) = my_out(idx).ideal.energy.E_load - my_out(idx).ideal.energy.E_du;
e_grid_in.e(t_0) = my_out(idx).ideal.energy.E_load;

e_grid_out.a(t_0) = -my_out(idx).ideal.energy.E_grid_out; %[kWh]
e_grid_out.b(t_0) = -my_out(idx).no_bal.energy.E_grid_out;
e_grid_out.c(t_0) = -my_out(idx+1).always_bal.energy.E_grid_out;
e_grid_out.d(t_0) = -my_out(idx).ideal.energy.E_pv - my_out(idx).ideal.energy.E_du;
e_grid_out.e(t_0) = 0; 

idx = 3;
e_grid_in.a(t_end) = my_out(idx).ideal.energy.E_grid_in; %[kWh]
e_grid_in.b(t_end) = my_out(idx).no_bal.energy.E_grid_in;
e_grid_in.c(t_end) = my_out(idx+1).always_bal.energy.E_grid_in;
e_grid_in.d(t_end) = my_out(idx).ideal.energy.E_load - my_out(idx).ideal.energy.E_du;
e_grid_in.e(t_end) = my_out(idx).ideal.energy.E_load;

e_grid_out.a(t_end) = -my_out(idx).ideal.energy.E_grid_out; %[kWh]
e_grid_out.b(t_end) = -my_out(idx).no_bal.energy.E_grid_out;
e_grid_out.c(t_end) = -my_out(idx+1).always_bal.energy.E_grid_out;
e_grid_out.d(t_end) = -my_out(idx).ideal.energy.E_pv - my_out(idx).ideal.energy.E_du;
e_grid_out.e(t_end) = 0;

e_grid_in_lin.a = linspace(e_grid_in.a(t_0),e_grid_in.a(t_end),life_span); %in realtà non varia
e_grid_in_lin.b = linspace(e_grid_in.b(t_0),e_grid_in.b(t_end),life_span);
e_grid_in_lin.c = linspace(e_grid_in.c(t_0),e_grid_in.c(t_end),life_span);
e_grid_in_lin.d = linspace(e_grid_in.d(t_0),e_grid_in.d(t_end),life_span); %in realtà non varia
e_grid_in_lin.e = linspace(e_grid_in.e(t_0),e_grid_in.e(t_end),life_span); %in realtà non varia
e_grid_out_lin.a = linspace(e_grid_out.a(t_0),e_grid_out.a(t_end),life_span); %in realtà non varia
e_grid_out_lin.b = linspace(e_grid_out.b(t_0),e_grid_out.b(t_end),life_span);
e_grid_out_lin.c = linspace(e_grid_out.c(t_0),e_grid_out.c(t_end),life_span);
e_grid_out_lin.d = linspace(e_grid_out.d(t_0),e_grid_out.d(t_end),life_span); %in realtà non varia
e_grid_out_lin.e = linspace(e_grid_out.e(t_0),e_grid_out.e(t_end),life_span); %in realtà non varia

%costo annuo legato all'acquisto di energia
c_grid_in_lin.a = e_grid_in_lin.a * e_price_grid_in;
c_grid_in_lin.b = e_grid_in_lin.b * e_price_grid_in;
c_grid_in_lin.c = e_grid_in_lin.c * e_price_grid_in;
c_grid_in_lin.d = e_grid_in_lin.d * e_price_grid_in;
c_grid_in_lin.e = e_grid_in_lin.e * e_price_grid_in;

% energia venduta
e_grid_out_lin.a = linspace(e_grid_out.a(t_0),e_grid_out.a(t_end),life_span);
e_grid_out_lin.b = linspace(e_grid_out.b(t_0),e_grid_out.b(t_end),life_span);
e_grid_out_lin.c = linspace(e_grid_out.c(t_0),e_grid_out.c(t_end),life_span);
e_grid_out_lin.d = linspace(e_grid_out.d(t_0),e_grid_out.d(t_end),life_span);
e_grid_out_lin.e = linspace(e_grid_out.e(t_0),e_grid_out.e(t_end),life_span);

% ricavi legati alla vendita di energia
c_grid_out_lin.a = e_grid_out_lin.a * e_price_grid_out;
c_grid_out_lin.b = e_grid_out_lin.b * e_price_grid_out;
c_grid_out_lin.c = e_grid_out_lin.c * e_price_grid_out;
c_grid_out_lin.d = e_grid_out_lin.d * e_price_grid_out;
c_grid_out_lin.e = e_grid_out_lin.e * e_price_grid_out;

% netto economico per ogni anno, senza considerare l'investimento iniziale
c_tot_lin.a = -c_grid_in_lin.a + c_grid_out_lin.a;
c_tot_lin.b = -c_grid_in_lin.b + c_grid_out_lin.b;
c_tot_lin.c = -c_grid_in_lin.c + c_grid_out_lin.c;
c_tot_lin.d = -c_grid_in_lin.d + c_grid_out_lin.d;
c_tot_lin.e = -c_grid_in_lin.e + c_grid_out_lin.e;

%soldi risparmiati ogni anno rispetto al caso "e" (ovvero quello che non
%devo pagare in bolletta rispetto al caso in cui non avessi PV e batteria)
c_saved_lin.a = c_tot_lin.a - c_tot_lin.e;
c_saved_lin.b = c_tot_lin.b - c_tot_lin.e;
c_saved_lin.c = c_tot_lin.c - c_tot_lin.e;
c_saved_lin.d = c_tot_lin.d - c_tot_lin.e;

% calcolo il pbt, rispetto al caso "e", dove non ho PV e batteria.
pbt_lin.a = c_init.a / mean(c_tot_lin.a - c_tot_lin.e);
pbt_lin.b = c_init.b / mean(c_tot_lin.b - c_tot_lin.e);
pbt_lin.c = c_init.c / mean(c_tot_lin.c - c_tot_lin.e);
pbt_lin.d = c_init.d / mean(c_tot_lin.d - c_tot_lin.e);

years = 1:1:life_span;
npv_lin.a = -c_init.a + sum(c_saved_lin.a .* (1/(1+interest_rate)).^years(:)');
npv_lin.b = -c_init.b + sum(c_saved_lin.b .* (1/(1+interest_rate)).^years(:)');
npv_lin.c = -c_init.c + sum(c_saved_lin.c .* (1/(1+interest_rate)).^years(:)');
npv_lin.d = -c_init.d + sum(c_saved_lin.d .* (1/(1+interest_rate)).^years(:)');

figure;
yyaxis left
labels = ["NEW BATTERY", "NEVER", "ALWAYS"];
plot(1:3, [npv_lin.a npv_lin.b npv_lin.c], '-o', 'LineWidth', 1);
xticks(1:3);
xticklabels(labels);
ytickformat('eur');
ylabel("NPV");

yyaxis right
plot(1:3, [pbt_lin.a pbt_lin.b pbt_lin.c],"-*", 'LineWidth',1, "LineStyle","--"); % plot con variazione lineare
xticks(1:3);
xticklabels(labels);
legend(["NPV", "PBT"])
ylabel("PBT [years]")
title("linear capacity fading 20% in 15y")
xlabel("Scenario");

figure;
yyaxis left
bar(1:3, [npv_lin.a npv_lin.b npv_lin.c]);
xticks(1:3);
xticklabels(labels);
%ytickformat('eur');
ylabel("NPV (1000 \euro)");
yticks([3000 6000 9000 12000 15000 18000])

yyaxis right
bar(1:3, [pbt_lin.a pbt_lin.b pbt_lin.c]);%,"-*", 'LineWidth',2); % plot con variazione lineare
xticks(1:3);
xticklabels(labels);
ylim([4 8])
legend(["NPV", "PBT"])
ylabel("PBT (years)")

fig = gcf;
fig.Position = [100, 100, 700, 500]; % Larghezza x Altezza in pixel
exportgraphics(fig, 'fig\economic_analisys.pdf', 'ContentType', 'vector','Resolution', 300);
%% local functions

function add_label_metadata(sim,file_name,scenario_index)
metadata = sprintf("METADATA:  Cnom=%.1f, Cvar=%d%%, eff=%.1f, Ibal=%s, %s, scenario id nel file:%.0f", sim.metadata.c_nom, sim.metadata.c_var*100, sim.metadata.eff, sim.metadata.I_bal_str, file_name,scenario_index );
txt_pos = [0.001 0.9 0.1 0.1];
txt = annotation('textbox',txt_pos, 'String',metadata);
end

function [no_bal_year,always_bal_year,opt_bal_year,ideal_year ] = split_scenarios(file_name,ref_scenario,id_scenario)
load(file_name)

% nella dimensione 1(raw) di sim_year ci sono i vari mesi
% nella dimensione 2(col) di sim_year ci sono i vari scenari, al variare di
% i_bal, eff, c_var... tra questi ci sono anche i reference scenario
% es.
%          ref   scen_1   scen_2   scen_3
%   gen |  --  |   --   |   --   |   --   |
%   feb |  --  |   --   |   --   |   --   |
%   marz|  --  |   --   |   --   |   --   |

% colonna: 1   reference  c_nom = 400, C_var = 0.15,
% colonna: 2:4 eff=0.7, i_bal= c/10,c/25,c/50
% colonna: 5:7 eff=0.9,  "       "   "   "
% colonna: 8     reference  c_nom = 400, C_var = 0.25,
% colonna: 9:11  eff=0.7, i_bal= c/10,c/25,c/50
% colonna: 12:14 eff=0.9,  "       "   "   "


% NB: ref_scenario deve essere coerente con le impostazioni di id_scenario,
%
% ref_scenario = 21;
% id_scenario = [22:25];

%le variabili estratte dal semestre le creo usando una riga per ogni
%scenario, e poi le variabili sono vettori con un elemento per mese.
% Opt_bal in aggiunta ha una colonna per ogni horizon

no_bal_year = []; % variabili estratte semestrali
ideal_year = [];
always_bal_year = [];
opt_bal_year = [];
aux_cmp = [];

for i=1:length(id_scenario)
    sel = id_scenario(i);
    for month=1:size(sim_year,1)
        no_bal_year(i).energy.E_load(month)       = sim_year(month,ref_scenario).no_bal.energy.E_load;
        no_bal_year(i).energy.E_pv(month)         = sim_year(month,ref_scenario).no_bal.energy.E_pv;
        no_bal_year(i).energy.E_batt(month)       = sim_year(month,ref_scenario).no_bal.energy.E_batt;
        no_bal_year(i).energy.E_du(month)         = sim_year(month,ref_scenario).no_bal.energy.E_du;
        no_bal_year(i).energy.E_bc(month)         = sim_year(month,ref_scenario).no_bal.energy.E_bc;
        no_bal_year(i).energy.E_bd(month)         = sim_year(month,ref_scenario).no_bal.energy.E_bd;
        no_bal_year(i).energy.E_grid_out(month)   = sim_year(month,ref_scenario).no_bal.energy.E_grid_out;
        no_bal_year(i).energy.E_grid_in(month)    = sim_year(month,ref_scenario).no_bal.energy.E_grid_in;
        no_bal_year(i).energy.E_balanced(month)   = sim_year(month,ref_scenario).no_bal.energy.E_balanced;
        no_bal_year(i).energy.E_lost(month)       = sim_year(month,ref_scenario).no_bal.energy.E_lost;
        no_bal_year(i).ss(month)                  = sim_year(month,ref_scenario).no_bal.ss;
        no_bal_year(i).sc(month)                  = sim_year(month,ref_scenario).no_bal.sc;

        % controllo che per i vari mesi ci siano gli stessi metadata, in
        % modo da esser sicuro che le simulazioni sono coerenti per gli
        % input
        if month == 1
            no_bal_year(i).metadata.c_nom      = sim_year(month,ref_scenario).c_nom;
            no_bal_year(i).metadata.c_var      = sim_year(month,ref_scenario).c_var;
            no_bal_year(i).metadata.I_bal      = sim_year(month,ref_scenario).I_bal;
            no_bal_year(i).metadata.I_bal_str  = sim_year(month,ref_scenario).I_bal_str;
            no_bal_year(i).metadata.eff        = sim_year(month,ref_scenario).eff;
        else
            aux_cmp(1) = no_bal_year(i).metadata.c_nom      - sim_year(month,ref_scenario).c_nom;
            aux_cmp(2) = no_bal_year(i).metadata.c_var      - sim_year(month,ref_scenario).c_var;
            if any(aux_cmp ~= 0)
                error "simulazioni con metadata diversi"
            end
        end

        ideal_year(i).energy.E_load(month)       = sim_year(month,ref_scenario).ideal.energy.E_load;
        ideal_year(i).energy.E_pv(month)         = sim_year(month,ref_scenario).ideal.energy.E_pv;
        ideal_year(i).energy.E_batt(month)       = sim_year(month,ref_scenario).ideal.energy.E_batt;
        ideal_year(i).energy.E_du(month)         = sim_year(month,ref_scenario).ideal.energy.E_du;
        ideal_year(i).energy.E_bc(month)         = sim_year(month,ref_scenario).ideal.energy.E_bc;
        ideal_year(i).energy.E_bd(month)         = sim_year(month,ref_scenario).ideal.energy.E_bd;
        ideal_year(i).energy.E_grid_out(month)   = sim_year(month,ref_scenario).ideal.energy.E_grid_out;
        ideal_year(i).energy.E_grid_in(month)    = sim_year(month,ref_scenario).ideal.energy.E_grid_in;
        ideal_year(i).energy.E_balanced(month)   = sim_year(month,ref_scenario).ideal.energy.E_balanced;
        ideal_year(i).energy.E_lost(month)       = sim_year(month,ref_scenario).ideal.energy.E_lost;
        ideal_year(i).ss(month)                  = sim_year(month,ref_scenario).ideal.ss;
        ideal_year(i).sc(month)                  = sim_year(month,ref_scenario).ideal.sc;
        if month == 1
            ideal_year(i).metadata.c_nom      = sim_year(month,ref_scenario).c_nom;
            ideal_year(i).metadata.c_var      = sim_year(month,ref_scenario).c_var;
            ideal_year(i).metadata.I_bal      = sim_year(month,ref_scenario).I_bal;
            ideal_year(i).metadata.I_bal_str  = sim_year(month,ref_scenario).I_bal_str;
            ideal_year(i).metadata.eff        = sim_year(month,ref_scenario).eff;
        else
            aux_cmp(1) = ideal_year(i).metadata.c_nom - sim_year(month,ref_scenario).c_nom;
            aux_cmp(2) = ideal_year(i).metadata.c_var - sim_year(month,ref_scenario).c_var;
            if any(aux_cmp ~= 0)
                error simulazioni con metadata diversi
            end
        end
        always_bal_year(i).energy.E_load(month)       = sim_year(month,sel).always_bal.energy.E_load;
        always_bal_year(i).energy.E_pv(month)         = sim_year(month,sel).always_bal.energy.E_pv;
        always_bal_year(i).energy.E_batt(month)       = sim_year(month,sel).always_bal.energy.E_batt;
        always_bal_year(i).energy.E_du(month)         = sim_year(month,sel).always_bal.energy.E_du;
        always_bal_year(i).energy.E_bc(month)         = sim_year(month,sel).always_bal.energy.E_bc;
        always_bal_year(i).energy.E_bd(month)         = sim_year(month,sel).always_bal.energy.E_bd;
        always_bal_year(i).energy.E_grid_out(month)   = sim_year(month,sel).always_bal.energy.E_grid_out;
        always_bal_year(i).energy.E_grid_in(month)    = sim_year(month,sel).always_bal.energy.E_grid_in;
        always_bal_year(i).energy.E_balanced(month)   = sim_year(month,sel).always_bal.energy.E_balanced;
        always_bal_year(i).energy.E_lost(month)       = sim_year(month,sel).always_bal.energy.E_lost;
        always_bal_year(i).ss(month)                  = sim_year(month,sel).always_bal.ss;
        always_bal_year(i).sc(month)                  = sim_year(month,sel).always_bal.sc;
        if month == 1
            always_bal_year(i).metadata.c_nom      = sim_year(month,sel).c_nom;
            always_bal_year(i).metadata.c_var      = sim_year(month,sel).c_var;
            always_bal_year(i).metadata.I_bal      = sim_year(month,sel).I_bal;
            always_bal_year(i).metadata.I_bal_str  = sim_year(month,sel).I_bal_str;
            always_bal_year(i).metadata.eff        = sim_year(month,sel).eff;
        else
            aux_cmp(1) = always_bal_year(i).metadata.c_nom - sim_year(month,sel).c_nom;
            aux_cmp(2) = always_bal_year(i).metadata.c_var - sim_year(month,sel).c_var;
            aux_cmp(3) = always_bal_year(i).metadata.I_bal - sim_year(month,sel).I_bal;
            aux_cmp(4) = always_bal_year(i).metadata.eff   - sim_year(month,sel).eff;
            if any(aux_cmp ~= 0)
                error simulazioni con metadata diversi
            end
        end
        for h=1:length(sim_year(month,sel).opt_bal)
            opt_bal_year(i,h).energy.E_load(month)       = sim_year(month,sel).opt_bal(h).energy.E_load;
            opt_bal_year(i,h).energy.E_pv(month)         = sim_year(month,sel).opt_bal(h).energy.E_pv;
            opt_bal_year(i,h).energy.E_batt(month)       = sim_year(month,sel).opt_bal(h).energy.E_batt;
            opt_bal_year(i,h).energy.E_du(month)         = sim_year(month,sel).opt_bal(h).energy.E_du;
            opt_bal_year(i,h).energy.E_bc(month)         = sim_year(month,sel).opt_bal(h).energy.E_bc;
            opt_bal_year(i,h).energy.E_bd(month)         = sim_year(month,sel).opt_bal(h).energy.E_bd;
            opt_bal_year(i,h).energy.E_grid_out(month)   = sim_year(month,sel).opt_bal(h).energy.E_grid_out;
            opt_bal_year(i,h).energy.E_grid_in(month)    = sim_year(month,sel).opt_bal(h).energy.E_grid_in;
            opt_bal_year(i,h).energy.E_balanced(month)   = sim_year(month,sel).opt_bal(h).energy.E_balanced;
            opt_bal_year(i,h).energy.E_lost(month)       = sim_year(month,sel).opt_bal(h).energy.E_lost;
            opt_bal_year(i,h).ss(month)                  = sim_year(month,sel).opt_bal(h).ss;
            opt_bal_year(i,h).sc(month)                  = sim_year(month,sel).opt_bal(h).sc;
            if month == 1
                opt_bal_year(i,h).metadata.c_nom      = sim_year(month,sel).c_nom;
                opt_bal_year(i,h).metadata.c_var      = sim_year(month,sel).c_var;
                opt_bal_year(i,h).metadata.I_bal      = sim_year(month,sel).I_bal;
                opt_bal_year(i,h).metadata.I_bal_str  = sim_year(month,sel).I_bal_str;
                opt_bal_year(i,h).metadata.eff        = sim_year(month,sel).eff;
                opt_bal_year(i,h).metadata.horizon    = sim_year(month,sel).opt_bal(h).horizon;
            else
                aux_cmp(1) = opt_bal_year(i,h).metadata.c_nom - sim_year(month,sel).c_nom;
                aux_cmp(2) = opt_bal_year(i,h).metadata.c_var - sim_year(month,sel).c_var;
                aux_cmp(3) = opt_bal_year(i,h).metadata.I_bal - sim_year(month,sel).I_bal;
                aux_cmp(4) = opt_bal_year(i,h).metadata.eff   - sim_year(month,sel).eff;
                if any(aux_cmp ~= 0)
                    error simulazioni con metadata diversi
                end
            end
        end
    end
end
end



