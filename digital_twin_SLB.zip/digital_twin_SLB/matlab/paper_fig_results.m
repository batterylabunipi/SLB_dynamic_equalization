%% fig/ss_sc_one_year
% grafico per i 12 mesi dei valori di SS e SC per batterie di diverse
% capacità (simulando la batteria nuova, senza mismatch di capacità

set(groot, 'DefaultAxesFontName', 'Helvetica');
set(groot, 'DefaultTextFontName', 'Helvetica');
set(groot, 'DefaultAxesFontSize', 14);
set(groot, 'DefaultTextFontSize', 14);

load("data/output/ss_sc_ideal.mat"); 
month_list = [ 1,32,60,91,121,152,182,213,244,274,305,335];
capacity_list = [100,200,300,400,500,600];
ss = [];
sc = [];
legend_str = "";
% accorpa dati nei vettori ss,sc
for j=1:length(capacity_list)
    i=j-1;
    for m=1:length(month_list)
        ss(j,m) = my_out(m+i*12).ideal.ss;
        sc(j,m) = my_out(m+i*12).ideal.sc;
    end
    legend_str(j) = sprintf("%.1f kWh",capacity_list(j)*3.5*10/1e3);
end

figure; 
tiledlayout(2,1,"TileSpacing", "compact");
nexttile;hold on;   
for j=1:length(capacity_list)
    if capacity_list(j) == 400
        plot(ss(j,:), '-*', LineWidth=1.2)
    else
        plot(ss(j,:))
    end
end

x_text_label = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul","Aug", "Sept", "Oct", "Nov", "Dec"];
xticks(linspace(1,length(month_list),12));
xticklabels(x_text_label);
xlim([1 12])
legend(legend_str,'NumColumns',6,'Location','northoutside')
ylabel('Self Sufficiency [%]')

nexttile;hold on;
for j=1:length(capacity_list)
    if capacity_list(j) == 400
        plot(sc(j,:), '-*', LineWidth=1.2)
    else
        plot(sc(j,:))
    end
end

x_text_label = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul","Aug", "Sept", "Oct", "Nov", "Dec"];
xticks(linspace(1,length(month_list),12));
xticklabels(x_text_label);
xlim([1 12])
ylabel("Self Consumption [%]")

fig = gcf;
fig.Position = [100, 100, 800, 500]; % Larghezza x Altezza in pixel
exportgraphics(fig, 'fig\ss_sc_one_year.pdf', 'ContentType', 'vector','Resolution', 300);
%% plot stima tempo di bilanciamento(horizon) in base a i_bal
% in base allo stato della batteria (c_nom, c_var), calcolo lo
% sbilanciamento da compensare e per ciascuna corrente mi stimo il tempo
% necessario (HP: eff=1 e funzionamento continuo)

batt.n_cell = 10;
batt.c_nom = 400; %[Ah]
batt.c_var = 0.25; % percentuale

c_min = batt.c_nom * (1-batt.c_var);
c_max = batt.c_nom * (1+batt.c_var);
batt.c_cell = [c_min:(c_max-c_min)/(batt.n_cell-1):c_max];

i_bal = batt.c_nom ./ [10, 25, 50];

c_mismatch = sum(abs(batt.c_cell - batt.c_nom))/2; %[Ah] %capacità da spostare in tot per bilanciare, la divisione per 2 perchè con DC2C agisco su due celle alla volta in modo complementare

t_bal = c_mismatch ./ i_bal;

fprintf("c_nom=%.1f +- %.0f%% Ah, overall mismatch=%.3fAh, servono: \n",batt.c_nom, batt.c_var*100, c_mismatch);
for i=1:length(t_bal)
    fprintf("\t Ibal=%.1fAh (%s) --> %.1fh\n", i_bal(i), Ah_to_Crate(i_bal(i), batt.c_nom), t_bal(i));
end
%% plot stima corrente di bilanciamento in base all'orizzonte di preavviso
% in base allo stato della batteria (c_nom, c_var), calcolo lo
% sbilanciamento da compensare e per ciascuna corrente mi stimo la corrente
% di bilanciamento che mi servirebbe (HP: eff=1 e funzionamento continuo)
% OSS: rispetto allo script precedente inverto input/output
mismatch = [0.10 0.15 0.25 0.35];

batt.n_cell = 10;
batt.c_nom = 400; %[Ah]

fg = figure; hold on;
legend_str = "";
for j=1:length(mismatch)
    batt.c_var = mismatch(j); % percentuale

    c_min = batt.c_nom * (1-batt.c_var);
    c_max = batt.c_nom * (1+batt.c_var);
    batt.c_cell = [c_min:(c_max-c_min)/(batt.n_cell-1):c_max];

    c_mismatch = sum(abs(batt.c_cell - batt.c_nom))/2; %[Ah] %capacità da spostare in tot per bilanciare, la divisione per 2 perchè con DC2C agisco su due celle alla volta in modo complementare


    t_bal = [1:12]; %[h] % lunghezza horizon (è il preavviso per iniziare a bilanciare

    i_bal = c_mismatch ./ t_bal;


    fprintf("c_nom=%.1f +- %.0f%% Ah, overall mismatch=%.3fAh, servono: \n",batt.c_nom, batt.c_var*100, c_mismatch);
    for i=1:length(t_bal)
        fprintf("\t horizon: %.1fh  --> Ibal=%.1fA ( %s )\n",  t_bal(i), i_bal(i), Ah_to_Crate(i_bal(i), batt.c_nom));
    end

    legend_str(j) = sprintf("%.0f%%", batt.c_var*100);
    plot(t_bal, i_bal, '-*');
end

xlabel("T_{horizon} [h]");
ylabel("I_{eq}");
title("Equalization current estimation @ C_{nom} = 14 kWh")
grid on
yticks( [0 batt.c_nom/50 batt.c_nom/25 batt.c_nom/15 batt.c_nom/10 batt.c_nom/2] );
y_labels = {'0',
    Ah_to_Crate(batt.c_nom/50,batt.c_nom),
    Ah_to_Crate(batt.c_nom/25,batt.c_nom),
    Ah_to_Crate(batt.c_nom/15,batt.c_nom),
    Ah_to_Crate(batt.c_nom/10,batt.c_nom),
    Ah_to_Crate(batt.c_nom/2,batt.c_nom)};
yticklabels(y_labels);
ylim([0 250]);
lgd = legend(legend_str);
lgd.Title.String = ['max capacity',sprintf('\n'),' mismatch'];
lgd.Title.FontSize = 10;


annotation(fg ,'textbox',...
    [0.565315476190473 0.359084247176903 0.301428578189441 0.103809525716873],...
    'String',['typical charge/discharge',sprintf('\n'),'time expected'],...
    'EdgeColor',[1 1 1]);
annotation(fg,'doublearrow',[0.522857142857143 0.898571428571429],...
    [0.360904761904763 0.361904761904762]);

%% fig/year_power_profile 
set(groot, 'DefaultAxesFontName', 'Helvetica');
set(groot, 'DefaultTextFontName', 'Helvetica');
set(groot, 'DefaultAxesFontSize', 6);
set(groot, 'DefaultTextFontSize', 6);

load('data\input_profile\load_profile_raw.mat');    %[kW]
load('data\input_profile\PV_irr_raw.mat');          %[W]

load_profile_resampled.P = mean(reshape(load_profile_raw.P(1:end),15,[]))'; %[kW]
load_profile_resampled.P = load_profile_resampled.P * 1e3;                      %[W]
load_profile_resampled.t = reshape(load_profile_raw.t(1:end),15,[])';
load_profile_resampled.t = load_profile_resampled.t(:,1);

p_pk=7; %KW
p_du = load_profile_resampled.P - pv_profile_raw.I*p_pk;
window_length = 96*1; % n. di campioni d 15 min in 24h
p_du_filtered = movmean(p_du, window_length);

fig_pos = [5 5 8.8 4];   %[left bottom width height] column wide (88 millimeters) or page wide 181 millimeters
fig=figure; 
set(gcf, 'Units','centimeters','Position', fig_pos);
fig.PaperSize = fig.Position(3:4);

ax =axes('Units','centimeters','Box','on');
set(ax, 'FontSize',8,'FontName','Helvetica');
hold on; grid on;

plot(ax,p_du/1e3);
plot(ax,p_du_filtered/1e3, 'LineWidth',1.2);
ylabel(ax,"Power [kW]");
title("Difference between PV production and load demand")
legend(["raw","filtered 24h"], 'Position',[0.6066 0.2013 0.2974 0.199]);
x_text_label = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul","Aug", "Sept", "Oct", "Nov", "Dec"];
N = length(load_profile_resampled.t);
xticks(linspace(1,N,13));
xticklabels(x_text_label);
xlim([0 N])

%fig = gcf;
%fig.Position = [100, 100, 1200, 300]; % Larghezza x Altezza in pixel
%exportgraphics(fig, 'fig\year_power_profile.pdf', 'ContentType', 'vector','Resolution', 300);
print -dpdf 'fig\year_power_profile.pdf'
%% plot finto p_batt e SoC per creare immagine drawio

C_batt = 30; % Capacità della batteria in kWh
efficiency = 0.95; % Efficienza di carica/scarica (assunta simmetrica)

dt = 30/60; % Passo temporale in ore (30 minuti)
t_hours = 0:dt:24; % Tempo in ore

P_PV = 5 * exp(-((t_hours - 12) / 4).^2); 

P_load = 2 * sin(2 * pi * t_hours / 24) + 1.5 * sin(2 * pi * t_hours / 6);
P_load = P_load + 0.5 * randn(size(P_load)); % Aggiunta di rumore casuale

P_batt = P_load - P_PV + 1*mean(P_PV);

% Smussamento del profilo
P_batt = smoothdata(P_batt, 'movmean', 3);

% Calcolo del SoC
SoC = zeros(size(P_batt)); 
SoC(1) = 20; 

for i = 2:length(P_batt)
    E_delta = P_batt(i-1) * dt * efficiency; % Energia trasferita (in kWh)
    SoC(i) = SoC(i-1) + (E_delta / C_batt) * 100; % Aggiornamento SoC in percentuale
end

% Limiti SoC tra 0% e 100%
SoC(SoC > 100) = 100;
SoC(SoC < 0) = 0;

split_idx = find(t_hours >= 6, 1); % Indice della separazione

t_datetime = datetime(2025,1,1,0,0,0) + hours(t_hours); % Vettore temporale

figure; tiledlayout(2,1)
fontSize = 12;
nexttile; hold on;
plot(t_datetime(1:split_idx-1), P_batt(1:split_idx-1), LineWidth=2, Color='b');
plot(t_datetime(split_idx:end), P_batt(split_idx:end), LineWidth=2, LineStyle="--",Color='b');
title("Battery Power Profile",'FontSize', fontSize)
xticklabels({})
%yticklabels({})
ylabel('[kW]','FontSize', fontSize);
xlabel('time','FontSize', fontSize);
xsecondarylabel("")

nexttile; hold on;
plot(t_datetime(1:split_idx-1), SoC(1:split_idx-1), LineWidth=2,Color='r');
plot(t_datetime(split_idx:end), SoC(split_idx:end), LineWidth=2,LineStyle="--", Color='r');
ylim([0 100])
ylabel('SoC (%)','FontSize', fontSize);
xlabel('time','FontSize', fontSize);
xticklabels({})
title("SoC evolution",'FontSize', fontSize)
xsecondarylabel("")


%% fig/SoC_year - plot SoC profile one year
% grafico dell'andamento del SoC per una batteria da 400Ah durante il
% periodo di un anno
set(groot, 'DefaultAxesFontName', 'Helvetica');
set(groot, 'DefaultTextFontName', 'Helvetica');
set(groot, 'DefaultAxesFontSize', 18);
set(groot, 'DefaultTextFontSize', 18);

load("data/output/SoC_one_year.mat");

fig=figure; 

% fig_pos = [5 5 24 8];   %[left bottom width height] column wide (88 millimeters) or page wide 181 millimeters
% set(gcf, 'Units','centimeters','Position', fig_pos);
% fig.PaperSize = fig.Position(3:4);
% 
% ax =axes('Units','centimeters','Box','on');
% set(ax, 'FontSize',8,'FontName','Helvetica');

SoC_decimated = my_out(1).ideal.SoC_profile*100;
plot(downsample(SoC_decimated,5));
x_text_label = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul","Aug", "Sept", "Oct", "Nov", "Dec",""];
N = my_out.ideal.SoC_profile.Time(end);
xticks(linspace(1,N,13));
xticklabels(x_text_label);
xlim([0 N])
ylabel('SoC [%]');
xlabel("")
title("One year SoC profile")

annotation(fig,'textbox',...
    [0.1376 0.686 0.1243 0.0559],...
    'String',{'partial cycle'},...
    'LineStyle','none',...
    'FitBoxToText','off');
annotation(fig,'doublearrow',[0.1326 0.248],...
    [0.639 0.639],'LineWidth',1);
annotation(fig,'textbox',...
    [0.4953 0.327 0.1253 0.0559],...
    'String',{'partial cycle'},...
    'LineStyle','none',...
    'FitBoxToText','off');
annotation(fig,'doublearrow',[0.4936 0.606],...
    [0.271 0.271],'LineWidth',1);
annotation(fig,'textbox',...
    [0.7806 0.657 0.119 0.0559],...
    'String',{'partial cycle'},...
    'LineStyle','none',...
    'FitBoxToText','off');
annotation(fig,'doublearrow',[0.782 0.894],...
    [0.604 0.604],'LineWidth',1);

fig.Position = [100, 100, 1200, 400]; % Larghezza x Altezza in pixel
exportgraphics(fig, 'fig\SoC_year.pdf', 'ContentType', 'image','Resolution', 500);
% print -dpdf 'fig\SoC_year2.pdf'

%% fig/partial_cycle_soc - grafico ALWAYS vs NEVER --> need of smart equalization algorithm
% grafico in cui faccio vedere che in un ciclo parziale non è necessario
% bilanciare. simulo un giorno impostando come SoC iniziale 100%

set(groot, 'DefaultAxesFontName', 'Helvetica');
set(groot, 'DefaultTextFontName', 'Helvetica');
set(groot, 'DefaultAxesFontSize', 11);
set(groot, 'DefaultTextFontSize', 11);

id = 1;
load("data/output/one_day.mat");

h_start = 15+24*1;
h_end = h_start+24;
t_start = h_start*3600/10+1;
t_end = h_end*3600/10;

month = round(my_out(id).sim_start_day/31);
day = mod(my_out(id).sim_start_day,31);
t = my_out(id).no_bal.SoC_profile.Time(t_start : t_end);
t_datetime = datetime(2018,month,day,0,0,0) + seconds(t);
t_datetime.Format = ' d/MM  HH:mm:ss';

% plot SoC plot
fig = figure; 
tiledlayout(2,1);
nexttile; 
soc_always = reshape(my_out(id+1).always_bal.SoC_profile.Data(:,:,t_start:t_end), [10,size(t_datetime,1)]);
plot(t_datetime,soc_always*100,'DateTimeTickFormat','MM/dd HH:mm');
grid on
ylim([0 100]);
ylabel("SoC [%]")
title("Cells SoC profile - equalization system ON")
%xticks([])
xsecondarylabel(Visible='off')

nexttile; 
soc_nobal = reshape(my_out(id).no_bal.SoC_profile.Data(:,:,t_start:t_end), [10,size(t_datetime,1)]);
plot(t_datetime,soc_nobal*100,'DateTimeTickFormat','MM/dd HH:mm');
grid on
ylim([0 100]);
ylabel("SoC [%]")
title("Cells SoC profile - equalization system OFF")
xsecondarylabel(Visible='off')

%calcolo energia persa nell'intervallo mostrato dal grafico
E_loss  = trapz(my_out(id+1).always_bal.power.P_lost.Time(t_start:t_end), my_out(id+1).always_bal.power.P_lost.Data(t_start:t_end));
E_bd  = trapz(my_out(id+1).always_bal.power.P_bd.Time(t_start:t_end), my_out(id+1).always_bal.power.P_bd.Data(t_start:t_end));
fprintf("energia persa bilanciando sempre: %.2f KWs,  %.2f KWh\n", E_loss, E_loss/3.6e3)
fprintf("energia prelevata batteria: %.2f KWs, %.2f KWh\n", E_bd, E_bd/3.6e3)

annotation(fig,'textbox',...
    [0.0288 0.5069 0.0624 0.0730],'String',{'(a)'},...
    'LineStyle','none',...
    'FitBoxToText','off');
annotation(fig,'textbox',...
    [0.0288 0.0299 0.0624 0.0730],...
    'String','(b)',...
    'LineStyle','none',...
    'FitBoxToText','off');
fig = gcf;
fig.Position = [100, 100, 500, 400]; % Larghezza x Altezza in pixel
exportgraphics(fig, 'fig\partial_cycle_soc.png', 'ContentType', 'image','Resolution', 500);
%% fig/platform_behaviour_ALWAYSvsNEVER - grafico energia ALWAYS vs NEVER --> caso di ciclo completo
% grafico di due giorni, in cui mostro lo l'aumento dell'energia che il sistema
% con bilanciamento riesce  gestire. 
% DOPO IL PLOT MODIFICARLO MANUALMENTE PER INSERIRE LE LINEE VERTICALI E LE
% FRECCE. CONVIENE ESPORTARE IL PLOT CON MATLAB DALLO SCRIPT E POI
% AGGIUNGERE LA GRAFICA MANUALMENTE

set(groot, 'DefaultAxesFontName', 'Helvetica');
set(groot, 'DefaultTextFontName', 'Helvetica');
set(groot, 'DefaultAxesFontSize', 11);
set(groot, 'DefaultTextFontSize', 11);

%%load("data/output/one_day.mat");

color=[17, 138, 178;
       239, 71, 111;
       255, 209, 102;
       6, 214, 160]/255;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%id = 3;
% seleziono la finestra di ore da vedere nel grafico
% h_start = 12;
% h_end = h_start+1*24+6;
% t_start = h_start*3600/10+1;
% t_end = h_end*3600/10;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% stessi giorni del caso TWIN vs ALWAYS (ma si vede meno l'effetto positivo
% del bilanciamento
id = 9;
h_start = 0*24+12;
h_end = h_start + 3*24 -6;
t_start = h_start*3600/10+1;
t_end = h_end*3600/10;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

month = round(my_out(id).sim_start_day/31)+1;
day = mod(my_out(id).sim_start_day,31);
t = my_out(id).no_bal.SoC_profile.Time(t_start : t_end);
t_datetime = datetime(2018,month,day,0,0,0) + seconds(t);
t_datetime.Format = ' d/MM  HH:mm:ss';

soc_always = 100* reshape(my_out(id+1).always_bal.SoC_profile.Data(:,:,t_start:t_end), [10,size(t_datetime,1)]);
soc_nobal = 100* reshape(my_out(id).no_bal.SoC_profile.Data(:,:,t_start:t_end), [10,size(t_datetime,1)]);

% plot SoC plot
% figure; 
% tiledlayout(2,1);
% nexttile;
% plot(t_datetime,soc_always,'DateTimeTickFormat','MM/dd HH:mm');
% title("ALWAYS BALANCING - SoC profile")
% xsecondarylabel(Visible='off')
% nexttile;
% plot(t_datetime,soc_nobal,'DateTimeTickFormat','MM/dd HH:mm');
% title("NO BALANCING - SoC profile")
% xsecondarylabel(Visible='off')

% plot somme potenze
fig = figure; 

% Create line
annotation(fig,'line',[0.319000000000001 0.319666666666668],...
    [0.1105 0.9255],'LineWidth',1);
annotation(fig,'line',[0.265333333333334 0.266],[0.112 0.927],...
    'LineWidth',1,...
    'LineStyle','--');
annotation(fig,'arrow',[0.266666666666667 0.319333333333333],...
    [0.273 0.273],'LineWidth',1);
annotation(fig,'line',[0.84166666666667 0.842333333333336],...
    [0.1085 0.9235],'LineWidth',1);
annotation(fig,'line',[0.814000000000002 0.814666666666669],...
    [0.109 0.924],'LineWidth',1,'LineStyle','--');
annotation(fig,'arrow',[0.814000000000002 0.84],[0.29 0.29],...
    'LineWidth',1);

tiledlayout(3,1);
ax1 = nexttile;hold on;
plot(t_datetime,soc_nobal, "LineStyle","--");
plot(t_datetime,soc_always);
xlim([t_datetime(1) t_datetime(end)]);
ylabel("[%]");
legend("SoC NEVER","","","","","","","","","", "SoC ALWAYS",'NumColumns',2,'Position',[0.4291 0.9276 0.2123 0.02500])
title("Cells SoC")
xsecondarylabel(Visible='off')
ax1.TitleHorizontalAlignment = 'left';

ax2 = nexttile; hold on;
area(t_datetime, my_out(id).no_bal.power.P_grid_out.Data(t_start:t_end),"FaceColor",color(1,:),"FaceAlpha",0.7, "LineStyle", "--")
area(t_datetime, my_out(id).no_bal.power.P_grid_in.Data(t_start:t_end), "FaceColor",color(2,:),"FaceAlpha",0.7, "LineStyle", "--" )
area(t_datetime, my_out(id).no_bal.power.P_bc.Data(t_start:t_end),      "FaceColor",color(3,:),"FaceAlpha",0.7, "LineStyle", "--" )
area(t_datetime, my_out(id).no_bal.power.P_bd.Data(t_start:t_end),      "FaceColor",color(4,:),"FaceAlpha",0.7, "LineStyle", "--" )
plot(t_datetime, my_out(id).no_bal.power.P_pv.Data(t_start:t_end) + my_out(id).no_bal.power.P_load.Data(t_start:t_end), "LineWidth",2,"Color","k")
legend("E_{grid\_out}","E_{grid\_in}", "E_{bc}","E_{bd}","P_{load}-P_{pv}",'NumColumns',5,'Position',[0.3449 0.6228 0.3605 0.03100])

ylabel("[kW]")
xsecondarylabel(Visible='off')
xlim([t_datetime(1) t_datetime(end)]);
title("NEVER")
ax2.TitleHorizontalAlignment = 'left';

ax3 = nexttile;
hold on;
plot(t_datetime, my_out(id+1).always_bal.power.P_pv.Data(t_start:t_end) + my_out(id+1).always_bal.power.P_load.Data(t_start:t_end), "LineWidth",2, "Color","k")
area(t_datetime, my_out(id+1).always_bal.power.P_grid_out.Data(t_start:t_end),"FaceColor",color(1,:),"FaceAlpha",1);
area(t_datetime, my_out(id+1).always_bal.power.P_grid_in.Data(t_start:t_end) ,"FaceColor",color(2,:),"FaceAlpha",1);
area(t_datetime, my_out(id+1).always_bal.power.P_bc.Data(t_start:t_end)      ,"FaceColor",color(3,:),"FaceAlpha",1);
area(t_datetime, my_out(id+1).always_bal.power.P_bd.Data(t_start:t_end)      ,"FaceColor",color(4,:),"FaceAlpha",1);
%legend("P_{load}-P_{pv}","E_{grid\_out_n}","E_{grid\_in_n}", "E_{bc_n}","E_{bd_n}","E_{grid\_out}","E_{grid\_in}", "E_{bc}","E_{bd}")
xsecondarylabel(Visible='off')
ylabel("[kW]")
xlim([t_datetime(1) t_datetime(end)]);
title("ALWAYS")
linkaxes( [ax1 ax2 ax3], 'x')
ax3.TitleHorizontalAlignment = 'left';


fig = gcf;
fig.Position = [100, 100, 1200, 600]; % Larghezza x Altezza in pixel
exportgraphics(fig, 'fig\platform_behaviour_ALWAYSvsNEVER.pdf', 'ContentType', 'image','Resolution', 1000);

%% fig/partial_cycle_ALWAYSvsTWIN - grafico energia OPT_BAL vs ALWAYS_BAL ciclo parziale scarica
set(groot, 'DefaultAxesFontName', 'Helvetica');
set(groot, 'DefaultTextFontName', 'Helvetica');
set(groot, 'DefaultAxesFontSize', 17);
set(groot, 'DefaultTextFontSize', 17);

load("data/output/one_day.mat");

% seleziono la finestra di ore da vedere nel grafico
id = 9;
h_start = 0*24+12;
h_end = h_start + 3*24 -6;
t_start = h_start*3600/10+1;
t_end = h_end*3600/10;

month = round(my_out(id).sim_start_day/31)+1;
day = mod(my_out(id).sim_start_day,31);
t = my_out(id).no_bal.SoC_profile.Time(t_start : t_end);
t_datetime = datetime(2018,month,day,0,0,0) + seconds(t);
t_datetime.Format = ' d/MM  HH:mm:ss';

soc_always = 100* reshape(my_out(id+1).always_bal.SoC_profile.Data(:,:,t_start:t_end), [10,size(t_datetime,1)]);
soc_opt = 100* reshape(my_out(id+1).opt_bal.SoC_profile.Data(:,:,t_start:t_end), [10,size(t_datetime,1)]);

% % plot SoC plot
% figure; 
% tiledlayout(2,1);
% nexttile;
% plot(t_datetime,soc_always);
% title("ALWAYS - SoC profile")
% xsecondarylabel(Visible='off')
% nexttile;
% plot(t_datetime,soc_opt);
% title("TWIN - SoC profile")
% xsecondarylabel(Visible='off')

fig = figure; 
tiledlayout(2,1);
nexttile; hold on;
plot(t_datetime,soc_always);
plot(t_datetime,soc_opt, "--");
ylabel("[%]");
xlim([t_datetime(1) t_datetime(end)]);
xsecondarylabel("");
title("Cells SoC")
legend("SoC ALWAYS","","","","","","","","","", "SoC TWIN",'Position',[0.7496 0.8092 0.15112 0.0928]);

nexttile; hold on;
E_lost_always = cumtrapz(my_out(id+1).always_bal.power.P_lost.Time(t_start:t_end),my_out(id+1).always_bal.power.P_lost.Data(t_start:t_end)) / 3.6e3*1e3; %[Wh] (da simulink la potenza arriva in kWs)
plot(t_datetime, E_lost_always, LineWidth=1.5)
E_lost_opt = cumtrapz(my_out(id+1).opt_bal.power.P_lost.Time(t_start:t_end),my_out(id+1).opt_bal.power.P_lost.Data(t_start:t_end)) / 3.6e3*1e3;
plot(t_datetime,E_lost_opt,LineWidth=1.5);
ylabel("[Wh]");
xsecondarylabel("");
xlim([t_datetime(1) t_datetime(end)]);
title("Energy lost by DC-DC")
legend("E_{lost\_ALWAYS}","E_{lost\_TWIN}",'Position',[0.7629 0.1128 0.1398 0.1221]);

annotation(fig,'textbox',...
    [0.2028 0.5806 0.0343 0.0766],...
    'String',{'t^*'},...
    'LineStyle','none',...
    'FontWeight','bold',...
    'FontSize',18,...
    'FontName','Agency FB');
annotation(fig,'line',[0.2315 0.2315],...
    [0.926 0.1083],'LineWidth',1,'LineStyle','--');

annotation(fig,'textbox',...
    [0.0075 0.4859 0.0476 0.0646],...
    'String',{'(a)'},...
    'LineStyle','none');
annotation(fig,'textbox',...
    [0.0075 0.0146 0.04766 0.064],...
    'String',{'(b)'},...
    'LineStyle','none');

fig = gcf;
fig.Position = [100, 100, 1200, 600]; % Larghezza x Altezza in pixel
exportgraphics(fig, 'fig\partial_cycle_ALWAYSvsTWIN.pdf', 'ContentType', 'vector','Resolution', 500);

%% fig/E_loss - plot W_waste integrale
set(groot, 'DefaultAxesFontName', 'Helvetica');
set(groot, 'DefaultTextFontName', 'Helvetica');
set(groot, 'DefaultAxesFontSize', 11);
set(groot, 'DefaultTextFontSize', 11);

file_name = 'data/output/year_400Ah.mat';
load(file_name)
ref_scenario = 1;
id_scenario = [2:5];
[~,always_bal_year,opt_bal_year,~] = split_scenarios(file_name,ref_scenario,id_scenario);

scenario_index = 2; % indice della i_bal che mi interessa nelle strutture no_bal_year,always_bal_year,opt_bal_year,ideal_year
% 1=C/5, 2=C/10, 3=C/25, 4=C/50,

wasted_energy = [];
%in "wasted_energy" metto cumulativamente l'energia persa da gennaio al mese "m"
for m=1:12
    wasted_energy(1,m)= sum(opt_bal_year(scenario_index, 1).energy.E_lost(1:m)); % TWIN 3h
    wasted_energy(2,m)= sum(opt_bal_year(scenario_index, 2).energy.E_lost(1:m)); % TWIN 6h
    wasted_energy(3,m)= sum(opt_bal_year(scenario_index, 3).energy.E_lost(1:m)); % TWIN 12h
    wasted_energy(4,m)= sum(always_bal_year(scenario_index).energy.E_lost(1:m)); %always bal
end

figure;
hold on;
plot(wasted_energy(4,:), "lineWidth", 1.5);
plot(wasted_energy(3,:), "lineWidth", 1.5);
plot(wasted_energy(2,:), "lineWidth", 1.5);
plot(wasted_energy(1,:), "lineWidth", 1.5);
title("Energy loss by dynamic equalization system");
months_list = ["Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sept", "Oct", "Nov", "Dec"];
xticks([1:size(wasted_energy,2)]);
xticklabels(months_list);
xlim([1 12])
ylabel("[kWh]");
legend("ALWAYS","TWIN 12h","TWIN 6h","TWIN 3h", "Location","northwest");

fig = gcf;
fig.Position = [100, 100, 600, 400]; % Larghezza x Altezza in pixel
exportgraphics(fig, 'fig\E_loss.pdf', 'ContentType', 'image','Resolution', 500);

%% fig/energy_gain - plot E_gain_bd per i vari mesi
set(groot, 'DefaultAxesFontName', 'Helvetica');
set(groot, 'DefaultTextFontName', 'Helvetica');
set(groot, 'DefaultAxesFontSize', 15);
set(groot, 'DefaultTextFontSize', 15);

color = [0 0.4470 0.7410;
    0.8500 0.3250 0.0980;
    0.9290 0.6940 0.1250;
    0.4940 0.1840 0.5560];
file_name = 'data/output/year_400Ah.mat';
ref_scenario = 1;
id_scenario = [2:8];
[no_bal_year,always_bal_year,opt_bal_year,ideal_year ] = split_scenarios(file_name,ref_scenario,id_scenario);

scenario_index = 2; % è la riga che andrò ada analizzare di no_bal_year, always_bal_year, etc..
sel_horizon = [2,3,4]; %indice dell'orizzonte da plottare (es. [2,3] plotta solo gli orizzonti che corrispondono alla posizione 2,3 della struct opt_bal_year)


figure; hold on;
tiledlayout(2,1);
x_text_label = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul","Aug", "Sept", "Oct", "Nov", "Dec"];

nexttile(1); hold on
legend_str = [""];
E_never_bd= no_bal_year(scenario_index).energy.E_bd;
E_always_bd= always_bal_year(scenario_index).energy.E_bd;
E_ideal_bd= ideal_year(scenario_index).energy.E_bd;
E_opt_bd= opt_bal_year(scenario_index,1).energy.E_bd;
plot(E_ideal_bd,"LineStyle", "-"  , "LineWidth", 1.5)
plot(E_opt_bd, "LineStyle","-."   , "LineWidth", 1.5)
plot(E_always_bd,"LineStyle", ":" , "LineWidth", 1.5)
plot(E_never_bd, "LineStyle", "--", "LineWidth", 1.5)
title("Energy provided by the battery");
ylabel("E_{bd} [kWh]");
legend("IDEAL","TWIN", "ALWAYS","NEVER")
xticks([1:length(E_never_bd)]); xticklabels(x_text_label);
xlim([1 12])

nexttile(2); hold on
E_always_bd_gain = 100*((E_always_bd - E_never_bd)./E_never_bd);
E_opt_bd_gain  = 100*((E_opt_bd - E_never_bd)./E_never_bd);
E_ideal_bd_gain  = 100*((E_ideal_bd - E_never_bd)./E_never_bd);

area(E_ideal_bd_gain, "LineStyle","-")
area(E_opt_bd_gain,"LineStyle","-."  ) 
area(E_always_bd_gain,"LineStyle",":")
title("Energy gain");
ylabel("G [%]");
legend("IDEAL","TWIN","ALWAYS");
xticks([1:length(E_always_bd_gain)]); xticklabels(x_text_label);
xlim([1 12])

fig = gcf;
fig.Position = [100, 100, 1000, 500]; % Larghezza x Altezza in pixel
exportgraphics(fig, 'fig\energy_gain.pdf', 'ContentType', 'vector','Resolution', 300);
%% grafico NO_BAL vs ALWAYS_BAL ciclo misto
% scelgo due giorni in cui uno c'è un ciclo completo, e uno un ciclo
% parziale --> tra il giorno 148 e 156 c'è!
id = 5;

load("data/output/one_day.mat");

% seleziono la finestra di ore da vedere nel grafico
h_start = 6*24-6;
h_end = 8*24-6;
t_start = h_start*3600/10+1;
t_end = h_end*3600/10;

month = round(my_out(id).sim_start_day/31);
day = mod(my_out(id).sim_start_day,31);
t = my_out(id).no_bal.SoC_profile.Time(t_start : t_end);
t_datetime = datetime(2018,month,day,0,0,0) + seconds(t);
t_datetime.Format = ' d/MM  HH:mm:ss';

% plot SoC plot
figure; 
tiledlayout(2,1);
nexttile;
soc_always = reshape(my_out(id+1).always_bal.SoC_profile.Data(:,:,t_start:t_end), [10,size(t_datetime,1)]);
plot(t_datetime,soc_always,'DateTimeTickFormat','MM/dd HH:mm');
title("ALWAYS BALANCING - SoC profile")
xsecondarylabel(Visible='off')
nexttile;
soc_opt = reshape(my_out(id+1).opt_bal.SoC_profile.Data(:,:,t_start:t_end), [10,size(t_datetime,1)]);
plot(t_datetime,soc_opt,'DateTimeTickFormat','MM/dd HH:mm');
title("OPT BALANCING - SoC profile")
xsecondarylabel(Visible='off')

% plot somme potenze
figure; 

tiledlayout(3,1);
nexttile;
plot(t_datetime,soc_nobal);
title("full cycle")
nexttile;
hold on;
area(t_datetime, my_out(id+1).opt_bal.power.P_grid_out.Data(t_start:t_end),"FaceAlpha",0.5)
area(t_datetime, my_out(id+1).opt_bal.power.P_grid_in.Data(t_start:t_end), "FaceAlpha",0.5)
area(t_datetime, my_out(id+1).opt_bal.power.P_bc.Data(t_start:t_end),"FaceAlpha",0.5)
area(t_datetime, my_out(id+1).opt_bal.power.P_bd.Data(t_start:t_end),"FaceAlpha",0.5)
plot(t_datetime, my_out(id+1).opt_bal.power.P_pv.Data(t_start:t_end) + my_out(id).no_bal.power.P_load.Data(t_start:t_end), "LineWidth",2)
legend("E_{grid\_out}","E_{grid\_in}", "E_{bc}","E_{bd}","P_{load}-P_{pv}")
title("OPT")

nexttile;
hold on;
area(t_datetime, my_out(id+1).always_bal.power.P_grid_out.Data(t_start:t_end))
area(t_datetime, my_out(id+1).always_bal.power.P_grid_in.Data(t_start:t_end))
area(t_datetime, my_out(id+1).always_bal.power.P_bc.Data(t_start:t_end))
area(t_datetime, my_out(id+1).always_bal.power.P_bd.Data(t_start:t_end))
plot(t_datetime, my_out(id+1).always_bal.power.P_pv.Data(t_start:t_end) + my_out(id+1).always_bal.power.P_load.Data(t_start:t_end), "LineWidth",2)
legend("E_{grid\_out}","E_{grid\_in}", "E_{bc}","E_{bd}","P_{load}-P_{pv}")
title("ALWAYS")


%% local functions
function [no_bal_year,always_bal_year,opt_bal_year,ideal_year ] = split_scenarios(file_name,ref_scenario,id_scenario)
load(file_name)

% nella dimensione 1(raw) di sim_year ci sono i vari mesi
% nella dimensione 2(col) di sim_year ci sono i vari scenari, al variare di
% i_bal, eff, c_var... tra questi ci sono anche i reference scenario
% es.
%          ref   scen_1   scen_2   scen_3
%   gen |  --  |   --   |   --   |   --   |
%   feb |  --  |   --   |   --   |   --   |
%   marz|  --  |   --   |   --   |   --   |

% colonna: 1   reference  c_nom = 400, C_var = 0.15,
% colonna: 2:4 eff=0.7, i_bal= c/10,c/25,c/50
% colonna: 5:7 eff=0.9,  "       "   "   "
% colonna: 8     reference  c_nom = 400, C_var = 0.25,
% colonna: 9:11  eff=0.7, i_bal= c/10,c/25,c/50
% colonna: 12:14 eff=0.9,  "       "   "   "


% NB: ref_scenario deve essere coerente con le impostazioni di id_scenario,
%
% ref_scenario = 21;
% id_scenario = [22:25];

%le variabili estratte dal semestre le creo usando una riga per ogni
%scenario, e poi le variabili sono vettori con un elemento per mese.
% Opt_bal in aggiunta ha una colonna per ogni horizon

no_bal_year = []; % variabili estratte semestrali
ideal_year = [];
always_bal_year = [];
opt_bal_year = [];
aux_cmp = [];

for i=1:length(id_scenario)
    sel = id_scenario(i);
    for month=1:size(sim_year,1)
        no_bal_year(i).energy.E_load(month)       = sim_year(month,ref_scenario).no_bal.energy.E_load;
        no_bal_year(i).energy.E_pv(month)         = sim_year(month,ref_scenario).no_bal.energy.E_pv;
        no_bal_year(i).energy.E_batt(month)       = sim_year(month,ref_scenario).no_bal.energy.E_batt;
        no_bal_year(i).energy.E_du(month)         = sim_year(month,ref_scenario).no_bal.energy.E_du;
        no_bal_year(i).energy.E_bc(month)         = sim_year(month,ref_scenario).no_bal.energy.E_bc;
        no_bal_year(i).energy.E_bd(month)         = sim_year(month,ref_scenario).no_bal.energy.E_bd;
        no_bal_year(i).energy.E_grid_out(month)   = sim_year(month,ref_scenario).no_bal.energy.E_grid_out;
        no_bal_year(i).energy.E_grid_in(month)    = sim_year(month,ref_scenario).no_bal.energy.E_grid_in;
        no_bal_year(i).energy.E_balanced(month)   = sim_year(month,ref_scenario).no_bal.energy.E_balanced;
        no_bal_year(i).energy.E_lost(month)       = sim_year(month,ref_scenario).no_bal.energy.E_lost;
        no_bal_year(i).ss(month)                  = sim_year(month,ref_scenario).no_bal.ss;
        no_bal_year(i).sc(month)                  = sim_year(month,ref_scenario).no_bal.sc;

        % controllo che per i vari mesi ci siano gli stessi metadata, in
        % modo da esser sicuro che le simulazioni sono coerenti per gli
        % input
        if month == 1
            no_bal_year(i).metadata.c_nom      = sim_year(month,ref_scenario).c_nom;
            no_bal_year(i).metadata.c_var      = sim_year(month,ref_scenario).c_var;
            no_bal_year(i).metadata.I_bal      = sim_year(month,ref_scenario).I_bal;
            no_bal_year(i).metadata.I_bal_str  = sim_year(month,ref_scenario).I_bal_str;
            no_bal_year(i).metadata.eff        = sim_year(month,ref_scenario).eff;
        else
            aux_cmp(1) = no_bal_year(i).metadata.c_nom      - sim_year(month,ref_scenario).c_nom;
            aux_cmp(2) = no_bal_year(i).metadata.c_var      - sim_year(month,ref_scenario).c_var;
            if any(aux_cmp ~= 0)
                error "simulazioni con metadata diversi"
            end
        end

        ideal_year(i).energy.E_load(month)       = sim_year(month,ref_scenario).ideal.energy.E_load;
        ideal_year(i).energy.E_pv(month)         = sim_year(month,ref_scenario).ideal.energy.E_pv;
        ideal_year(i).energy.E_batt(month)       = sim_year(month,ref_scenario).ideal.energy.E_batt;
        ideal_year(i).energy.E_du(month)         = sim_year(month,ref_scenario).ideal.energy.E_du;
        ideal_year(i).energy.E_bc(month)         = sim_year(month,ref_scenario).ideal.energy.E_bc;
        ideal_year(i).energy.E_bd(month)         = sim_year(month,ref_scenario).ideal.energy.E_bd;
        ideal_year(i).energy.E_grid_out(month)   = sim_year(month,ref_scenario).ideal.energy.E_grid_out;
        ideal_year(i).energy.E_grid_in(month)    = sim_year(month,ref_scenario).ideal.energy.E_grid_in;
        ideal_year(i).energy.E_balanced(month)   = sim_year(month,ref_scenario).ideal.energy.E_balanced;
        ideal_year(i).energy.E_lost(month)       = sim_year(month,ref_scenario).ideal.energy.E_lost;
        ideal_year(i).ss(month)                  = sim_year(month,ref_scenario).ideal.ss;
        ideal_year(i).sc(month)                  = sim_year(month,ref_scenario).ideal.sc;
        if month == 1
            ideal_year(i).metadata.c_nom      = sim_year(month,ref_scenario).c_nom;
            ideal_year(i).metadata.c_var      = sim_year(month,ref_scenario).c_var;
            ideal_year(i).metadata.I_bal      = sim_year(month,ref_scenario).I_bal;
            ideal_year(i).metadata.I_bal_str  = sim_year(month,ref_scenario).I_bal_str;
            ideal_year(i).metadata.eff        = sim_year(month,ref_scenario).eff;
        else
            aux_cmp(1) = ideal_year(i).metadata.c_nom - sim_year(month,ref_scenario).c_nom;
            aux_cmp(2) = ideal_year(i).metadata.c_var - sim_year(month,ref_scenario).c_var;
            if any(aux_cmp ~= 0)
                error simulazioni con metadata diversi
            end
        end
        always_bal_year(i).energy.E_load(month)       = sim_year(month,sel).always_bal.energy.E_load;
        always_bal_year(i).energy.E_pv(month)         = sim_year(month,sel).always_bal.energy.E_pv;
        always_bal_year(i).energy.E_batt(month)       = sim_year(month,sel).always_bal.energy.E_batt;
        always_bal_year(i).energy.E_du(month)         = sim_year(month,sel).always_bal.energy.E_du;
        always_bal_year(i).energy.E_bc(month)         = sim_year(month,sel).always_bal.energy.E_bc;
        always_bal_year(i).energy.E_bd(month)         = sim_year(month,sel).always_bal.energy.E_bd;
        always_bal_year(i).energy.E_grid_out(month)   = sim_year(month,sel).always_bal.energy.E_grid_out;
        always_bal_year(i).energy.E_grid_in(month)    = sim_year(month,sel).always_bal.energy.E_grid_in;
        always_bal_year(i).energy.E_balanced(month)   = sim_year(month,sel).always_bal.energy.E_balanced;
        always_bal_year(i).energy.E_lost(month)       = sim_year(month,sel).always_bal.energy.E_lost;
        always_bal_year(i).ss(month)                  = sim_year(month,sel).always_bal.ss;
        always_bal_year(i).sc(month)                  = sim_year(month,sel).always_bal.sc;
        if month == 1
            always_bal_year(i).metadata.c_nom      = sim_year(month,sel).c_nom;
            always_bal_year(i).metadata.c_var      = sim_year(month,sel).c_var;
            always_bal_year(i).metadata.I_bal      = sim_year(month,sel).I_bal;
            always_bal_year(i).metadata.I_bal_str  = sim_year(month,sel).I_bal_str;
            always_bal_year(i).metadata.eff        = sim_year(month,sel).eff;
        else
            aux_cmp(1) = always_bal_year(i).metadata.c_nom - sim_year(month,sel).c_nom;
            aux_cmp(2) = always_bal_year(i).metadata.c_var - sim_year(month,sel).c_var;
            aux_cmp(3) = always_bal_year(i).metadata.I_bal - sim_year(month,sel).I_bal;
            aux_cmp(4) = always_bal_year(i).metadata.eff   - sim_year(month,sel).eff;
            if any(aux_cmp ~= 0)
                error simulazioni con metadata diversi
            end
        end
        for h=1:length(sim_year(month,sel).opt_bal)
            opt_bal_year(i,h).energy.E_load(month)       = sim_year(month,sel).opt_bal(h).energy.E_load;
            opt_bal_year(i,h).energy.E_pv(month)         = sim_year(month,sel).opt_bal(h).energy.E_pv;
            opt_bal_year(i,h).energy.E_batt(month)       = sim_year(month,sel).opt_bal(h).energy.E_batt;
            opt_bal_year(i,h).energy.E_du(month)         = sim_year(month,sel).opt_bal(h).energy.E_du;
            opt_bal_year(i,h).energy.E_bc(month)         = sim_year(month,sel).opt_bal(h).energy.E_bc;
            opt_bal_year(i,h).energy.E_bd(month)         = sim_year(month,sel).opt_bal(h).energy.E_bd;
            opt_bal_year(i,h).energy.E_grid_out(month)   = sim_year(month,sel).opt_bal(h).energy.E_grid_out;
            opt_bal_year(i,h).energy.E_grid_in(month)    = sim_year(month,sel).opt_bal(h).energy.E_grid_in;
            opt_bal_year(i,h).energy.E_balanced(month)   = sim_year(month,sel).opt_bal(h).energy.E_balanced;
            opt_bal_year(i,h).energy.E_lost(month)       = sim_year(month,sel).opt_bal(h).energy.E_lost;
            opt_bal_year(i,h).ss(month)                  = sim_year(month,sel).opt_bal(h).ss;
            opt_bal_year(i,h).sc(month)                  = sim_year(month,sel).opt_bal(h).sc;
            if month == 1
                opt_bal_year(i,h).metadata.c_nom      = sim_year(month,sel).c_nom;
                opt_bal_year(i,h).metadata.c_var      = sim_year(month,sel).c_var;
                opt_bal_year(i,h).metadata.I_bal      = sim_year(month,sel).I_bal;
                opt_bal_year(i,h).metadata.I_bal_str  = sim_year(month,sel).I_bal_str;
                opt_bal_year(i,h).metadata.eff        = sim_year(month,sel).eff;
                opt_bal_year(i,h).metadata.horizon    = sim_year(month,sel).opt_bal(h).horizon;
            else
                aux_cmp(1) = opt_bal_year(i,h).metadata.c_nom - sim_year(month,sel).c_nom;
                aux_cmp(2) = opt_bal_year(i,h).metadata.c_var - sim_year(month,sel).c_var;
                aux_cmp(3) = opt_bal_year(i,h).metadata.I_bal - sim_year(month,sel).I_bal;
                aux_cmp(4) = opt_bal_year(i,h).metadata.eff   - sim_year(month,sel).eff;
                if any(aux_cmp ~= 0)
                    error simulazioni con metadata diversi
                end
            end
        end
    end
end
end
