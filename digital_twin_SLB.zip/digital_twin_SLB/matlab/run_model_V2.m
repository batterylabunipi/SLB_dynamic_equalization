function run_model_V2(sim_config,varargin)
%function run_model_V2(sim_config,sim_reference,save_power_ts_ON)
% sim_config contiene tutte le configurazioni e i parametri del modello
% simulink
% come parametri varargin posso passare alla funzione le stringhe:
    % 'sim_reference' --> esegue simulazione per NO_BAL e IDEAL
    % 'save_power_ts_ON' -->salva i timeseries di power
    % 'save_SoC_ts_ON' --> salva i timeseries di soc e bal activation
    % 'save_out_position', 5 --> decide in che posizione di my_out inserire
    % i risultati (es. 5)
%sim_reference indica se devo fare una simulazione con il caso NO_BAL e il
%caso IDEAL. (IDEAL è quando simulo una batteria con celle omogenee uguali
% a C_nom.
% NB: Queste due simulazioni ha senso farle solo una volta e
% dipendono solo dal profilo di ingresso, e dalla capacità della batteria.
%% set model simulation option
% default param
sim_reference = false;
save_power_ts_ON = false;
save_SoC_ts_ON = false;
save_out_position = 0;

for i=1:length(varargin)
    switch varargin{i}
        case 'sim_reference'
            sim_reference = true;
        case 'save_power_ts_ON'
            save_power_ts_ON = true;
        case 'save_SoC_ts_ON'
            save_SoC_ts_ON = true;
        case 'save_out_position'
            i=i+1;
            save_out_position = varargin{i};
        otherwise
            % questo warning viene sempre attivato quando c'è
            % ('save_out_position', 5), perchè anche se faccio
            % l'incremento di i, il for loop in Matlab non viene
            % aggiornato.
           %warndlg("default case in varargin parsing","warning run_model_V2");  
    end
end

%% prepare battery config
t_start = tic;
batt.n_cell = 10;
batt.c_nom = sim_config.C_nom; %Ah
batt.c_var = sim_config.C_var; % percentuale
c_min = batt.c_nom * (1-batt.c_var);
c_max = batt.c_nom * (1+batt.c_var);
batt.c_cell = [c_min:(c_max-c_min)/(batt.n_cell-1):c_max];

load("data/NMC_60Ah_param.mat");
batt.cell.nominal_voltage = 3.65; %V
batt.cell.ocv = mdl_par.ocv;
batt.cell.soc = mdl_par.soc/100;
batt.ocv_soc(:,1) = batt.cell.ocv;
batt.ocv_soc(:,2) = batt.cell.soc;
batt.cell.r0 = mean(mdl_par.r0(4:19));
batt.cell.r1 = mean(mdl_par.r1(4:19));
batt.cell.c1 = mean(mdl_par.c1(4:19));
batt.R0_cell = (batt.cell.r0*batt.c_nom) ./ batt.c_cell;
batt.soc0 =  0.99+zeros(1,batt.n_cell);

clear C_min C_max mdl_out mdl_par

system.balance_algo_period = 10;    %[sec] intervallo di attivazione controllore
system.delta_SoC_thres = 1/100;     % percentuale di sbilanciamento tra le celle che fa attivare il DC-DC
system.cell_cutoff_max = 0.99;   %range in cui faccio ciclare la batteria
system.cell_cutoff_min = 0.01;
system.alarm_soc_bal = 0.01;     % SoC residuo per avere full-charge o full-discharge, che fa decidere al TWIN di attivare il bilanciamento
system.SoC_L = 0.2;
system.bal_topology = 1;    %system.bal_topology: 1= DC2C, 2=C2P, 3=P2C, else=no_bal
system.eff = sim_config.eff;
system.I_bal = sim_config.I_bal;

system.horizon_h = 12;    % gli step sono ogni 15 minuti
system.twin_run_period = 15*60; % [s] intervallo di attivazione del twin che fa la previsione del bilanciamento

%% prepare input profile
load('data\input_profile\load_profile_raw.mat');    %[kW]
load('data\input_profile\PV_irr_raw.mat');          %[W]

load_profile_resampled.P = mean(reshape(load_profile_raw.P(1:end),15,[]))'; %[kW]
load_profile_resampled.P = load_profile_resampled.P * 1e3;                      %[W]
load_profile_resampled.t = reshape(load_profile_raw.t(1:end),15,[])';
load_profile_resampled.t = load_profile_resampled.t(:,1);

% USER INPUT
m.ALWAYS = 0;
m.NO_BAL = 1;
m.OPTIMAL = 2;
system.sim_start_day = sim_config.start_day;
system.sim_days = sim_config.sim_dur_day;
system.horizon_h = 1; %[h], lunghezza in ore dell'intervallo da presimulare con TWIN
system.bal_mode = m.NO_BAL;  %NO_BAL/ALWAYS/OPTIMAL_BAL
system.pv_pk = sim_config.pv_pk;

%aux variable
sim_step_dur = 900; %s
sim_step_n = system.sim_days*96;
sim_start_step = (system.sim_start_day-1)*96 + 1;
sim_end_step = sim_start_step + sim_step_n -1;

start_sim_time = 0;
end_sim_time = sim_step_n * sim_step_dur - 1;

load_profile = [];
load_profile(:,1) = [0 : sim_step_dur : end_sim_time]'; %timestamp (s)
load_profile(:,2) = load_profile_resampled.P(sim_start_step:sim_end_step); % power profile [W]
pv_profile = [];
pv_profile(:,1) = [0 : sim_step_dur : end_sim_time]'; %timestamp (s)
pv_profile(:,2) = pv_profile_raw.I(sim_start_step:sim_end_step)*system.pv_pk * -1; % power profile [W] (negativa)

% figure; hold on;
% plot(load_profile(:,1),load_profile(:,2));
% plot(load_profile(:,1),pv_profile(:,2));
% legend("load[W]", "PV[W]");
% title('selected power profile');

save_sample_period = 10; % [s] intervallo di acquisizione dei dati

%% run simulation
system.simulink_mdl =  "Equalizer_scheduling_system_V2_1.slx";
load_system(system.simulink_mdl);

%  la modalità accelerato va abilitata nell'ambiente simulink, oppure devo fare:
% open_system(system.simulink_mdl);
% set_param(system.simulink_mdl,'SimulationMode','Accelerator');

if sim_reference == true
    % %%%%%%%%%%%%    NO_BAL

    fprintf("running NO_BAL... ")
    system.bal_mode = m.NO_BAL;
    out = sim(system.simulink_mdl,'SrcWorkspace', 'current');
    no_bal = pack_data(out,save_power_ts_ON,save_SoC_ts_ON);
    fprintf("elapsed %.2f sec \n", out.SimulationMetadata.TimingInfo.TotalElapsedWallTime );
    assignin('base',"no_bal",no_bal);

    %%%%%%%%%%%%    IDEAL
    fprintf("running IDEAL... ")
    batt.c_cell = batt.c_nom + zeros(1,batt.n_cell);
    batt.R0_cell = (batt.cell.r0*batt.c_nom) ./ batt.c_cell;
    system.bal_mode = m.NO_BAL;
    out = sim(system.simulink_mdl,'SrcWorkspace', 'current');
    ideal = pack_data(out,save_power_ts_ON,save_SoC_ts_ON);
    fprintf("elapsed %.2f sec \n", out.SimulationMetadata.TimingInfo.TotalElapsedWallTime );
    assignin('base',"no_bal",ideal);

    always_bal = [];
    opt_bal = [];
    I_bal_str = "--";
else
    no_bal = [];
    ideal = [];

    %%%%%%%%%%%%    ALWAYS
    fprintf("running ALWAYS... ")
    system.bal_mode = m.ALWAYS;
    out = sim(system.simulink_mdl,'SrcWorkspace', 'current');
    always_bal = pack_data(out,save_power_ts_ON,save_SoC_ts_ON);
    assignin('base',"always_bal",always_bal);
    fprintf("elapsed %.2f sec \n", out.SimulationMetadata.TimingInfo.TotalElapsedWallTime );

    %%%%%%%%%%%%    OPTIMAL
    % MODIFICATO
    % system.bal_mode = m.OPTIMAL;
    % for i=1:length(sim_config.horizon)
    %     fprintf("running OPTIMAL [%i/%i]... ", i ,length(sim_config.horizon))
    %     system.horizon_h = sim_config.horizon(i);
    %     out = sim(system.simulink_mdl,'SrcWorkspace', 'current');
    %     opt_bal(i) = pack_data(out,save_power_ts_ON,save_SoC_ts_ON,'horizon', system.horizon_h);
    %     fprintf("elapsed %.2f sec \n", out.SimulationMetadata.TimingInfo.TotalElapsedWallTime );
    % end
    I_bal_str = Ah_to_Crate(system.I_bal,batt.c_nom);
    % assignin('base',"opt_bal",opt_bal);

end

tic;
fprintf("saving data... ");
%%%%%%%%%%%%    SELECT WHAT TO SAVE
system.sim_metadata = out.SimulationMetadata;
out_log.system      = system;
out_log.batt        = batt;
out_log.sim_start_day = system.sim_start_day;
out_log.sim_days    = system.sim_days;
out_log.c_nom       = batt.c_nom;
out_log.c_var       = batt.c_var;
out_log.I_bal       = system.I_bal;
out_log.I_bal_str   = I_bal_str;
out_log.eff         = system.eff;
out_log.ideal       = ideal;
out_log.no_bal      = no_bal;
out_log.always_bal   = always_bal;
%out_log.opt_bal     = opt_bal;     % MODIFICATO
if sim_reference == true      %evito di salvare tutte le volte, salvo solo il primo caso
    out_log.input_profile.load = load_profile;
    out_log.input_profile.pv = pv_profile;
else
    out_log.input_profile = [];
end
%%%%%%%%%%%%%%%%%       SAVE      %%%%%%%%%%%%%%%
file_name = sim_config.file_name;
if isfile(file_name)
    fprintf("file exist: %s\n",file_name)% file ok, load it
    load(file_name);
    if save_out_position == 0 %default, accodo i dati al preesistente array
        my_out_idx = length(my_out) + 1; % i nuovi dati li accodo al presistente array
        my_out(my_out_idx) = out_log;
    elseif save_out_position <= length(my_out)
        for i=length(my_out):-1:(save_out_position)  %   sposto le struct in avanti a partire dall'ultima per inserire al posto giusto quella nuova 
            my_out(i+1)=my_out(i);
        end
        my_out(save_out_position) = out_log;
    else
        warndlg("save_out_position errato","attenzione");
    end
    save(file_name, "my_out", "-append")
else
    fprintf("\t\t file NOT FOUND: %s\n --> CREATED NEW... ",file_name)
    my_out(1) = out_log;
    save(file_name, "my_out"); % primo salvataggio, gli altri sono fatti con "-append"
end

fid = fopen('data/output/log_simulation.txt', 'a+'); %% per tenere traccia delle simulazioni fatte
fprintf(fid, "SIM -> startday: %.2f, Cnom=%.1f, Cvar=%.1f%%, I_bal=%s, eff: %.2f, sim_ref(0/1)=%d timestamp: %s, filename= %s, elapsed: %.2f (min)\n", ...
    system.sim_days , ...
    batt.c_nom, ...
    batt.c_var, ...
    I_bal_str, ...
    system.eff, ...
    sim_reference, ...
    datestr(datetime('now')),...
    file_name, ...
    toc(t_start)/60);
fclose(fid);
fprintf("elapsed = %.2f sec \n ",toc);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function out_log = pack_data(out,save_power_ts_ON,save_SoC_ts_ON, varargin)
%inpacchetta i risultati delle simulazioni in due strutture più semplici da
%gestire
% NB: l'energia in simulink è in [Ws], per passare a KWh divido per
% 3600*1e3 = 3.6e6. La potenza è in [W], e la porto in [kW]
energy.E_load       = out.E_load;
energy.E_pv         = out.E_pv;         % < 0
energy.E_batt       = out.E_batt;
energy.E_du         = out.E_du;
energy.E_bc         = out.E_bc;         % < 0
energy.E_bd         = out.E_bd;
energy.E_grid_out   = out.E_grid_out;   % < 0
energy.E_grid_in    = out.E_grid_in;
energy.E_balanced   = out.E_balanced;
energy.E_lost       = out.E_lost;
energy =  structfun(@(x) x/3.6e6, energy, 'uniformOutput', false);
% structfun applica una funzione a tutti i campi di una struct. Qui la
% funzione è una funziona implicita ed è f = @(x) 0;
% @ crea il puntatore a funzione, x è l'argomento della funzione. e poi
% dopo c'è la funzione vera e propria (che in questo caso è 0, quindi
% restituisce sempre 0). 'uniformOutput'=false indica che viene
% restituita una funzione, altrimenti i campi sarebbero stati
% concatenati in un vettore.

[ss,sc] = evaluate_ss_sc(energy);
if save_power_ts_ON
    power.P_du = out.P_du;
    power.P_bc = out.P_bc;      % < 0
    power.P_bd = out.P_bd;
    power.P_grid_out = out.P_grid_out;  % < 0
    power.P_grid_in = out.P_grid_in;
    
    power.P_pv = out.P_pv;      %added
    power.P_load = out.P_load;  %added
    power.P_lost = out.P_lost;  %added

    power =  structfun(@(x) x/1e3, power, 'uniformOutput', false);
else
    power =  [];
end

if save_SoC_ts_ON
    out_log.SoC_profile             = out.SoC_profile;
    out_log.bal_activation_profile  = out.bal_activation_profile;
else
    out_log.SoC_profile             = [];
    out_log.bal_activation_profile  = [];
end

out_log.offline_time = out.offline_time;    % [s]
out_log.bal_time_tot = out.bal_time_tot;

out_log.energy  = energy;
out_log.power   = power;
out_log.ss      = ss;
out_log.sc      = sc;

% Controllo se horizon è stato passato come argomento
if ~isempty(varargin) && strcmp(varargin{1}, 'horizon')
    out_log.horizon = varargin{2};
end

end

function [ss,sc] = evaluate_ss_sc(energy)
% calcola gli indicatori self-sufficiency e self-consumption partendo da i
% valori di energia. La chiamo in pack_data
sc = 100 * (energy.E_du + abs(energy.E_bc)) / abs(energy.E_pv);
ss = 100 * (energy.E_du  + energy.E_bd) / energy.E_load ;

end