%% V2 load
clear;

% months_list = {["January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December"],
%                [ 1,           32,       60,      91,     121,    152,  182,     213,        244,        274,       305,       335  ]};

%% schedule simulation
% opzioni di default della simulazione
sim_config.file_name = "data/output/one_day.mat";
sim_config.start_day = 60+12;
sim_config.sim_dur_day = 6;
sim_config.pv_pk = 7;   % PV peak power [kWp], numero di kWp dell'impianto
sim_config.C_nom = 400;
sim_config.C_var = 0.15;
sim_config.horizon = [3];
sim_config.eff= 0.70;
sim_config.I_bal = sim_config.C_nom/10;

run_model_V2(sim_config,'sim_reference','save_SoC_ts_ON', 'save_power_ts_ON');
run_model_V2(sim_config,'save_SoC_ts_ON','save_power_ts_ON');
% sim_config.I_bal = sim_config.C_nom/22;
% run_model_V2(sim_config,'save_SoC_ts_ON');

%% one year simulation, with capacity fading
% opzioni di default della simulazione

SoH = 0.8;
sim_config.file_name = "data/output/one_year_aging.mat";
sim_config.start_day = 1;
sim_config.sim_dur_day = 365;
sim_config.pv_pk = 7;   % PV peak power [kWp], numero di kWp dell'impianto
sim_config.C_nom = 400*SoH;
sim_config.C_var = 0.25;
sim_config.horizon = [];
sim_config.eff= 0.70;
sim_config.I_bal = sim_config.C_nom/10;

run_model_V2(sim_config,'sim_reference');
run_model_V2(sim_config,'save_SoC_ts_ON');
% sim_config.I_bal = sim_config.C_nom/22;
% run_model_V2(sim_config,'save_SoC_ts_ON');
%% simulazioni mensili
% elemento della struct my_out:
% id: 1   reference  c_nom = 400, C_var = 0.15,
% id: 2:5 eff=0.7, i_bal= c/5, c/10,c/25,c/50
% id: 6:8 eff=0.9,  "       "   "   "
% id: 9     reference  c_nom = 400, C_var = 0.25,
% id: 10:13  eff=0.7, i_bal= c/5, c/10,c/25,c/50
% id: 14:16 eff=0.9,  "       "   "   "
% id: 17   reference  c_nom = 400, C_var = 0.25, ### alarm_soc_bal = 10/90% ### (per vedere se in questo modo si riducono le scariche parziali a giugno/luglio, e valorizzo opt_bal)
% id: 18:20  eff=0.7, i_bal= c/10,c/25,c/50
% id: 21   reference  c_nom = 400, C_var = 0.35,
% id: 22:25  eff=0.7, i_bal= c/5,c/10,c/25,c/50

diary("data/output/log_console.txt")
sim_config.sim_dur_day = 30;
sim_config.C_nom = 400;
sim_config.horizon = [1, 3, 6, 12]; %[1,6,12];
i_bal = sim_config.C_nom ./ [5, 10, 25, 50];%[10, 25, 50];
sim_config.C_var = 0.35;


% months_list = {["January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December"],
% month_list = [ 1,           32,       60,      91,     121,    152,  182,     213,        244,        274,       305,       335  ];
% capacity_list = [100,200,300,400,500,600];
sim_config.file_name = "data/output/SoC_one_year.mat";
sim_config.start_day = 1;
sim_config.sim_dur_day = 364;
run_model_V2(sim_config,'sim_reference',"save_SoC_ts_ON");



%%
diary("data/output/log_console.txt")
sim_config.sim_dur_day = 30;
sim_config.C_nom = 400;
sim_config.horizon = [3, 6, 12]; %[1,6,12];
i_bal = sim_config.C_nom ./ [10, 25, 50];
sim_config.C_var = 0.15;
%%
%%%%%%%%%%%%%% GENNAIO
sim_config.file_name = "data/output/gennaio1.mat";
sim_config.start_day = 1;
sim_start_tic = tic;
run_model_V2(sim_config,'sim_reference');

sim_config.eff= 0.70;
fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
for i=1:length(i_bal)
    sim_config.I_bal = i_bal(i);
    run_model_V2(sim_config,'save_SoC_ts_ON');   % run_model_V2(sim_config, 'save_SoC_ts_ON','save_out_position', 10);
end
re_save(sim_config.file_name);

% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config, 'save_SoC_ts_ON');
% end
% re_save(sim_config.file_name);

fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
%%
%%%%%%%%%%%%%% FEBBRAIO
sim_config.file_name = "data/output/febbraio1.mat";
sim_config.start_day = 32;
sim_start_tic = tic;
run_model_V2(sim_config,'sim_reference');

sim_config.eff= 0.70;
fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
for i=1:length(i_bal)
    sim_config.I_bal = i_bal(i);
    run_model_V2(sim_config,'save_SoC_ts_ON');
end
re_save(sim_config.file_name);

% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config, 'save_SoC_ts_ON' );
% end
% re_save(sim_config.file_name);

fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));

%%%%%%%%%%%%%% MARZO
sim_config.file_name = "data/output/marzo1.mat";
sim_config.start_day = 60;
sim_start_tic = tic;
run_model_V2(sim_config,'sim_reference');

sim_config.eff= 0.70;
fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
for i=1:length(i_bal)
    sim_config.I_bal = i_bal(i);
    run_model_V2(sim_config,'save_SoC_ts_ON');
end
re_save(sim_config.file_name);

% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config, 'save_SoC_ts_ON' );
% end
% re_save(sim_config.file_name);

fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));

%%%%%%%%%%%%%% APRILE
sim_config.file_name = "data/output/aprile1.mat";
sim_config.start_day = 91;
sim_start_tic = tic;
run_model_V2(sim_config,'sim_reference');

sim_config.eff= 0.70;
fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
for i=1:length(i_bal)
    sim_config.I_bal = i_bal(i);
    run_model_V2(sim_config,'save_SoC_ts_ON');
end
re_save(sim_config.file_name);

% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config, 'save_SoC_ts_ON' );
% end
% re_save(sim_config.file_name);

fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));

%%%%%%%%%%%%%% MAGGIO
sim_config.file_name = "data/output/maggio1.mat";
sim_config.start_day = 121;
sim_start_tic = tic;
run_model_V2(sim_config,'sim_reference');

sim_config.eff= 0.70;
fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
for i=1:length(i_bal)
    sim_config.I_bal = i_bal(i);
    run_model_V2(sim_config,'save_SoC_ts_ON');
end
re_save(sim_config.file_name);

% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config, 'save_SoC_ts_ON' );
% end
% re_save(sim_config.file_name);

fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));

%%%%%%%%%%%%%% GIUGNO
sim_config.file_name = "data/output/giugno1.mat";
sim_config.start_day = 152;
sim_start_tic = tic;
run_model_V2(sim_config,'sim_reference');

sim_config.eff= 0.70;
fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
for i=1:length(i_bal)
    sim_config.I_bal = i_bal(i);
    run_model_V2(sim_config,'save_SoC_ts_ON');
end
re_save(sim_config.file_name);

% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config, 'save_SoC_ts_ON' );
% end
% re_save(sim_config.file_name);

fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));

%%%%%%%%%%%%%% LUGLIO
sim_config.file_name = "data/output/luglio1.mat";
sim_config.start_day = 182;
sim_start_tic = tic;
run_model_V2(sim_config,'sim_reference');

sim_config.eff= 0.70;
fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
for i=1:length(i_bal)
    sim_config.I_bal = i_bal(i);
    run_model_V2(sim_config,'save_SoC_ts_ON');
end
re_save(sim_config.file_name);

% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config, 'save_SoC_ts_ON' );
% end
% re_save(sim_config.file_name);

fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
%
%%%%%%%%%%%%%% AGOSTO
sim_config.file_name = "data/output/agosto1.mat";
sim_config.start_day = 213;
sim_start_tic = tic;
run_model_V2(sim_config,'sim_reference');

sim_config.eff= 0.70;
fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
for i=1:length(i_bal)
    sim_config.I_bal = i_bal(i);
    run_model_V2(sim_config,'save_SoC_ts_ON');
end
re_save(sim_config.file_name);
%
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config, 'save_SoC_ts_ON' );
% end
% re_save(sim_config.file_name);

fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));

%%%%%%%%%%%%%% SETTEMBRE
sim_config.file_name = "data/output/settembre1.mat";
sim_config.start_day = 244;
sim_start_tic = tic;
run_model_V2(sim_config,'sim_reference');

sim_config.eff= 0.70;
fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
for i=1:length(i_bal)
    sim_config.I_bal = i_bal(i);
    run_model_V2(sim_config,'save_SoC_ts_ON');
end
re_save(sim_config.file_name);

% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config, 'save_SoC_ts_ON' );
% end
% re_save(sim_config.file_name);

fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));

%%%%%%%%%%%%%% ottobre
sim_config.file_name = "data/output/ottobre1.mat";
sim_config.start_day = 274;
sim_start_tic = tic;
run_model_V2(sim_config,'sim_reference');

sim_config.eff= 0.70;
fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
for i=1:length(i_bal)
    sim_config.I_bal = i_bal(i);
    run_model_V2(sim_config,'save_SoC_ts_ON');
end
re_save(sim_config.file_name);

% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config, 'save_SoC_ts_ON' );
% end
% re_save(sim_config.file_name);

fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
%%%%%%%%%%%%%% novembre
sim_config.file_name = "data/output/novembre1.mat";
sim_config.start_day = 305;
sim_start_tic = tic;
run_model_V2(sim_config,'sim_reference');

sim_config.eff= 0.70;
fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
for i=1:length(i_bal)
    sim_config.I_bal = i_bal(i);
    run_model_V2(sim_config,'save_SoC_ts_ON');
end
re_save(sim_config.file_name);

% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config, 'save_SoC_ts_ON' );
% end
% re_save(sim_config.file_name);

fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));

%%%%%%%%%%%%%% dicembre
sim_config.file_name = "data/output/dicembre1.mat";
sim_config.start_day = 335;
sim_start_tic = tic;
run_model_V2(sim_config,'sim_reference');

sim_config.eff= 0.70;
fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
for i=1:length(i_bal)
    sim_config.I_bal = i_bal(i);
    run_model_V2(sim_config,'save_SoC_ts_ON');
end
re_save(sim_config.file_name);

% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config, 'save_SoC_ts_ON' );
% end
% re_save(sim_config.file_name);

fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
diary off;
%% aux function
function re_save(file_name)
% mi sono accorto che con append i file è come se si deframmentassero, e
% diventano più grandi del necessario, quindi ogni tanto carico il file per intero, e
% lo salvo di nuovo
tic;
fprintf("start re_save function...  ")
load(file_name);
save(file_name, "my_out");
fprintf("elapsed %.1f sec\n", toc);
end
