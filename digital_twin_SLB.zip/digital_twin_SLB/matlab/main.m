%% V2 load
clear;

% months_list = {["January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December"],
%                [ 1,           32,       60,      91,     121,    152,  182,     213,        244,        274,       305,       335  ]};

%% schedule simulation
% opzioni di default della simulazione
sim_config.file_name = "data/output/tmp.mat";
sim_config.start_day = 120;
sim_config.sim_dur_day = 10;
sim_config.pv_pk = 5;   % PV peak power [kWp], numero di kWp dell'impianto
sim_config.C_nom = 400;
sim_config.C_var = 0.15;
sim_config.horizon = [6];
sim_config.eff= 0.70;
sim_config.I_bal = sim_config.C_nom/5;

% run_model_V2(sim_config,'sim_reference'); 
% sim_config.I_bal =sim_config.C_nom/10; 
% run_model_V2(sim_config,'save_SoC_ts_ON'); 
% % sim_config.I_bal = sim_config.C_nom/20;
% run_model_V2(sim_config);

%% simulazioni mensili
% elemento della struct my_out:
% id: 1   reference  c_nom = 400, C_var = 0.15, 
% id: 2:4 eff=0.7, i_bal= c/10,c/25,c/50
% id: 5:7 eff=0.9,  "       "   "   "
% id: 8     reference  c_nom = 400, C_var = 0.25, 
% id: 9:11  eff=0.7, i_bal= c/10,c/25,c/50
% id: 12:14 eff=0.9,  "       "   "   "

% NB:   DA FARE GIUGNO E LUGLIO!!

diary("data/output/log_console.txt")

sim_config.sim_dur_day = 30;
sim_config.C_nom = 400;
sim_config.horizon = [1,6,12];
i_bal = sim_config.C_nom ./ [10, 25, 50];
sim_config.C_var = 0.15;

% %%%%%%%%%%%%%% GENNAIO
% sim_config.file_name = "data/output/gennaio.mat";
% sim_config.start_day = 1;
% sim_start_tic = tic;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
% 
% %%%%%%%%%%%%%% FEBBRAIO
% sim_config.file_name = "data/output/febbraio.mat";
% sim_config.start_day = 32;
% sim_start_tic = tic;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
% 
% %%%%%%%%%%%%%% MARZO
% sim_config.file_name = "data/output/marzo.mat";
% sim_config.start_day = 60;
% sim_start_tic = tic;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
% 
% %%%%%%%%%%%%%% APRILE
% sim_config.file_name = "data/output/aprile.mat";
% sim_config.start_day = 91;
% sim_start_tic = tic;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
% 
% %%%%%%%%%%%%%% MAGGIO
% sim_config.file_name = "data/output/maggio.mat";
% sim_config.start_day = 121;
% sim_start_tic = tic;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
%
% %%%%%%%%%%%%%% GIUGNO
% sim_config.file_name = "data/output/giugno.mat";
% sim_config.start_day = 152;
% sim_start_tic = tic;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config,'save_SoC_ts_ON');
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
% 
% %%%%%%%%%%%%%% LUGLIO
% sim_config.file_name = "data/output/luglio.mat";
% sim_config.start_day = 182;
% sim_start_tic = tic;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config,'save_SoC_ts_ON');
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
% 
% sim_config.C_var = 0.25;
% 
% %%%%%%%%%%%%%%%%%%%%%%% con c_var = 25%
% %%%%%%%%%%%%%% GIUGNO
% sim_config.file_name = "data/output/giugno.mat";
% sim_config.start_day = 152;
% sim_start_tic = tic;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
% 
% %%%%%%%%%%%%%% LUGLIO
% sim_config.file_name = "data/output/luglio.mat";
% sim_config.start_day = 182;
% sim_start_tic = tic;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));

% %%%%%%%%%%%%%% AGOSTO
% sim_config.file_name = "data/output/agosto.mat";
% sim_config.start_day = 213;
% sim_start_tic = tic;
% sim_config.C_var = 0.15;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config,'save_SoC_ts_ON');
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
% 
% %%%%%%%%%%%%%% AGOSTO
% sim_config.file_name = "data/output/agosto.mat";
% sim_config.start_day = 213;
% sim_start_tic = tic;
% sim_config.C_var = 0.25;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config,'save_SoC_ts_ON');
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
% 
% 
% %%%%%%%%%%%%%% SETTEMBRE
% sim_config.file_name = "data/output/settembre.mat";
% sim_config.start_day = 244;
% sim_start_tic = tic;
% sim_config.C_var = 0.15;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config,'save_SoC_ts_ON');
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
% 
% %%%%%%%%%%%%%% SETTEMBRE
% sim_config.file_name = "data/output/settembre.mat";
% sim_config.start_day = 244;
% sim_start_tic = tic;
% sim_config.C_var = 0.25;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config,'save_SoC_ts_ON');
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
% 
% %%%%%%%%%%%%%% ottobre
% sim_config.file_name = "data/output/ottobre.mat";
% sim_config.start_day = 274;
% sim_start_tic = tic;
% sim_config.C_var = 0.15;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config,'save_SoC_ts_ON');
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
% 
% %%%%%%%%%%%%%% ottobre
% sim_config.file_name = "data/output/ottobre.mat";
% sim_config.start_day = 274;
% sim_start_tic = tic;
% sim_config.C_var = 0.25;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config,'save_SoC_ts_ON');
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
% 
% 
% %%%%%%%%%%%%%% novembre
% sim_config.file_name = "data/output/novembre.mat";
% sim_config.start_day = 305;
% sim_start_tic = tic;
% sim_config.C_var = 0.15;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config,'save_SoC_ts_ON');
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
% 
% %%%%%%%%%%%%%% novembre
% sim_config.file_name = "data/output/novembre.mat";
% sim_config.start_day = 305;
% sim_start_tic = tic;
% sim_config.C_var = 0.25;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config,'save_SoC_ts_ON');
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
% 
% 
% %%%%%%%%%%%%%% dicembre
% sim_config.file_name = "data/output/dicembre.mat";
% sim_config.start_day = 335;
% sim_start_tic = tic;
% sim_config.C_var = 0.15;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config,'save_SoC_ts_ON');
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
% 
% %%%%%%%%%%%%%% dicembre
% sim_config.file_name = "data/output/dicembre.mat";
% sim_config.start_day = 335;
% sim_start_tic = tic;
% sim_config.C_var = 0.25;
% run_model_V2(sim_config,'sim_reference');
% 
% sim_config.eff= 0.70;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config,'save_SoC_ts_ON');
% end
% re_save(sim_config.file_name);
% 
% sim_config.eff= 0.90;
% fprintf("SIM -> startday:%.2f, eff:%.2f\n",sim_config.sim_dur_day, sim_config.eff);
% for i=1:length(i_bal)
%     sim_config.I_bal = i_bal(i);
%     run_model_V2(sim_config);
% end
% re_save(sim_config.file_name);
% fprintf("END SIM, startday:%.2f, elapsed:%.2f sec\n\n",sim_config.sim_dur_day, toc(sim_start_tic));
% 

diary off;
%% aux function
function re_save(file_name)
% mi sono accorto che con append i file è come se si deframmentassero, e
% diventano più grandi del necessario, quindi ogni tanto carico il file per intero, e
% lo salvo di nuovo
tic;
fprintf("start re_save function...  ")
load(file_name);
save(file_name, "my_out");
fprintf("elapsed %.1f sec\n", toc);
end
