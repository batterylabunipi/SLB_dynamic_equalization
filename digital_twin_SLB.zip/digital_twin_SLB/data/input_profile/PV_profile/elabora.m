clear;

file_name='./YearlyData_2021_corrected.csv';

id=fopen(file_name);
C = textscan(id,'%s %f','HeaderLines',1,'Delimiter',';','EmptyValue',0);
fclose(id);

data.date_time=C{1};



id=fopen(file_name);
C = textscan(id,'%s %s %f','HeaderLines',1,'Delimiter',';  ','EmptyValue',0);
fclose(id);

data.date=C{1};
data.time=C{2};


save('data_date.mat','data');

id=fopen(file_name);
C = textscan(id,'%f %f %f %f %f %f %f ','HeaderLines',1,'MultipleDelimsAsOne',1,'Delimiter','; - :','EmptyValue',0);
fclose(id);

%DateNumber = datenum(double(C{1}),double(C{2}),double(C{3}),double(C{4}),double(C{5}),double(C{6}));
DateNumber = datenum(C{1},C{2},C{3},C{4},C{5},C{6});
DateNumber=DateNumber-DateNumber(1);
DateNumber=DateNumber*24;
data.t_h=DateNumber;
data.t_m=DateNumber*60;
data.t_s=DateNumber*3600;
data.I=C{7};


save('data_irr.mat','data');
%%

clear;
load data_irr.mat

ninv= 0.95;% inverter efficiency
npv= 0.167;%PV cell efficiency
A=12.5;%PV area m^2 (2.5m+5m)

data.P=ninv*npv*A*data.I;
save('data_irr_P.mat','data');

